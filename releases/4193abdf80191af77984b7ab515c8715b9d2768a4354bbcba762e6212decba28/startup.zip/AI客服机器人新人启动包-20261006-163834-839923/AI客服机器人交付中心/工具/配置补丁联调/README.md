# 配置补丁联调工具

以 `平台接口/第二阶段-20261003/` 中的 API 文档、开发决策指南和完整联调执行单为当前契约。`phase1.py` 用于只读发现与可信工作包导出；`phase2.py` 用于测试环境上传到回退的分步联调。两者均不得替代业务确认、本次发布确认、人工 diff 审核和真人企微实测。Codex 分角色模拟在客户任务对话内完成，无需后台对话测试接口。

Python 3.11 及 `PyYAML>=6,<7` 是第二阶段工具的依赖。新人在自己的 Python 环境执行 `py -m pip install -r 工具/配置补丁联调/requirements.txt`；macOS/Linux 用 `python3`。Token 只放当前进程环境变量 `CONFIG_PATCH_STAFF_TOKEN`，Base URL 放 `CONFIG_PATCH_BASE_URL`。不将 Token 写进命令、项目文件、Git 或截图。

## 1. 选择并导出

```powershell
py 工具/配置补丁联调/phase1.py discover
py 工具/配置补丁联调/phase1.py export --bot-id <当前列表明确选定的BotID> --output <私有任务目录>
```

导出校验响应头、ZIP 摘要、Manifest、四项来源指纹与跨平台原路径。失败即停止并反馈管理员；不得映射、改名或转义。原始 ZIP 与 `平台基线/<Release>/extracted` 原样留存，只修改 `当前工作区`。已有基线和工作副本不会覆盖。

## 2. 本地打包与分步调用

以下 `state.json` 放在私有任务目录；`prepare` 生成固定 ZIP 和五个持久幂等键，重试同一操作必须保留该状态文件。R5 是示例，实际以本次导出的 Release 为准。

```powershell
py 工具/配置补丁联调/phase2.py prepare --state <私有任务目录>/state.json --bot-id <BotID> --baseline <私有任务目录>/平台基线/R5/extracted --work <私有任务目录>/当前工作区
py 工具/配置补丁联调/phase2.py online-baseline --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py diff --state <私有任务目录>/state.json
```

预检有效期过后，若原上传仍有效且线上基线、Bot 绑定及配置上下文未变化，可沿用原 `state.json` 和 uploadId 执行 `renew-precheck`。工具会重新核对归档 ZIP 与线上状态，保留旧预检历史，生成新的预检及发布幂等键；之后重新查询 diff 并人工确认，不能沿用过期的 precheckId 或原 diff 确认结果。

```powershell
py 工具/配置补丁联调/phase2.py renew-precheck --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py diff --state <私有任务目录>/state.json
```

`prepare` 检查 Manifest 未变、`change-plan.yaml` 包含模板规定的需求、四组件、协同、验证和能力申请字段，基线及组件声明对应实际改动，没有越界文件，并生成可移植 ZIP。有测试反馈时，先汇总、修复、回归并让用户确认本批反馈已收口。上传前重新核对 Agent Profile 和能力目录版本；变化后重新导出。上传后先查线上 Release 未变化。预检必须 `PREPARED`、`canPublish=true`、`blockers=[]`；diff 必须恰好展示四组件的摘要、changed 和文件清单，且与本地相符。工具把核对过的完整 diff 留在私有状态文件中，同一预检的重复查询若改变即停止。人工阅读完整 diff、业务规则和预期影响后，向用户展示环境、Bot、变更范围、影响和当前 diff，单独取得本次 Bot 发布确认，才可使用显示的 `diffDigest` 调用发布。预检续期、基线或 diff 变化后重新核对并再次确认：

原本没有标签时，`customer-service/tag-schema.json` 的 `{"config":null}` 是规范空值；不要自行补默认标签，已有标签也不能改成 `null` 来删除。仅排障用的无组件改动控制样本可在 `prepare` 时添加 `--no-change-diagnostic`；工具会在状态中标记并拒绝 `publish`。正常配置变更仍须有真实组件差异。

```powershell
py 工具/配置补丁联调/phase2.py publish --state <私有任务目录>/state.json --confirm-diff sha256:<diffDigest>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

operation 为 `ACTIVE` 且新 Release、四项摘要和配置上下文核对后，按本次范围另记真人企微对话和发送回执结果；Codex 分角色模拟不能替代。需要回退时，目标必须是本次保存的起始 Release；回退会产生新 Release：

```powershell
py 工具/配置补丁联调/phase2.py rollback --state <私有任务目录>/state.json --release-id <起始Release>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json --operation-id <回退operationId>
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <回退生成的新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

回退前工具核对发布 operation 已 `ACTIVE` 且 Release 历史没有更新版本；回退后再做真实会话和回执验证。能力缺口按官方 JSON 契约写在私有文件后执行 `capability --request-file <路径>`，用 `capability-status` 查询；收到能力目录升级后重新发现、导出和规划。

网络结果不明时先查询已保存的 upload/precheck/operation ID；必要重放使用 `state.json` 原键与原包，不生成新状态文件。预检有 blocker 时，工具在私有状态和终端保留 `precheckId`、状态及 blocker 的 `code`、`path`、`message`、`missingItems`，据此向管理员反馈；不记录 Token 或完整响应正文。`RECOVERY_REQUIRED`、绑定变化、基线冲突、预检 blocker、diff 越界时停止发布并交管理员处理。工具拒绝非官方测试环境写入；正式环境的关闭状态由管理员按联调单验证，不能用测试 Token 混用正式环境。

测试：`py -m unittest discover -s 工具/配置补丁联调 -p 'test_*.py'`。
