# AI 客服配置补丁 API 文档（调用方 AI）

> 状态：完整写入闭环正式契约；测试环境开放写接口，正式环境默认只读。
>
> 配套：[调用方 AI 开发决策指南](./caller-ai-development-decision-guide.zh-CN.md) · [完整联调执行单](./调用方AI第二阶段完整联调执行单.md)

## 1. 接入边界与兼容性

调用方只访问 `worktool-bot-service` 所属的配置补丁 API，不直接访问 DClaw 或 AI 客服内部接口。现有第一阶段的 Base URL、Token、请求头、五个只读接口、响应字段和 R1～R5 工作包继续有效；第二阶段只在导出之后增加上传、预检、差异、发布、查询、回退和能力申请。

调用方只选择 `botId`。服务端解析绑定的 `agentId`，并强制校验工作包内 Agent ID 与当前绑定一致。Agent 首次安装仍必须由 DClaw 管理员完成；员工接口只能更新已完成 OpenAPI、计费账户和经验库关联且可正常对话的 Agent。

## 2. 环境、Base URL 与 Token

| 环境 | Base URL | 写入状态 | Token |
| --- | --- | --- | --- |
| 测试 | `https://worktool-test.deepmega.cn` | 开放，用于完整联调 | 仅测试后台创建的 Token |
| 正式 | `https://worktool.deepmega.cn` | 默认关闭，只读 | 仅正式后台创建的 Token |

测试 Token 与正式 Token 互不认可。切换环境必须同时切换 Base URL 与 Token，并重新调用 `whoami`、能力目录、Bot 列表和配置上下文。两套 AI 客服连接同一套 DClaw；业务侧应使用不同 Bot 和 Agent 隔离。如主动共用同一 Agent，更新继续遵循 DClaw 既有的共同维护语义。

```bash
export CONFIG_PATCH_BASE_URL="https://worktool-test.deepmega.cn"
export CONFIG_PATCH_STAFF_TOKEN="<安全渠道取得的测试 Token>"
```

所有员工请求携带：

```http
Authorization: Bearer <员工 Codex Token>
```

所有改变数据的请求还要携带唯一且可重放的：

```http
Idempotency-Key: <本次业务操作的稳定键>
```

同键同请求返回原结果；同键不同请求返回 `409 / IDEMPOTENCY_KEY_REUSED`。不要在 URL、日志、Git、聊天或截图中保存 Token。

## 3. 完整接口清单

### 3.1 已联通且保持不变的只读接口

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/staff/v1/whoami` | 验证环境、Token 与员工身份 |
| `GET` | `/staff/v1/capabilities` | 获取动态能力目录和普通/超级专家 Profile |
| `GET` | `/staff/v1/bots` | 获取本环境全部 Bot |
| `GET` | `/staff/v1/bots/{botId}/configuration-context` | 获取绑定、状态机、标签和就绪状态 |
| `POST` | `/staff/v1/bots/{botId}/workspace-bundles/export` | 导出可信、Windows 可直接解压的基线工作包 |

### 3.2 新增写入闭环接口

| 方法 | 路径 | 是否改变线上配置 |
| --- | --- | --- |
| `POST` | `/staff/v1/bots/{botId}/workspace-bundles/uploads` | 否 |
| `GET` | `/staff/v1/bots/{botId}/workspace-bundles/uploads/{uploadId}` | 否 |
| `POST` | `/staff/v1/bots/{botId}/releases/prechecks` | 否 |
| `GET` | `/staff/v1/bots/{botId}/releases/prechecks/{precheckId}` | 否 |
| `GET` | `/staff/v1/bots/{botId}/releases/prechecks/{precheckId}/diff` | 否 |
| `POST` | `/staff/v1/bots/{botId}/releases` | 是 |
| `GET` | `/staff/v1/bots/{botId}/operations/{operationId}` | 否 |
| `GET` | `/staff/v1/bots/{botId}/releases` | 否 |
| `GET` | `/staff/v1/bots/{botId}/releases/{releaseId}` | 否 |
| `POST` | `/staff/v1/bots/{botId}/releases/{releaseId}/rollback` | 是，生成新的 Release |
| `POST` | `/staff/v1/platform-capability-requests` | 仅创建申请记录 |
| `GET` | `/staff/v1/platform-capability-requests/{requestId}` | 否 |

## 4. 固定执行顺序

```text
whoami → capabilities → bots → configuration-context → export
→ 本地只改工作副本并填写 change-plan.yaml
→ upload → precheck → diff → 人工确认 → publish
→ operation 查询 → Release 回读 → 真实对话验证
→ 必要时 rollback → 新 Release 回读
```

上传和预检绝不改变线上配置。只有 publish 和 rollback 会写入。预检结果有有效期；过期、Bot 绑定变化、基线变化或任一来源指纹变化后必须重新导出，不允许自动覆盖。

## 5. 上传工作包

```http
POST /staff/v1/bots/{botId}/workspace-bundles/uploads
Content-Type: multipart/form-data
Idempotency-Key: upload-<稳定任务ID>
```

```bash
curl --fail-with-body -X POST \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  -H "Idempotency-Key: task-20261003-upload-1" \
  -F "file=@workspace-modified.zip;type=application/zip" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots/$BOT_ID/workspace-bundles/uploads"
```

成功为 HTTP `201`：

```json
{
  "uploadId": "upload_xxx",
  "botId": "blackbox-wuhe-aigc-phase1",
  "agentId": "wuhe_aigc_service_phase1_test",
  "baseReleaseId": "R5",
  "archiveDigest": "sha256:...",
  "componentDigests": {
    "agent": "sha256:...",
    "knowledge": "sha256:...",
    "flowMachine": "sha256:...",
    "tags": "sha256:..."
  },
  "status": "validated"
}
```

服务端拒绝路径穿越、绝对路径、链接、大小写碰撞、Windows 非法路径、异常压缩比、摘要不符、Bot/Agent/baseRelease 不匹配。调用方不得改写 Manifest 的 Bot、Agent 或来源指纹。

## 6. 预检与差异

```http
POST /staff/v1/bots/{botId}/releases/prechecks
Idempotency-Key: precheck-<稳定任务ID>
Content-Type: application/json

{"uploadId":"upload_xxx"}
```

成功且允许发布：

```json
{
  "precheckId": "precheck_xxx",
  "botId": "...",
  "uploadId": "upload_xxx",
  "status": "PREPARED",
  "canPublish": true,
  "blockers": [],
  "diff": {"schemaVersion":"config-patch-diff.v1","components":{}},
  "expiresAt": "2026-10-03T12:15:00Z"
}
```

随后调用 diff 接口，必须展示四组件的 `changed`、`oldDigest`、`newDigest` 和文件列表，并与 `change-plan.yaml` 逐项核对。`canPublish=false` 时不得调用发布。

## 7. 发布、查询与回读

```http
POST /staff/v1/bots/{botId}/releases
Idempotency-Key: publish-<稳定任务ID>
Content-Type: application/json

{"precheckId":"precheck_xxx"}
```

返回 `ReleaseOperation`：

```json
{
  "operationId": "operation_xxx",
  "botId": "...",
  "operationType": "publish",
  "status": "ACTIVE",
  "precheckId": "precheck_xxx",
  "errorCode": null,
  "metadata": {"releaseId":"R6","step":"complete"}
}
```

状态只使用 `PRECHECKING`、`PREPARED`、`COMMITTING`、`ACTIVE`、`ABORTING`、`ABORTED`、`RECOVERY_REQUIRED`。结果不明时使用 operation 查询；不得用新的幂等键盲目重发。`ACTIVE` 后读取 `metadata.releaseId`，再调用 Release 列表和详情验证四项摘要。

发布期间服务只暂停目标 Bot 的新消息，等待已开始的单次处理结束；其他 Bot 不受影响。DClaw 与 AI 客服任一环节失败时执行补偿恢复，不能把半完成状态报告为成功。

## 8. 回退

```http
POST /staff/v1/bots/{botId}/releases/{targetReleaseId}/rollback
Idempotency-Key: rollback-<稳定任务ID>
```

回退不是把旧行改回 Active，而是按同一发布流程创建新的 Release。例如 R6 回退到 R5 后生成 R7。回退完成后同样要查询 operation、R7 详情并做真实对话验证。

## 9. 平台能力申请

能力目录不支持需求时停止实现，不伪造能力。提交：

```http
POST /staff/v1/platform-capability-requests
Idempotency-Key: capability-<稳定任务ID>
Content-Type: application/json
```

```json
{
  "businessRequirement": "业务要实现什么",
  "blocker": "当前能力为何阻断",
  "affectedModules": ["agent", "stateMachine"],
  "proposedContract": "建议输入、输出和一致性语义",
  "compatibilityRequirements": "哪些既有机制必须保持不变",
  "acceptanceCases": ["验收案例一", "验收案例二"]
}
```

平台更新后重新获取能力目录并重新导出，不在旧工作包上继续发布。

## 10. 稳定错误码与处理

| HTTP | code | 调用方处理 |
| ---: | --- | --- |
| 401 | `STAFF_TOKEN_REQUIRED` / `INVALID_STAFF_TOKEN` / `STAFF_TOKEN_EXPIRED` / `STAFF_TOKEN_REVOKED` | 停止，核对环境或申请新 Token |
| 404 | `CONFIG_PATCH_BOT_NOT_FOUND` / `WORKSPACE_UPLOAD_NOT_FOUND` / `PRECHECK_NOT_FOUND` / `OPERATION_NOT_FOUND` / `RELEASE_NOT_FOUND` | 停止，重新读取目标或 ID |
| 409 | `AGENT_ID_MISMATCH` / `TARGET_BINDING_CHANGED` | 停止，让员工重新确认 Bot |
| 409 | `BASE_RELEASE_CHANGED` / `SOURCE_FINGERPRINT_CHANGED` | 重新导出新基线并重做变更 |
| 409 | `IDEMPOTENCY_KEY_REUSED` | 修复调用方幂等键复用错误 |
| 409 | `RELEASE_IN_PROGRESS` | 查询正在进行的 operation，不并发发布 |
| 422 | `CONFIGURATION_INVALID` / `CHANGE_PLAN_MISMATCH` | 修复工作包后重新上传与预检 |
| 503 | `CONFIG_PATCH_WRITES_DISABLED` | 当前环境只读；不得绕过 |
| 503 | `DCLAW_UPSTREAM_UNAVAILABLE` / `OMNICHANNEL_UPSTREAM_UNAVAILABLE` | 保留操作 ID，退避后查询 |

FastAPI 错误结构为 `{"detail":{"code":"..."}}`。操作自身失败则通过 `status` 与 `errorCode` 返回。调用方只能按机器码分支，不解析自由文本。

## 11. 超时、重试和安全

- JSON 读取：连接 10 秒，总超时 30 秒；导出、预检、发布、回退总超时建议 180 秒。
- `401/404/409/422` 不自动重试。
- 网络结果不明时，同一请求只能用同一个 `Idempotency-Key` 重放或查询 operation。
- 不访问 `/internal/*`，不获取 DClaw 或 AI 客服内部密钥。
- 不修改工作包内 `sessions_data` 等运行态目录；服务端不会用工作包覆盖运行态。
- 发布后必须分别验证 Release 摘要、配置回读、真实对话与渠道回执。

## 12. 最小 Python 调用骨架

```python
import os
import requests

base = os.environ["CONFIG_PATCH_BASE_URL"].rstrip("/")
token = os.environ["CONFIG_PATCH_STAFF_TOKEN"]
session = requests.Session()
session.headers["Authorization"] = f"Bearer {token}"

identity = session.get(f"{base}/staff/v1/whoami", timeout=30)
identity.raise_for_status()

# 每个改变数据的业务动作使用独立、稳定的 Idempotency-Key。
# 上传使用 files=；其余请求使用 json=。不要关闭 TLS 校验。
```

完整顺序与验收记录字段见配套联调执行单。

