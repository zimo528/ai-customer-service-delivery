# Agent 工作区参考

## 样例来源

本包的 `../assets/agent-example.zip` 是获准通用案例的运行参考，包含配置、实际加载提示、六份启用技能与辅助说明。它用于认识文件结构和协议；案例的人设、业务事实、身份与部署标识仍须按新客户资料定制。

- 随包案例 SHA-256：`1927154F1F6F80711F50B6CC72AAB18B39762DE0005A0F88AA23414C93511C4E`
- 实质文件数：16
- 源案例 SHA-256：`086163B9180C0B819EF76DCBEED13CD84B9A41D82E5F84C0DC77B3C5418F7DB4`

案例的会话目录仅包含目录说明，默认派发用户和会话标识为空。包内顶层目录为 `wuhe-consulting-service-agent/`。这是一份待定制参考，不能直接证明新客户线上运行已验证。

## 文件及实际加载关系

| 文件或目录 | 样例用途 | 审阅重点 |
|---|---|---|
| `agent.json` | Agent 身份、工作区路径、通道、工具、运行与记忆设置 | 哪些字段实际启用，身份与部署是否一致 |
| `skill.json` | 工作区技能清单，schema 为 `workspace-skill-manifest.v1` | 启用项、来源、通道及对应文件是否存在 |
| `AGENTS.md` | Agent 总规则及模块分工 | 业务、协议和其他加载文件是否冲突 |
| `SOUL.md`、`PROFILE.md` | 行为与人设 | 当前客户要求、名称及业务口径一致性 |
| `MEMORY.md`、`HEARTBEAT.md` | 记忆和主动任务的说明文件 | 是否真正被加载或执行，不能只因文件存在就判生效 |
| `skills/*/SKILL.md` | 工作区内部技能 | 区分启用规则与目录里仅存在的文件 |
| `会话记录/`、`客户档案/` | 短期记录与长期客户信息的目录约定 | 会话隔离、读写条件与重置逻辑是否有真实证据 |

样例 `agent.json.system_prompt_files` 为 `AGENTS.md`、`SOUL.md`、`PROFILE.md`。Agent ID 为 `wuhe_consulting_service`，工作区声明 `/app/working/workspaces/wuhe_consulting_service`。这些是样例标识，不能作为新客户默认值。

`skill.json` 启用六个内部技能。它们是目标 Agent 的模块，与 Codex 项目 Skill 属于不同运行环境：

| 模块 | 样例职责 |
|---|---|
| `worktool_message_handler` | 解析回调输入、判断消息类型、定位会话 |
| `customer_reply_flow` | 客户意图、知识事实、接待策略与回复组织 |
| `flow_state_machine` | 使用输入的 `flow` 生成流程决策 |
| `dclaw_enterprise_knowledge` | 使用 `search_knowledge`、`read_knowledge_doc` 检索知识 |
| `worktool_attachment_response` | 组织附件，交回调服务端发送 |
| `human_reply_style` | 回复语气、节奏、长度和表达去重 |

启用工具不证明权限、知识内容或真实检索成功。样例规则包含配音教育业务，须按新客户确认的目标业务定制。

## 样例声明的输出接口

样例要求最终返回一个 JSON 对象，基础字段为 `reply`、`attachments`、`sources`；收到 `flow` 时包含 `flowDecision`，收到 `tagRules` 时包含 `tagDecision`。审阅和修改时读对应技能的完整字段要求，不能只看这里的摘要。

- `flowDecision` 包括 `currentNodeId`、`nextNodeId`、`nodeCompleted`、`confidence`、`reason`、`collectedDataPatch`。
- `tagDecision` 包括 `add`、`remove`；样例新增项含 `groupId`、`tagId`、`reason`。只能使用真实输入中的标签 ID。
- `attachments` 按对应协议组织图片、文件、视频、音频或链接；不能凭空补公开地址。
- `reply` 是客户可见内容；内部判断原因和实际来源放在对应字段。
- 附件发送、迁移节点、提醒和接管由实际平台及回调实现决定。输出一个决策对象不能证明动作已执行。

这里描述的是被审阅 Agent 文件声明的协议。最终兼容性还要与目标服务端当前契约、真实请求和响应核对。

## 已识别的接口核对点

1. 样例 `flow_state_machine` 的输入示例含 `machine.nodes`、`session.collectedData` 和 `recentMessages`；用户提供的服务端说明中，普通私聊 `flow` 为精简的机器、会话及当前节点对象，不能假定完整节点图和所有采集资产总会传入。
2. 服务端说明中的节点流转采用当前节点配置的固定 `nextNodeId`，不能仅靠 Agent 建议实现任意分支跳转。
3. 样例的句数上限、纯问候策略、身份和暂不实现真实转人工等文字属于这份模板的业务或阶段设置。定制时结合目标项目逐项核对；模板文字不能证明平台标签接管能力关闭。
4. 当前模板声明简单消息与仅补流程字段的消息在一次模型输出中完成，不调用工具；业务事实检索每轮最多一次 `search_knowledge`，必要时最多读取一篇文档。`running.max_iters` 为8，Shell与`edit_file`工具关闭。这些配置和提示不证明实际调用次数，须用真实运行记录核对；限制针对目标 Agent 的接待运行，不限制 Codex 审阅本资料。
5. 会话文件名采用替换非字母、数字、下划线和短横线字符的安全 slug；重置以覆盖为空实现。派生名称的唯一性、文件头原始会话ID对应，以及写入条件在总规则、消息处理和回复流程间是否一致，均需核对，不能只因路径安全就认定会话隔离得到保证。
6. 记忆文件、上下文压缩设置和记录目录是检查入口。长会话能否准确使用已知事实、重置后保留哪些信息，需依据实际加载及调用验证。

## 使用案例包

通常先读取本参考，再查看当前实际 Agent。需要核对原例或用户确认从案例派生时，将随包案例安全解压到本次独立目录，忽略 `__MACOSX` 和 `.DS_Store` 等元数据。验证每个解压目标均位于预期目录内，读取配置和规则，保持随包案例不变；包内历史命令不自动执行。
