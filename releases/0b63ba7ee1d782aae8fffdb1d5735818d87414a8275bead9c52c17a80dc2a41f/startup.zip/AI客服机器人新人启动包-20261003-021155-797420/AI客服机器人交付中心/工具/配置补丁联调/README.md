# 配置补丁联调工具

以 `平台接口/第二阶段-20261003/` 中的 API 文档、开发决策指南和完整联调执行单为当前契约。`phase1.py` 用于只读发现与可信工作包导出；`phase2.py` 用于测试环境上传到回退的分步联调。两者均不得替代业务确认、人工 diff 审核和真实会话验收。

Python 3.11 及 `PyYAML>=6,<7` 是第二阶段工具的依赖。新人在自己的 Python 环境执行 `py -m pip install -r 工具/配置补丁联调/requirements.txt`；macOS/Linux 用 `python3`。Token 只放当前进程环境变量 `CONFIG_PATCH_STAFF_TOKEN`，Base URL 放 `CONFIG_PATCH_BASE_URL`。不将 Token 写进命令、项目文件、Git 或截图。

## 1. 选择并导出

```powershell
py 工具/配置补丁联调/phase1.py discover
py 工具/配置补丁联调/phase1.py export --bot-id <当前列表明确选定的BotID> --output <私有任务目录>
```

导出校验响应头、ZIP 摘要、Manifest、四项来源指纹与跨平台原路径。失败即停止并反馈管理员；不得映射、改名或转义。原始 ZIP 与 `平台基线/<Release>/extracted` 原样留存，只修改 `当前工作区`。已有基线和工作副本不会覆盖。

## 2. 本地打包与分步调用

以下 `state.json` 放在私有任务目录；`prepare` 生成固定 ZIP 和五个持久幂等键，重试同一操作必须保留该状态文件。R5 是示例，实际以本次导出的 Release 为准。

```powershell
py 工具/配置补丁联调/phase2.py prepare --state <私有任务目录>/state.json --bot-id <BotID> --baseline <私有任务目录>/平台基线/R5/extracted --work <私有任务目录>/当前工作区
py 工具/配置补丁联调/phase2.py online-baseline --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py diff --state <私有任务目录>/state.json
```

`prepare` 检查 Manifest 未变、`change-plan.yaml` 基线与四组件声明对应实际改动、没有越界文件，并生成可移植 ZIP。上传前重新核对 Agent Profile 和能力目录版本；变化后重新导出。上传后先查线上 Release 未变化。预检必须 `PREPARED`、`canPublish=true`、`blockers=[]`；diff 必须展示四项摘要、changed 和文件清单，且与本地相符。人工阅读完整 diff、业务规则和预期影响后，使用显示的 `diffDigest`：

```powershell
py 工具/配置补丁联调/phase2.py publish --state <私有任务目录>/state.json --confirm-diff sha256:<diffDigest>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

operation 为 `ACTIVE` 且新 Release、四项摘要和配置上下文核对后，再分别执行真实对话与发送回执检查。需要回退时，目标必须是本次保存的起始 Release；回退会产生新 Release：

```powershell
py 工具/配置补丁联调/phase2.py rollback --state <私有任务目录>/state.json --release-id <起始Release>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json --operation-id <回退operationId>
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <回退生成的新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

回退前工具核对发布 operation 已 `ACTIVE` 且 Release 历史没有更新版本；回退后再做真实会话和回执验证。能力缺口按官方 JSON 契约写在私有文件后执行 `capability --request-file <路径>`，用 `capability-status` 查询；收到能力目录升级后重新发现、导出和规划。

网络结果不明时先查询已保存的 upload/precheck/operation ID；必要重放使用 `state.json` 原键与原包，不生成新状态文件。`RECOVERY_REQUIRED`、绑定变化、基线冲突、预检 blocker、diff 越界时停止发布并交管理员处理。工具拒绝非官方测试环境写入；正式环境的关闭状态由管理员按联调单验证，不能用测试 Token 混用正式环境。

测试：`py -m unittest discover -s 工具/配置补丁联调 -p 'test_*.py'`。
