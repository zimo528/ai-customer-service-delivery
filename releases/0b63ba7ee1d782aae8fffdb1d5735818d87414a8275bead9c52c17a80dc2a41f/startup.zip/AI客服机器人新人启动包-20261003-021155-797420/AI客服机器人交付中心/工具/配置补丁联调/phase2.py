"""Stepwise client for the test-environment config patch release loop."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import re
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
import uuid
import zipfile

import yaml

from phase1 import validate_zip_members


TEST_BASE = "https://worktool-test.deepmega.cn"
COMPONENTS = ("agent", "knowledge", "flowMachine", "tags")


class PatchError(Exception):
    pass


def digest(data: bytes) -> str:
    return "sha256:" + sha256(data).hexdigest()


def save(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def load(path: Path) -> dict:
    if not path.is_file():
        raise PatchError(f"state file missing: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def require_test(base: str) -> None:
    if base.rstrip("/") != TEST_BASE:
        raise PatchError("write loop is restricted to the documented test environment")


def request(base: str, token: str, method: str, path: str, *, payload=None, key=None, archive=None):
    headers = {"Authorization": f"Bearer {token}"}
    body = None
    if key:
        headers["Idempotency-Key"] = key
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if archive is not None:
        boundary = "config-patch-" + uuid.uuid4().hex
        body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
                f"filename=\"workspace.zip\"\r\nContent-Type: application/zip\r\n\r\n").encode() \
            + archive + f"\r\n--{boundary}--\r\n".encode()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    req = Request(base.rstrip("/") + "/staff/v1" + path, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=180 if method == "POST" else 30) as response:
            result = json.load(response)
    except HTTPError as error:
        try:
            detail = json.load(error).get("detail", {})
        except (ValueError, AttributeError):
            detail = {}
        code = detail.get("code") if isinstance(detail, dict) else None
        raise PatchError(f"HTTP {error.code} detail.code={code}; {method} {path}") from None
    except (URLError, TimeoutError, OSError) as error:
        raise PatchError(f"result unknown for {method} {path}; reuse the saved key or query status ({type(error).__name__})") from None
    if not isinstance(result, (dict, list)):
        raise PatchError(f"unexpected response for {method} {path}")
    return result


def file_map(root: Path) -> dict[str, bytes]:
    if not root.is_dir():
        raise PatchError(f"directory missing: {root}")
    result = {}
    for path in root.rglob("*"):
        if path.is_symlink():
            raise PatchError(f"symlink is not allowed: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = path.read_bytes()
    return result


def component(path: str) -> str | None:
    if path.startswith("agent/"):
        return "agent"
    if path.startswith("knowledge/"):
        return "knowledge"
    if path == "customer-service/flow-machine.json":
        return "flowMachine"
    if path == "customer-service/tag-schema.json":
        return "tags"
    return None


def validate_plan_and_files(baseline: Path, work: Path, bot_id: str) -> tuple[dict, dict, list]:
    old, new = file_map(baseline), file_map(work)
    original_zip = baseline.parent / "workspace.zip"
    if not original_zip.is_file():
        raise PatchError("original exported ZIP missing beside baseline")
    with zipfile.ZipFile(original_zip) as archive:
        validate_zip_members(archive)
        exported = {info.filename: archive.read(info) for info in archive.infolist() if not info.is_dir()}
    if exported != old:
        raise PatchError("baseline differs from original exported ZIP")
    if "dclaw-manifest.json" not in old or old.get("dclaw-manifest.json") != new.get("dclaw-manifest.json"):
        raise PatchError("Manifest changed or missing")
    manifest = json.loads(new["dclaw-manifest.json"])
    if manifest.get("botId") != bot_id:
        raise PatchError("Manifest Bot differs from selected Bot")
    if not all(manifest.get(key) for key in ("agentId", "agentProfileId", "capabilityCatalogVersion", "baseReleaseId")):
        raise PatchError("Manifest identity, Profile, catalog or Release missing")
    if "change-plan.yaml" not in new:
        raise PatchError("change-plan.yaml missing")
    plan = yaml.safe_load(new["change-plan.yaml"])
    if not isinstance(plan, dict) or plan.get("schemaVersion") != "customer-service-change-plan.v1":
        raise PatchError("unsupported change plan")
    if plan.get("baseReleaseId") != manifest["baseReleaseId"]:
        raise PatchError("change-plan baseReleaseId differs from Manifest")
    changes = plan.get("changes")
    if not isinstance(changes, dict) or any(not isinstance(changes.get(c), list) for c in
                                              ("agent", "knowledge", "stateMachine", "tags")):
        raise PatchError("change plan must declare all four components")
    actual = []
    for name in sorted(old.keys() | new.keys()):
        if old.get(name) == new.get(name):
            continue
        if name == "change-plan.yaml":
            continue
        part = component(name)
        if part is None:
            raise PatchError(f"change outside editable components: {name}")
        actual.append({"path": name, "component": part,
                       "action": "added" if name not in old else "deleted" if name not in new else "modified"})
    for part, plan_key in (("agent", "agent"), ("knowledge", "knowledge"),
                           ("flowMachine", "stateMachine"), ("tags", "tags")):
        if bool(changes[plan_key]) != any(item["component"] == part for item in actual):
            raise PatchError(f"change-plan declaration differs from actual {part} files")
    if not actual:
        raise PatchError("no component files changed")
    return manifest, plan, actual


def make_archive(work: Path) -> bytes:
    files = file_map(work)
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    data = memory.getvalue()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        validate_zip_members(archive)
        if archive.testzip() is not None:
            raise PatchError("archive CRC failed")
    return data


def prepare(args) -> dict:
    require_test(args.base_url)
    manifest, _, changed = validate_plan_and_files(args.baseline, args.work, args.bot_id)
    archive = make_archive(args.work)
    state_path = args.state
    if state_path.exists():
        raise PatchError("state already exists; retain it for idempotent continuation")
    archive_path = state_path.with_suffix(".zip")
    if archive_path.exists():
        raise PatchError("prepared ZIP already exists")
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    archive_path.write_bytes(archive)
    state = {"baseUrl": args.base_url, "botId": args.bot_id, "agentId": manifest["agentId"],
             "agentProfileId": manifest["agentProfileId"], "catalogVersion": manifest["capabilityCatalogVersion"],
             "baseReleaseId": manifest["baseReleaseId"], "sourceFingerprints": manifest["sourceFingerprints"],
             "archive": str(archive_path.resolve()), "archiveDigest": digest(archive),
             "changed": changed, "keys": {name: str(uuid.uuid4()) for name in
                                       ("upload", "precheck", "publish", "rollback", "capability")}}
    save(state_path, state)
    return {k: state[k] for k in ("botId", "agentId", "baseReleaseId", "archive", "archiveDigest", "changed")}


def checked_state(path: Path, base: str) -> dict:
    require_test(base)
    state = load(path)
    if state.get("baseUrl") != base:
        raise PatchError("environment changed since preparation")
    return state


def bot_path(state: dict) -> str:
    return "/bots/" + quote(state["botId"], safe="")


def ensure_live_target(state: dict, token: str, *, check_catalog=True) -> None:
    base = state["baseUrl"]
    identity = request(base, token, "GET", "/whoami")
    if not identity.get("tokenId"):
        raise PatchError("whoami failed")
    listing = request(base, token, "GET", "/bots").get("bots", [])
    bot = next((b for b in listing if b.get("botId") == state["botId"]), None)
    if not bot or bot.get("boundAgentId") != state["agentId"] or (bot.get("readiness") or {}).get("ready") is not True:
        raise PatchError("Bot binding or readiness changed")
    if state.get("agentProfileId") and bot.get("agentProfileId") != state["agentProfileId"]:
        raise PatchError("Bot Agent Profile changed")
    if check_catalog and state.get("catalogVersion"):
        catalog = request(base, token, "GET", "/capabilities")
        if catalog.get("version") != state["catalogVersion"] or state.get("agentProfileId") not in catalog.get("profiles", {}):
            raise PatchError("capability catalog changed; re-export before writing")
    context = request(base, token, "GET", bot_path(state) + "/configuration-context")
    if context.get("boundAgentId") != state["agentId"] or context.get("botId") != state["botId"]:
        raise PatchError("configuration context binding changed")
    if state.get("agentProfileId") and context.get("agentProfileId") != state["agentProfileId"]:
        raise PatchError("configuration context Agent Profile changed")


def compare_diff(state: dict, diff: dict) -> str:
    if diff.get("schemaVersion") != "config-patch-diff.v1":
        raise PatchError("unsupported server diff schema")
    components = diff.get("components")
    if not isinstance(components, dict) or set(COMPONENTS) - set(components):
        raise PatchError("diff is missing one or more components")
    for part in COMPONENTS:
        item = components[part]
        expected = any(change["component"] == part for change in state["changed"])
        if not isinstance(item, dict) or item.get("changed") is not expected:
            raise PatchError(f"server diff differs from local change plan: {part}")
        if not all(re.fullmatch(r"sha256:[0-9a-f]{64}", str(item.get(key, "")))
                   for key in ("oldDigest", "newDigest")) or not isinstance(item.get("files"), list):
            raise PatchError(f"server diff lacks digest or file list: {part}")
        if (item["oldDigest"] != item["newDigest"]) is not expected:
            raise PatchError(f"server diff digest transition differs from changed flag: {part}")
        paths = set()
        for file in item["files"]:
            path = file if isinstance(file, str) else file.get("path") if isinstance(file, dict) else None
            if not isinstance(path, str):
                raise PatchError(f"server diff file entry invalid: {part}")
            paths.add(path)
        local = {change["path"] for change in state["changed"] if change["component"] == part}
        # The server lists all files in each component, including unchanged files.
        if not local <= paths:
            raise PatchError(f"server diff file list omits local changes: {part}")
    return digest(json.dumps(diff, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def run(args) -> dict:
    if args.command == "prepare":
        return prepare(args)
    state = checked_state(args.state, args.base_url)
    token = os.environ.get("CONFIG_PATCH_STAFF_TOKEN", "")
    if not token:
        raise PatchError("CONFIG_PATCH_STAFF_TOKEN is required in the process environment")
    base, bot = state["baseUrl"], bot_path(state)
    if args.command == "upload":
        if not state.get("onlineContextDigest"):
            raise PatchError("capture online-baseline before upload")
        ensure_live_target(state, token)
        archive = Path(state["archive"]).read_bytes()
        if digest(archive) != state["archiveDigest"]:
            raise PatchError("prepared archive changed")
        result = request(base, token, "POST", bot + "/workspace-bundles/uploads",
                         archive=archive, key=state["keys"]["upload"])
        if result.get("botId") != state["botId"] or result.get("agentId") != state["agentId"] or \
                result.get("baseReleaseId") != state["baseReleaseId"] or \
                result.get("archiveDigest") != state["archiveDigest"]:
            raise PatchError("upload response identity or digest mismatch")
        state["uploadId"] = result["uploadId"]
        save(args.state, state)
        return result
    if args.command == "online-baseline":
        if state.get("uploadId"):
            raise PatchError("online baseline must be captured before upload")
        ensure_live_target(state, token)
        context = request(base, token, "GET", bot + "/configuration-context")
        state["onlineContextDigest"] = digest(json.dumps(context, sort_keys=True, ensure_ascii=False).encode("utf-8"))
        state["onlineReleaseId"] = context.get("currentReleaseId")
        save(args.state, state)
        return {"currentReleaseId": state["onlineReleaseId"], "contextDigest": state["onlineContextDigest"]}
    if args.command == "online-unchanged":
        if not state.get("onlineContextDigest"):
            raise PatchError("capture online-baseline first")
        context = request(base, token, "GET", bot + "/configuration-context")
        current_digest = digest(json.dumps(context, sort_keys=True, ensure_ascii=False).encode("utf-8"))
        if current_digest != state["onlineContextDigest"]:
            raise PatchError("online configuration changed after baseline capture")
        return {"unchanged": True, "currentReleaseId": context.get("currentReleaseId"), "contextDigest": current_digest}
    if args.command == "precheck":
        if not state.get("uploadId"):
            raise PatchError("upload first")
        ensure_live_target(state, token)
        result = request(base, token, "POST", bot + "/releases/prechecks",
                         payload={"uploadId": state["uploadId"]}, key=state["keys"]["precheck"])
        state["precheckId"] = result.get("precheckId")
        save(args.state, state)
        if result.get("status") != "PREPARED" or result.get("canPublish") is not True or result.get("blockers"):
            codes = [blocker.get("code") for blocker in result.get("blockers", []) if isinstance(blocker, dict)]
            raise PatchError(f"precheck status={result.get('status')} canPublish={result.get('canPublish')} blockerCodes={codes}")
        return result
    if args.command == "upload-status":
        if not state.get("uploadId"):
            raise PatchError("upload ID unavailable; retry only with saved original key and archive")
        return request(base, token, "GET", bot + "/workspace-bundles/uploads/" + quote(state["uploadId"], safe=""))
    if args.command == "precheck-status":
        if not state.get("precheckId"):
            raise PatchError("precheck ID unavailable; retry only with saved original key")
        return request(base, token, "GET", bot + "/releases/prechecks/" + quote(state["precheckId"], safe=""))
    if args.command == "diff":
        if not state.get("precheckId"):
            raise PatchError("precheck first")
        result = request(base, token, "GET", bot + "/releases/prechecks/" + quote(state["precheckId"], safe="") + "/diff")
        fingerprint = compare_diff(state, result)
        state["diffDigest"] = fingerprint
        save(args.state, state)
        return {"diffDigest": fingerprint, "components": result["components"], "changedLocalFiles": state["changed"]}
    if args.command == "publish":
        if not state.get("precheckId") or not state.get("diffDigest") or args.confirm_diff != state["diffDigest"]:
            raise PatchError("review diff and supply its exact digest")
        if state.get("publishOperationId"):
            return request(base, token, "GET", bot + "/operations/" + quote(state["publishOperationId"], safe=""))
        if state.get("publishAttemptedAt"):
            result = request(base, token, "POST", bot + "/releases",
                             payload={"precheckId": state["precheckId"]}, key=state["keys"]["publish"])
            state["publishOperationId"] = result.get("operationId")
            save(args.state, state)
            return result
        ensure_live_target(state, token)
        precheck_path = bot + "/releases/prechecks/" + quote(state["precheckId"], safe="")
        precheck = request(base, token, "GET", precheck_path)
        if precheck.get("status") != "PREPARED" or precheck.get("canPublish") is not True or precheck.get("blockers"):
            raise PatchError("precheck no longer permits publishing")
        expires = precheck.get("expiresAt")
        if not expires or datetime.fromisoformat(expires.replace("Z", "+00:00")) <= datetime.now(timezone.utc):
            raise PatchError("precheck expired")
        current_diff = request(base, token, "GET", precheck_path + "/diff")
        if compare_diff(state, current_diff) != state["diffDigest"]:
            raise PatchError("server diff changed since review")
        state["publishAttemptedAt"] = datetime.now(timezone.utc).isoformat()
        save(args.state, state)
        result = request(base, token, "POST", bot + "/releases",
                         payload={"precheckId": state["precheckId"]}, key=state["keys"]["publish"])
        state["publishOperationId"] = result.get("operationId")
        save(args.state, state)
        return result
    if args.command == "operation":
        operation_id = args.operation_id or state.get("rollbackOperationId") or state.get("publishOperationId")
        if not operation_id:
            raise PatchError("operation ID required")
        return request(base, token, "GET", bot + "/operations/" + quote(operation_id, safe=""))
    if args.command == "releases":
        return request(base, token, "GET", bot + "/releases" +
                       ("/" + quote(args.release_id, safe="") if args.release_id else ""))
    if args.command == "context":
        return request(base, token, "GET", bot + "/configuration-context")
    if args.command == "rollback":
        if not args.release_id or args.release_id != state["baseReleaseId"]:
            raise PatchError("rollback target must be the saved starting Release")
        if state.get("rollbackTargetReleaseId") and state["rollbackTargetReleaseId"] != args.release_id:
            raise PatchError("rollback target differs from saved attempted operation")
        if state.get("rollbackOperationId"):
            return request(base, token, "GET", bot + "/operations/" + quote(state["rollbackOperationId"], safe=""))
        if state.get("rollbackAttemptedAt"):
            result = request(base, token, "POST", bot + "/releases/" + quote(args.release_id, safe="") + "/rollback",
                             key=state["keys"]["rollback"])
            state["rollbackOperationId"] = result.get("operationId")
            save(args.state, state)
            return result
        if not state.get("publishOperationId"):
            raise PatchError("publish operation must be recorded before rollback")
        published = request(base, token, "GET", bot + "/operations/" + quote(state["publishOperationId"], safe=""))
        if published.get("status") != "ACTIVE" or not (published.get("metadata") or {}).get("releaseId"):
            raise PatchError("publish operation is not ACTIVE; inspect and recover before rollback")
        history = request(base, token, "GET", bot + "/releases")
        active = [release for release in history if isinstance(release, dict) and
                  release.get("status") == "ACTIVE" and isinstance(release.get("version"), int)]
        if not active or max(active, key=lambda release: release["version"]).get("releaseId") != published["metadata"]["releaseId"]:
            raise PatchError("a newer Release exists or Release history is incomplete; stop rollback")
        ensure_live_target(state, token, check_catalog=False)
        state["rollbackTargetReleaseId"] = args.release_id
        state["rollbackAttemptedAt"] = datetime.now(timezone.utc).isoformat()
        save(args.state, state)
        result = request(base, token, "POST", bot + "/releases/" + quote(args.release_id, safe="") + "/rollback",
                         key=state["keys"]["rollback"])
        state["rollbackOperationId"] = result.get("operationId")
        save(args.state, state)
        return result
    if args.command == "capability":
        payload = json.loads(args.request_file.read_text(encoding="utf-8"))
        required = {"businessRequirement", "blocker", "affectedModules", "proposedContract",
                    "compatibilityRequirements", "acceptanceCases"}
        if not required <= payload.keys():
            raise PatchError("capability request is missing required fields")
        payload_digest = digest(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8"))
        if state.get("capabilityPayloadDigest") and state["capabilityPayloadDigest"] != payload_digest:
            raise PatchError("capability payload changed since first request; use a new operation")
        if not state.get("capabilityPayloadDigest"):
            state["capabilityPayloadDigest"] = payload_digest
            save(args.state, state)
        result = request(base, token, "POST", "/platform-capability-requests",
                         payload=payload, key=state["keys"]["capability"])
        state["capabilityRequestId"] = result.get("requestId")
        save(args.state, state)
        return result
    if args.command == "capability-status":
        if not state.get("capabilityRequestId"):
            raise PatchError("capability request ID unavailable")
        return request(base, token, "GET", "/platform-capability-requests/" +
                       quote(state["capabilityRequestId"], safe=""))
    raise AssertionError(args.command)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "online-baseline", "online-unchanged",
                                            "upload", "upload-status", "precheck",
                                            "precheck-status", "diff", "publish", "operation", "releases",
                                            "context", "rollback", "capability", "capability-status"))
    parser.add_argument("--state", type=Path, required=True, help="private local operation state JSON")
    parser.add_argument("--base-url", default=os.environ.get("CONFIG_PATCH_BASE_URL", ""))
    parser.add_argument("--bot-id")
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--work", type=Path)
    parser.add_argument("--confirm-diff")
    parser.add_argument("--operation-id")
    parser.add_argument("--release-id")
    parser.add_argument("--request-file", type=Path)
    args = parser.parse_args()
    if args.command == "prepare" and not (args.bot_id and args.baseline and args.work):
        parser.error("prepare requires --bot-id, --baseline and --work")
    if args.command == "capability" and not args.request_file:
        parser.error("capability requires --request-file")
    try:
        print(json.dumps(run(args), ensure_ascii=False, indent=2))
    except (PatchError, ValueError, KeyError, OSError, zipfile.BadZipFile, yaml.YAMLError) as error:
        print(f"联调停止: {error}", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
