import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import phase2


MANIFEST = {"schemaVersion": "customer-service-workspace.v1", "botId": "practice",
            "agentId": "agent-practice", "baseReleaseId": "R5",
            "sourceFingerprints": {part: "sha256:" + "a" * 64 for part in ("agent", "knowledge", "flow", "tags")}}
PLAN = """schemaVersion: customer-service-change-plan.v1
baseReleaseId: R5
changes:
  agent: []
  knowledge: [Update FAQ]
  stateMachine: []
  tags: []
"""


class Phase2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.baseline = root / "baseline"
        self.work = root / "work"
        files = {
            "dclaw-manifest.json": json.dumps(MANIFEST), "AGENTS.md": "instructions",
            "change-plan.yaml": "baseReleaseId: R5", "knowledge/knowledge-manifest.json": "{}",
            "knowledge/documents/FAQ.md": "old", "customer-service/flow-machine.json": "{}",
            "customer-service/tag-schema.json": "{}", "platform/capability-catalog.json": "{}",
        }
        for target in (self.baseline, self.work):
            for name, body in files.items():
                path = target / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(body, encoding="utf-8")
        with zipfile.ZipFile(self.baseline.parent / "workspace.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for name in files:
                archive.write(self.baseline / name, name)
        (self.work / "change-plan.yaml").write_text(PLAN, encoding="utf-8")
        (self.work / "knowledge/documents/FAQ.md").write_text("new", encoding="utf-8")
        self.state = root / "operation.json"

    def args(self, command, **kw):
        values = dict(command=command, state=self.state, base_url=phase2.TEST_BASE,
                      bot_id="practice", baseline=self.baseline, work=self.work,
                      confirm_diff=None, operation_id=None, release_id=None, request_file=None)
        values.update(kw)
        return type("Args", (), values)()

    def test_prepare_preserves_manifest_and_packs_only_work_files(self):
        result = phase2.run(self.args("prepare"))
        self.assertEqual(result["baseReleaseId"], "R5")
        self.assertEqual(result["changed"], [{"path": "knowledge/documents/FAQ.md",
                                               "component": "knowledge", "action": "modified"}])
        archive = Path(result["archive"])
        self.assertEqual(phase2.digest(archive.read_bytes()), result["archiveDigest"])
        with zipfile.ZipFile(archive) as z:
            self.assertEqual(json.loads(z.read("dclaw-manifest.json")), MANIFEST)
        with self.assertRaisesRegex(phase2.PatchError, "state already exists"):
            phase2.run(self.args("prepare"))

    def test_unplanned_change_and_production_are_rejected(self):
        (self.work / "AGENTS.md").write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "outside editable"):
            phase2.run(self.args("prepare"))
        with self.assertRaisesRegex(phase2.PatchError, "restricted"):
            phase2.run(self.args("prepare", base_url="https://worktool.deepmega.cn"))

    def test_plan_must_match_changed_component(self):
        (self.work / "change-plan.yaml").write_text(PLAN.replace("[Update FAQ]", "[]"), encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "declaration differs"):
            phase2.run(self.args("prepare"))

    def test_changed_baseline_is_rejected(self):
        (self.baseline / "AGENTS.md").write_text("tampered", encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "baseline differs"):
            phase2.run(self.args("prepare"))

    def test_diff_checks_all_four_components_and_publish_gate(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        diff = {"schemaVersion": "config-patch-diff.v1", "components": {
                 part: {"changed": part == "knowledge", "oldDigest": "sha256:" + "a" * 64,
                                      "newDigest": "sha256:" + ("b" if part == "knowledge" else "a") * 64,
                                      "files": ["knowledge/documents/FAQ.md"] if part == "knowledge" else []}
                               for part in phase2.COMPONENTS}}
        fingerprint = phase2.compare_diff(state, diff)
        self.assertTrue(fingerprint.startswith("sha256:"))
        diff["components"]["knowledge"]["files"].append("knowledge/knowledge-manifest.json")
        self.assertTrue(phase2.compare_diff(state, diff).startswith("sha256:"))
        diff["components"]["agent"]["changed"] = True
        with self.assertRaisesRegex(phase2.PatchError, "diff differs|digest transition differs"):
            phase2.compare_diff(state, diff)
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}):
            with self.assertRaisesRegex(phase2.PatchError, "review diff"):
                phase2.run(self.args("publish", confirm_diff="sha256:wrong"))

    def test_upload_replays_saved_key_and_rejects_tampered_archive(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["onlineContextDigest"] = "sha256:" + "c" * 64
        phase2.save(self.state, state)
        calls = []
        def fake_request(base, token, method, path, **kwargs):
            if method == "POST":
                calls.append(kwargs["key"])
                return {"uploadId": "upload-1", "botId": "practice", "agentId": "agent-practice",
                        "baseReleaseId": "R5", "archiveDigest": phase2.load(self.state)["archiveDigest"]}
            return {}
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), patch.object(phase2, "request", side_effect=fake_request):
            phase2.run(self.args("upload"))
            phase2.run(self.args("upload"))
            self.assertEqual(calls[0], calls[1])
            Path(phase2.load(self.state)["archive"]).write_bytes(b"tampered")
            with self.assertRaisesRegex(phase2.PatchError, "archive changed"):
                phase2.run(self.args("upload"))

    def test_rollback_requires_active_publish(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["publishOperationId"] = "op-1"
        phase2.save(self.state, state)
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "request", return_value={"status": "RECOVERY_REQUIRED"}):
            with self.assertRaisesRegex(phase2.PatchError, "not ACTIVE"):
                phase2.run(self.args("rollback", release_id="R5"))


if __name__ == "__main__":
    unittest.main()
