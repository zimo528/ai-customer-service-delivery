"""Export project Codex conversations and exchange an audit ZIP via private Issues."""

from __future__ import annotations

import argparse
import base64
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid
import zipfile

from sync import GitHub, Sync, RemoteError


SCHEMA = 'customer-service-conversation-audit.v1'
MARKER = '<!-- customer-service-conversation-audit.v1 -->'
PART_MARKER = '<!-- conversation-audit-part.v1 '
PART_BYTES = 36_000
TOOL_TEXT_LIMIT = 12_000
SECRET = re.compile(
    r'(?i)(?:github_pat_|gh[pousr]_|dclaw_staff_|sk-)[A-Za-z0-9_-]{16,}'
    r'|Bearer\s+[A-Za-z0-9._-]{16,}'
    r'|(?<=password=)[^\s]+'
)
REPO = re.compile(r'^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$')


def redact(value, counts=None, tool=False):
    counts = counts if counts is not None else defaultdict(int)
    if isinstance(value, str):
        if value.startswith('data:') and ';base64,' in value[:120]:
            counts['embeddedMediaOmitted'] += 1
            return f'[EMBEDDED_MEDIA sha256:{hashlib.sha256(value.encode()).hexdigest()} chars:{len(value)}]'
        value = SECRET.sub('[REDACTED_CREDENTIAL]', value)
        if tool and len(value) > TOOL_TEXT_LIMIT:
            counts['truncatedToolFields'] += 1
            return value[:TOOL_TEXT_LIMIT] + f'\n[TOOL_OUTPUT_TRUNCATED originalChars:{len(value)}]'
        return value
    if isinstance(value, list):
        return [redact(item, counts, tool) for item in value]
    if isinstance(value, dict):
        return {key: redact(item, counts, tool) for key, item in value.items()}
    return value


def titles(codex_home):
    found = {}
    index = codex_home / 'session_index.jsonl'
    if index.is_file():
        with index.open(encoding='utf-8-sig') as stream:
            for line in stream:
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if entry.get('id') and entry.get('thread_name'):
                    found[entry['id']] = entry['thread_name']
    return found


def project_sources(project, codex_home, include_ids):
    selected = defaultdict(list)
    project_key = os.path.normcase(os.path.normpath(str(project.resolve())))
    roots = (codex_home / 'sessions', codex_home / 'archived_sessions')
    for root in roots:
        if not root.is_dir():
            continue
        for path in root.rglob('*.jsonl'):
            try:
                with path.open(encoding='utf-8-sig') as stream:
                    first = json.loads(stream.readline())
            except (OSError, UnicodeError, json.JSONDecodeError):
                continue
            if first.get('type') != 'session_meta':
                continue
            meta = first.get('payload') or {}
            thread_id = meta.get('session_id') or meta.get('id')
            cwd = meta.get('cwd')
            if not thread_id or not cwd:
                continue
            if os.path.normcase(os.path.normpath(cwd)) == project_key or thread_id in include_ids:
                selected[thread_id].append(path)
    missing = include_ids - selected.keys()
    if missing:
        raise ValueError('未找到指定对话的本机记录：' + ', '.join(sorted(missing)))
    return {key: sorted(value) for key, value in selected.items()}


def has_user_message(paths):
    for path in paths:
        with path.open(encoding='utf-8-sig') as stream:
            for line in stream:
                if '"role"' not in line or '"user"' not in line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                item = record.get('payload') or {}
                if record.get('type') == 'response_item' and item.get('type') == 'message' and item.get('role') == 'user':
                    return True
    return False


def export(project, codex_home, controller_id, output_root=None, include_ids=()):
    project = Path(project).resolve()
    codex_home = Path(codex_home).resolve()
    controller_id = str(uuid.UUID(controller_id))
    include_ids = {str(uuid.UUID(item)) for item in include_ids} | {controller_id}
    sources = project_sources(project, codex_home, include_ids)
    registry = project / '.经验同步' / 'task-registry.json'
    expected = set()
    if registry.is_file():
        expected = set(json.loads(registry.read_text(encoding='utf-8-sig')))
        missing = expected - sources.keys()
        if missing:
            raise ValueError('已登记客户任务缺少本机对话记录：' + ', '.join(sorted(missing)))
    empty = sorted(thread_id for thread_id, paths in sources.items() if not has_user_message(paths))
    required_empty = set(empty) & (include_ids | expected)
    if required_empty:
        raise ValueError('总控或已登记客户任务没有用户消息：' + ', '.join(sorted(required_empty)))
    sources = {key: value for key, value in sources.items() if key not in empty}
    if len(sources) < 2:
        raise ValueError('只找到总控或没有客户任务；先核对项目目录与任务范围。')
    output = Path(output_root or project / '.经验同步' / '对话审计')
    output.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    archive = output / f'conversation-audit-{stamp}-{uuid.uuid4().hex[:8]}.zip'
    known_titles = titles(codex_home)
    index = {
        'schema': SCHEMA, 'createdAtUtc': datetime.now(timezone.utc).isoformat(),
        'projectDirectory': project.name, 'controllerThreadId': controller_id,
        'scope': 'All local Codex session logs whose cwd matches this project, plus explicitly included threads.',
        'contents': 'User and assistant text messages, tool calls and bounded results, and turn boundaries; internal reasoning and system/developer messages excluded.',
        'redaction': 'Credential-shaped values replaced with [REDACTED_CREDENTIAL].',
        'limits': {'toolTextCharsPerField': TOOL_TEXT_LIMIT,
                   'embeddedMedia': 'sha256 and character count retained; binary omitted'},
        'excludedSessionsWithoutUserMessages': empty, 'threads': [],
    }
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as bundle:
        for thread_id, paths in sorted(sources.items()):
            counts = defaultdict(int)
            member = f'conversations/{thread_id}.jsonl'
            with bundle.open(member, 'w') as destination:
                for path in paths:
                    with path.open(encoding='utf-8-sig') as stream:
                        for line in stream:
                            try:
                                record = json.loads(line)
                            except json.JSONDecodeError:
                                counts['partialLines'] += 1
                                continue
                            kind = record.get('type')
                            item = record.get('payload') or {}
                            if kind == 'response_item':
                                if item.get('type') == 'reasoning':
                                    continue
                                if item.get('type') == 'message' and item.get('role') not in {'user', 'assistant'}:
                                    continue
                                counts[item.get('role') or item.get('type', 'other')] += 1
                            elif kind == 'event_msg':
                                if item.get('type') not in {'task_started', 'task_complete', 'task_failed'}:
                                    continue
                                counts[item['type']] += 1
                            else:
                                continue
                            tool = kind == 'response_item' and item.get('type') != 'message'
                            clean = redact({'timestamp': record.get('timestamp'), 'type': kind, 'payload': item}, counts, tool)
                            destination.write((json.dumps(clean, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
            if counts['user'] == 0:
                raise ValueError('对话没有用户消息：' + thread_id)
            index['threads'].append({
                'threadId': thread_id, 'title': known_titles.get(thread_id, '未命名'),
                'role': 'controller' if thread_id == controller_id else 'project-task',
                'sourceFiles': len(paths), 'member': member, 'counts': dict(counts),
            })
        bundle.writestr('index.json', json.dumps(index, ensure_ascii=False, indent=2) + '\n')
    verify(archive)
    return {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'bytes': archive.stat().st_size, 'threads': len(index['threads']),
            'userMessages': sum(t['counts'].get('user', 0) for t in index['threads']),
            'threadIds': [item['threadId'] for item in index['threads']]}


def verify(archive):
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise ValueError('对话包 ZIP 校验失败。')
        index = json.loads(bundle.read('index.json'))
        if index.get('schema') != SCHEMA or not index.get('threads'):
            raise ValueError('对话包索引无效。')
        members = set(bundle.namelist())
        expected = {'index.json'} | {item['member'] for item in index['threads']}
        if members != expected or len({item['threadId'] for item in index['threads']}) != len(index['threads']):
            raise ValueError('对话包文件与索引不一致。')
        if index['controllerThreadId'] not in {item['threadId'] for item in index['threads']}:
            raise ValueError('对话包缺少总控。')
        for item in index['threads']:
            if not re.fullmatch(r'conversations/[0-9a-f-]{36}\.jsonl', item['member']):
                raise ValueError('对话包成员路径无效。')
            if not bundle.read(item['member']).strip():
                raise ValueError('对话内容为空。')
    return index


def feedback_route(sync):
    if not sync.config:
        raise RuntimeError('经验同步尚未初始化。')
    repository = sync.config.get('feedback_repository')
    if not repository or not REPO.fullmatch(repository):
        raise RuntimeError('未配置私有反馈仓库。')
    metadata = sync.api.request('GET', f'repos/{repository}')
    if not metadata.get('private') or metadata.get('archived'):
        raise RuntimeError('对话审计只允许上传到可用的私有反馈仓库。')
    return f'repos/{repository}'


def all_issues(api, route):
    for page in range(1, 101):
        items = api.request('GET', f'{route}/issues?state=all&per_page=100&page={page}')
        for item in items:
            if 'pull_request' not in item:
                yield item
        if len(items) < 100:
            return
    raise RuntimeError('私有 Issue 超过分页检查范围。')


def comments(api, route, issue):
    for page in range(1, 1001):
        items = api.request('GET', f'{route}/issues/{issue}/comments?per_page=100&page={page}')
        yield from items
        if len(items) < 100:
            return
    raise RuntimeError('审计包分片超过分页检查范围。')


def issue_manifest(archive):
    content = archive.read_bytes()
    index = verify(archive)
    return {'schema': SCHEMA, 'archiveSha256': hashlib.sha256(content).hexdigest(),
            'archiveBytes': len(content), 'partBytes': PART_BYTES,
            'partCount': (len(content) + PART_BYTES - 1) // PART_BYTES,
            'controllerThreadId': index['controllerThreadId'],
            'threadCount': len(index['threads']), 'createdAtUtc': index['createdAtUtc']}


def parse_manifest(body):
    if not body.startswith(MARKER + '\n'):
        return None
    try:
        value = json.loads(body[len(MARKER) + 1:])
    except json.JSONDecodeError:
        return None
    return value if value.get('schema') == SCHEMA else None


def parse_part(body, archive_sha):
    match = re.fullmatch(r'<!-- conversation-audit-part\.v1 ([0-9a-f]{64}) (\d+) -->\n([A-Za-z0-9+/=]+)', body or '')
    if not match or match[1] != archive_sha:
        return None
    return int(match[2]), base64.b64decode(match[3], validate=True)


def upload(sync, archive):
    sync.role('worker')
    archive = Path(archive).resolve()
    manifest = issue_manifest(archive)
    route = feedback_route(sync)
    sha = manifest['archiveSha256']
    title = '对话审计 ' + sha[:16]
    issue = next((item for item in all_issues(sync.api, route) if item.get('title') == title), None)
    if issue:
        existing = parse_manifest(issue.get('body') or '')
        if existing != manifest:
            raise ValueError('同名审计 Issue 的清单不一致，停止上传。')
    else:
        issue = sync.api.request('POST', route + '/issues', {
            'title': title, 'body': MARKER + '\n' + json.dumps(manifest, ensure_ascii=False, sort_keys=True)})
    number = issue['number']
    present = {}
    for item in comments(sync.api, route, number):
        part = parse_part(item.get('body'), sha)
        if part is not None:
            index, data = part
            if index in present and present[index] != data:
                raise ValueError('远端审计分片重复且内容不一致。')
            present[index] = data
    with archive.open('rb') as source:
        for index in range(manifest['partCount']):
            data = source.read(PART_BYTES)
            if index in present:
                if present[index] != data:
                    raise ValueError('远端审计分片与本机内容不一致。')
                continue
            body = f'{PART_MARKER}{sha} {index} -->\n' + base64.b64encode(data).decode('ascii')
            sync.api.request('POST', f'{route}/issues/{number}/comments', {'body': body})
    return {'issue': number, 'archiveSha256': sha, 'parts': manifest['partCount'],
            'alreadyUploadedParts': len(present), 'repository': sync.config['feedback_repository']}


def receive(sync, issue_number, output_root=None):
    sync.role('controller')
    route = feedback_route(sync)
    issue = sync.api.request('GET', f'{route}/issues/{issue_number}')
    manifest = parse_manifest(issue.get('body') or '')
    if not manifest:
        raise ValueError('该 Issue 不是对话审计包。')
    parts = {}
    for item in comments(sync.api, route, issue_number):
        part = parse_part(item.get('body'), manifest['archiveSha256'])
        if part is not None:
            index, data = part
            if index in parts and parts[index] != data:
                raise ValueError('远端审计分片重复且内容不一致。')
            parts[index] = data
    if set(parts) != set(range(manifest['partCount'])):
        raise ValueError('审计分片尚未传齐；稍后重试。')
    content = b''.join(parts[index] for index in range(manifest['partCount']))
    if len(content) != manifest['archiveBytes'] or hashlib.sha256(content).hexdigest() != manifest['archiveSha256']:
        raise ValueError('审计 ZIP 摘要不一致。')
    output = Path(output_root or sync.state / '审计收件箱')
    output.mkdir(parents=True, exist_ok=True)
    path = output / f'issue-{issue_number}-{manifest["archiveSha256"][:16]}.zip'
    if path.is_file() and path.read_bytes() != content:
        raise ValueError('本机已有同名但内容不同的审计包。')
    if not path.is_file():
        path.write_bytes(content)
    index = verify(path)
    return {'issue': issue_number, 'archive': str(path), 'threads': len(index['threads']),
            'sha256': manifest['archiveSha256']}


def collect(sync, output_root=None):
    sync.role('controller')
    route = feedback_route(sync)
    results = []
    for issue in all_issues(sync.api, route):
        if issue.get('state') == 'open' and parse_manifest(issue.get('body') or ''):
            results.append(receive(sync, issue['number'], output_root))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[2])
    commands = parser.add_subparsers(dest='command', required=True)
    pack = commands.add_parser('pack')
    pack.add_argument('--controller-thread-id', required=True)
    pack.add_argument('--codex-home', type=Path, default=Path(os.environ.get('CODEX_HOME', Path.home() / '.codex')))
    pack.add_argument('--include-thread-id', action='append', default=[])
    pack.add_argument('--output-root', type=Path)
    send = commands.add_parser('upload')
    send.add_argument('--archive', type=Path, required=True)
    get = commands.add_parser('receive')
    get.add_argument('--issue', type=int, required=True)
    get.add_argument('--output-root', type=Path)
    collect_cmd = commands.add_parser('collect')
    collect_cmd.add_argument('--output-root', type=Path)
    args = parser.parse_args()
    sync = Sync(args.project)
    try:
        if args.command == 'pack':
            result = export(args.project, args.codex_home, args.controller_thread_id,
                            args.output_root, args.include_thread_id)
        elif args.command == 'upload':
            result = upload(sync, args.archive)
        elif args.command == 'receive':
            result = receive(sync, args.issue, args.output_root)
        else:
            result = collect(sync, args.output_root)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, RuntimeError, KeyError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == '__main__':
    main()
