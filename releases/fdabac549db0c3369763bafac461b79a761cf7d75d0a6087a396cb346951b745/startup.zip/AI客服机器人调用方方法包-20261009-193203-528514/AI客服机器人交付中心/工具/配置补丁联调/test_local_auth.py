"""Check reusable staff tokens stay bound to the selected environment."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import local_auth


class LocalAuthTests(unittest.TestCase):
    def test_selects_the_token_for_the_base_url(self):
        with tempfile.TemporaryDirectory() as directory:
            token_file = Path(directory) / ".platform-staff-tokens.json"
            token_file.write_text(json.dumps({"test": "test-token", "production": "production-token"}))
            with patch.object(local_auth, "TOKEN_FILE", token_file):
                self.assertEqual(local_auth.staff_token("https://worktool-test.deepmega.cn"), "test-token")
                self.assertEqual(local_auth.staff_token("https://worktool.deepmega.cn/"), "production-token")

    def test_missing_local_token_uses_existing_process_setting(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(local_auth, "TOKEN_FILE", Path(directory) / "missing.json"), \
                    patch.dict("os.environ", {"CONFIG_PATCH_STAFF_TOKEN": "process-token"}):
                self.assertEqual(local_auth.staff_token("https://worktool-test.deepmega.cn"), "process-token")


if __name__ == "__main__":
    unittest.main()
