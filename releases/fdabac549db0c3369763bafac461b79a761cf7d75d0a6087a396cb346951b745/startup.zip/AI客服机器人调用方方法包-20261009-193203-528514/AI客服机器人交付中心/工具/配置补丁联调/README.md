# 配置补丁联调工具

以 `平台接口/第二阶段-20261003/` 中的 API 文档、开发决策指南和完整联调执行单为基础契约，并核对管理员当次开放范围。`phase1.py` 用于只读发现与可信工作包导出；`phase2.py` 用于获开放环境的上传到回退分步操作。测试环境默认可用；正式环境须有管理员当次开放证据，并在每一步显式传入 `--allow-production`，工具仅接受官方正式 Base URL。两者均不得替代业务确认、本次发布确认、人工 diff 审核和真人企微实测。Codex 分角色模拟在客户任务对话内完成，无需后台对话测试接口。

Python 3.11 及 `PyYAML>=6,<7` 是第二阶段工具的依赖。Skill 调用方 Codex 在本机 Python 环境执行 `py -m pip install -r 工具/配置补丁联调/requirements.txt`；macOS/Linux 用 `python3`。总控把已有员工 Token 一次写入本机项目根目录 `.platform-staff-tokens.json`，例如 `{"test":"<测试 Token>","production":"<正式 Token>"}`；文件不随方法包分发，也不随更新覆盖。`phase1.py` 用 `--base-url`、`phase2.py` 用 `--base-url` 或本轮 `state.json` 选择环境，工具自动读取对应 Token。若本机文件没有该环境的 Token，仍可用当前进程 `CONFIG_PATCH_STAFF_TOKEN` 或 `--token-prompt`。不向子任务重复索取已保存的 Token，也不把 Token 放进命令参数或结果报告。

执行平台步骤时直接调用一次性 `phase1.py`／`phase2.py` 命令并读取退出状态，不在工具会话中再启动嵌套交互式 PowerShell 等待。先核本轮凭据、环境和保存的 `state.json` 是否可用；缺项立即说明，不让命令长时间挂起。身份、当前基线和相关接口条款在每轮确认一次；未发生契约或绑定变化时，不为单项反馈重复通读整份文档。上传、预检、发布仍依次执行，结果不明按已保存 ID 查询，不靠等待或重开会话猜状态。

收到“上传成功”“发布成功”通知或用户催问状态时，先用本轮 `state.json` 中已保存的 ID 只读查询 operation、Release 和配置上下文，并核对四组件摘要。上传 `validated` 与预检 `PREPARED` 都不等于发布；operation `ACTIVE`、Release `published / ACTIVE` 且配置回读对应本轮目标时，停止重复写入。通知无法对应本轮 ID 时，先核实其所指的环境、Bot、时间和 Release，不因一句“已成功”直接重导工作包或重做上传。管理员因平台修复明确要求重建基线时，再按该次通知执行双导出及重做，并说明这一步的原因。详细判定见交付 Skill 的 `references/config-patch-phase2.md`。

## 1. 选择并导出

```powershell
py 工具/配置补丁联调/phase1.py discover --base-url https://worktool-test.deepmega.cn
py 工具/配置补丁联调/phase1.py export --base-url https://worktool-test.deepmega.cn --bot-id <当前列表明确选定的BotID> --output <私有任务目录>
```

导出校验响应头、ZIP 摘要、Manifest、四项来源指纹与跨平台原路径。失败即停止并反馈管理员；不得映射、改名或转义。原始 ZIP 与 `平台基线/<Release>/extracted` 原样留存，只修改 `当前工作区`。已有基线和工作副本不会覆盖。

## 2. 本地打包与分步调用

以下 `state.json` 放在私有任务目录；`prepare` 生成固定 ZIP 和五个持久幂等键，重试同一操作必须保留该状态文件。R5 是示例，实际以本次导出的 Release 为准。

```powershell
py 工具/配置补丁联调/phase2.py prepare --state <私有任务目录>/state.json --bot-id <BotID> --baseline <私有任务目录>/平台基线/R5/extracted --work <私有任务目录>/当前工作区
py 工具/配置补丁联调/phase2.py online-baseline --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py upload-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py online-unchanged --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py diff --state <私有任务目录>/state.json
```

预检有效期是短窗口。需要等待人工审核时，把 `expiresAt` 随 diff 一起交代，停在审核结果；收到本次发布授权后，先查当前预检剩余时间，再安排发布操作。有效期不足以完成必要核对时立即续期，不在临期状态重复长时间串行检查。预检过期后，若原上传仍有效且线上基线、Bot 绑定及配置上下文未变化，可沿用原 `state.json` 和 uploadId 执行 `renew-precheck`。工具会重新核对归档 ZIP 与线上状态，保留旧预检历史，生成新的预检及发布幂等键；之后重新查询 diff 并人工确认，不能沿用过期的 precheckId 或原 diff 确认结果。

```powershell
py 工具/配置补丁联调/phase2.py renew-precheck --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py precheck-status --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py diff --state <私有任务目录>/state.json
```

`prepare` 检查 Manifest 未变、`change-plan.yaml` 包含模板规定的需求、四组件、协同、验证和能力申请字段，基线及组件声明对应实际改动，没有越界文件，并生成可移植 ZIP。首次配置本地检查后即可走上传、预检和发布确认；只有发布回读生效后，才能真人企微实测新版。实测反馈进入下一轮时，先汇总并让用户确认本批已收口，从最新线上 Release 新建轮次，在新工作副本中修复和回归。上传前重新核对 Agent Profile 和能力目录版本；变化后重新导出。上传后先查线上 Release 未变化。预检必须 `PREPARED`、`canPublish=true`、`blockers=[]`；diff 必须恰好展示四组件的摘要、changed 和文件清单，且与本地相符。工具把核对过的完整 diff 留在私有状态文件中，同一预检的重复查询若改变即停止。人工阅读完整 diff、业务规则和预期影响后，向用户展示环境、Bot、变更范围、影响和当前 diff，单独取得本次 Bot 发布确认，才可使用显示的 `diffDigest` 调用发布。预检续期、基线或 diff 变化后重新核对并再次确认：

原本没有标签时，`customer-service/tag-schema.json` 的 `{"config":null}` 是规范空值；不要自行补默认标签，已有标签也不能改成 `null` 来删除。仅排障用的无组件改动控制样本可在 `prepare` 时添加 `--no-change-diagnostic`；工具会在状态中标记并拒绝 `publish`。正常配置变更仍须有真实组件差异。

```powershell
py 工具/配置补丁联调/phase2.py publish --state <私有任务目录>/state.json --confirm-diff sha256:<diffDigest>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

operation 为 `ACTIVE` 且新 Release、四项摘要和配置上下文核对后，按本次范围另记真人企微对话和发送回执结果；Codex 分角色模拟不能替代。需要回退时，目标必须是本次保存的起始 Release；回退会产生新 Release：

```powershell
py 工具/配置补丁联调/phase2.py rollback --state <私有任务目录>/state.json --release-id <起始Release>
py 工具/配置补丁联调/phase2.py operation --state <私有任务目录>/state.json --operation-id <回退operationId>
py 工具/配置补丁联调/phase2.py releases --state <私有任务目录>/state.json --release-id <回退生成的新Release>
py 工具/配置补丁联调/phase2.py context --state <私有任务目录>/state.json
```

回退前工具核对发布 operation 已 `ACTIVE` 且 Release 历史没有更新版本；回退后再做真实会话和回执验证。能力缺口按官方 JSON 契约写在私有文件后执行 `capability --request-file <路径>`，用 `capability-status` 查询；收到能力目录升级后重新发现、导出和规划。

网络结果不明时先查询已保存的 upload/precheck/operation ID；必要重放使用 `state.json` 原键与原包，不生成新状态文件。预检有 blocker 时，工具在私有状态和终端保留 `precheckId`、状态及 blocker 的 `code`、`path`、`message`、`missingItems`，据此向管理员反馈；不记录 Token 或完整响应正文。`RECOVERY_REQUIRED`、绑定变化、基线冲突、预检 blocker、diff 越界时停止发布并交管理员处理。正式环境未获管理员开放时保持只读；开放后从正式环境重新导出，使用正式 Token、正式 Base URL 和 `--allow-production` 执行每个 `phase2.py` 命令，不能混用测试 Token 或基线。

测试：`py -m unittest discover -s 工具/配置补丁联调 -p 'test_*.py'`。
