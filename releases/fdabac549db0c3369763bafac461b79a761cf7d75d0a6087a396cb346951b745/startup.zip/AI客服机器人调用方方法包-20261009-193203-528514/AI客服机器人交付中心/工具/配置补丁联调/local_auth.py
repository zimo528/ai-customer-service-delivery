"""Load the current project's reusable staff token for a selected platform."""

import json
import os
from pathlib import Path


TOKEN_FILE = Path(__file__).resolve().parents[2] / ".platform-staff-tokens.json"
ENVIRONMENTS = {
    "https://worktool-test.deepmega.cn": "test",
    "https://worktool.deepmega.cn": "production",
}


def staff_token(base_url: str) -> str:
    environment = ENVIRONMENTS.get(base_url.rstrip("/"))
    if environment and TOKEN_FILE.is_file():
        try:
            saved = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ValueError(f"invalid local staff token file: {TOKEN_FILE}") from exc
        if not isinstance(saved, dict):
            raise ValueError(f"invalid local staff token file: {TOKEN_FILE}")
        token = saved.get(environment)
        if token is not None:
            if not isinstance(token, str):
                raise ValueError(f"invalid {environment} staff token in {TOKEN_FILE}")
            if token.strip():
                return token.strip()
    return os.environ.get("CONFIG_PATCH_STAFF_TOKEN", "")
