# Agent 首次导入基础包

`生成.py` 从 `$dclaw-agent-config` 的 `assets/agent-base-template.zip` 中性母版生成 DClaw 首次导入 ZIP。母版只含技术结构与通用协议，不含客户产品、价格、对客身份或接待流程。

先核对客户名称、销售或售后、目标环境，拟定唯一 Agent ID 并请用户确认。确认后运行：

```powershell
python -X utf8 工具/Agent基础包/生成.py create --customer "<客户名称>" --purpose 销售 --environment 正式 --agent-id <已确认ID>
```

默认输出到 `Agent项目/<客户名称>-<用途>Agent基础包/`。如该客户已有专用目录，可用 `--output-dir` 指定；已有 ZIP 或工作区不会被覆盖。工具检查 ZIP 回读、ID、工作区路径、加载文件、技能引用与占位替换。平台导入、权限、Bot 绑定和后续业务配置须分别验证；本地生成不代表平台生效。
