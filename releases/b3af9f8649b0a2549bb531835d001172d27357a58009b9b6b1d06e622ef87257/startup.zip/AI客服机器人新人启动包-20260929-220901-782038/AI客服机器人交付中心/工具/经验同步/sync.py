"""Private GitHub transport for feedback and portable delivery-method releases.

Credentials stay in Git Credential Manager. Customer folders are never synchronized.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

SCHEMA = 'customer-service-feedback.v1'
SKILLS = ('ai-customer-service-delivery', 'dclaw-agent-config', 'no-negative-echo')
PII = re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|\b(?:gh[pousr]_|github_pat_|sk-)[A-Za-z0-9_\-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----', re.I)
MARKER = '<!-- customer-service-feedback.v1 -->'


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    fd, temporary = tempfile.mkstemp(prefix='.sync-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read(path, default=None):
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.is_file() else default


class RemoteError(RuntimeError):
    def __init__(self, status):
        self.status = status
        super().__init__(f'GitHub 请求未完成（状态 {status}）；本地待办保留。')


class GitHub:
    def __init__(self):
        env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never')
        try:
            p = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\n\n', text=True,
                               capture_output=True, timeout=30, env=env)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            raise RuntimeError('请先在本机准备 Git 并登录 GitHub。') from None
        fields = dict(line.split('=', 1) for line in p.stdout.splitlines() if '=' in line)
        token = fields.get('password') if p.returncode == 0 else None
        if not token:
            raise RuntimeError('本机尚无可用 GitHub 登录，请先完成一次登录授权。')
        self.headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
                        'User-Agent': 'customer-service-skill-sync', 'X-GitHub-Api-Version': '2026-03-10'}

    def request(self, method, path, payload=None, raw=False):
        headers = dict(self.headers)
        if raw:
            headers['Accept'] = 'application/vnd.github.raw+json'
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        if body is not None:
            headers['Content-Type'] = 'application/json'
        req = urllib.request.Request('https://api.github.com/' + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=40) as response:
                content = response.read()
        except urllib.error.HTTPError as e:
            raise RemoteError(e.code) from None
        except (urllib.error.URLError, TimeoutError):
            raise RemoteError('网络暂不可用') from None
        return content if raw else json.loads(content) if content else None


class Sync:
    def __init__(self, project, api=None):
        self.project = Path(project).resolve()
        self.state = self.project / '.经验同步'
        self.config_path = self.state / 'config.json'
        self.config = read(self.config_path)
        self._api = api

    @property
    def api(self):
        if self._api is None:
            self._api = GitHub()
        return self._api

    def route(self, suffix):
        if not self.config:
            raise RuntimeError('经验同步未初始化。')
        return 'repos/' + self.config['repository'] + '/' + suffix

    @contextmanager
    def locked(self, wait_seconds=30):
        # Several customer chats and the timer can share the same local queue.
        self.state.mkdir(parents=True, exist_ok=True)
        with (self.state / 'sync.lock').open('a+b') as lock:
            if lock.tell() == 0:
                lock.write(b'0')
                lock.flush()
            deadline = time.monotonic() + wait_seconds
            while True:
                try:
                    lock.seek(0)
                    if os.name == 'nt':
                        import msvcrt
                        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise RuntimeError('另一次同步仍在运行，本轮留待重试。') from None
                    time.sleep(0.2)
            try:
                # Initialization by another process may have completed while waiting.
                self.config = read(self.config_path)
                yield
            finally:
                lock.seek(0)
                if os.name == 'nt':
                    msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def role(self, expected):
        if not self.config or self.config['role'] != expected:
            raise RuntimeError('该操作只用于 ' + expected + ' 角色。')

    def init(self, repository, role):
        if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
            raise ValueError('仓库填写为 GitHub账号/仓库名。')
        if self.config and (self.config['repository'] != repository or self.config['role'] != role):
            raise ValueError('已有不同同步配置，须先核对迁移范围。')
        metadata = self.api.request('GET', 'repos/' + repository)
        if not metadata.get('private') or metadata.get('archived'):
            raise ValueError('仅使用可读写的私有仓库。')
        if role == 'controller' and not metadata.get('permissions', {}).get('push'):
            raise ValueError('主控账号需要发布权限。')
        self.config = self.config or {'schema': 'customer-service-sync.v1', 'repository': repository,
                                     'role': role, 'node_id': str(uuid.uuid4()), 'initialized_at': now()}
        dump(self.config_path, self.config)
        return {'role': role, 'repository': repository, 'initialized': True}

    def content(self, path, raw=False):
        return self.api.request('GET', self.route('contents/' + urllib.parse.quote(path, safe='/')), raw=raw)

    def put(self, path, content, immutable=False):
        existing = None
        try:
            existing = self.content(path)
        except RemoteError as e:
            if e.status != 404:
                raise
        if existing:
            prior = self.content(path, raw=True)
            if prior == content:
                return
            if immutable:
                raise ValueError('已发布版本不能覆盖。')
        body = {'message': 'Update delivery methods', 'content': base64.b64encode(content).decode('ascii')}
        if existing:
            body['sha'] = existing['sha']
        self.api.request('PUT', self.route('contents/' + urllib.parse.quote(path, safe='/')), body)

    def feedback(self, fields):
        allowed = {'module', 'problem', 'before', 'after', 'evidence', 'lesson', 'scope', 'test_level', 'business_change', 'result'}
        if set(fields) != allowed:
            raise ValueError('反馈字段须与示例一致，证据只用脱敏后的简短片段。')
        if fields['module'] not in {'agent', 'state-machine', 'knowledge', 'delivery'}:
            raise ValueError('未知反馈板块。')
        if fields['test_level'] not in {'静态推演', '隔离模拟', '微信实测'} or type(fields['business_change']) is not bool:
            raise ValueError('测试层级和业务变更标记无效。')
        if fields['result'] not in {'改进', '失败', '无变化', '待验证'}:
            raise ValueError('测试结果无效。')
        for key in allowed - {'evidence', 'business_change'}:
            if not isinstance(fields[key], str) or not fields[key].strip() or len(fields[key]) > 4000:
                raise ValueError('反馈文字为空或过长。')
        if not isinstance(fields['evidence'], list) or not 1 <= len(fields['evidence']) <= 10:
            raise ValueError('反馈需附至少一项简短证据。')
        for evidence in fields['evidence']:
            if not isinstance(evidence, dict) or set(evidence) != {'input', 'observed', 'expected'}:
                raise ValueError('证据字段应为 input、observed、expected。')
            if any(not isinstance(v, str) or len(v) > 2000 for v in evidence.values()):
                raise ValueError('证据片段格式无效。')
        body = json.dumps(fields, ensure_ascii=False)
        if len(body.encode('utf-8')) > 30000 or PII.search(body):
            raise ValueError('反馈含联系方式／凭据或超过大小限制，请先脱敏并缩短。')

    def enqueue(self, fields):
        if not self.config:
            raise RuntimeError('先完成经验同步初始化。')
        self.feedback(fields)
        item = dict(fields, schema=SCHEMA, id=str(uuid.uuid4()), node_id=self.config['node_id'], created_at=now(),
                    method_version=read(self.state / 'installed.json', {}).get('version', '初始包'))
        dump(self.state / 'outbox' / (item['id'] + '.json'), item)
        return item

    def submit(self):
        sent = read(self.state / 'sent.json', {})
        attempts = read(self.state / 'submission-attempts.json', {})
        count = 0
        for path in sorted((self.state / 'outbox').glob('*.json')):
            item = read(path)
            if item['id'] in sent:
                continue
            self.feedback({k: v for k, v in item.items() if k not in {'schema', 'id', 'node_id', 'created_at', 'method_version'}})
            # A timed-out POST can have succeeded; look up the stable UUID before retrying.
            q = urllib.parse.quote('repo:' + self.config['repository'] + ' is:issue ' + item['id'] + ' in:title')
            found = self.api.request('GET', 'search/issues?q=' + q)['items']
            matches = [x for x in found if x.get('title', '').endswith(item['id'])]
            if not matches and item['id'] in attempts:
                # GitHub search indexing can lag behind a successful POST. On retry
                # inspect the issue collection directly before creating anything.
                for page in range(1, 21):
                    recent = self.api.request('GET', self.route(f'issues?state=all&per_page=100&page={page}'))
                    matches.extend(x for x in recent if 'pull_request' not in x and x.get('title', '').endswith(item['id']))
                    if len(recent) < 100:
                        break
                else:
                    raise RuntimeError('回传重试核对超过读取上限，本地反馈保留待核。')
            if len(matches) > 1:
                raise RuntimeError('远端有重复反馈编号，保留本地待核。')
            if matches:
                issue = matches[0]
                expected_body = MARKER + '\n```json\n' + json.dumps(item, ensure_ascii=False, indent=2) + '\n```'
                full = self.api.request('GET', self.route('issues/' + str(issue['number'])))
                if full.get('body') != expected_body:
                    raise RuntimeError('远端反馈内容与本地不同，保留待核。')
            else:
                attempts[item['id']] = {'started_at': now()}
                dump(self.state / 'submission-attempts.json', attempts)
                issue = self.api.request('POST', self.route('issues'), {
                    'title': '[经验反馈] ' + item['module'] + ' ' + item['id'],
                    'body': MARKER + '\n```json\n' + json.dumps(item, ensure_ascii=False, indent=2) + '\n```'})
            sent[item['id']] = {'issue': issue['number'], 'sent_at': now(), 'sha256': digest(path.read_bytes())}
            dump(self.state / 'sent.json', sent)
            count += 1
        return {'submitted': count, 'total_sent': len(sent)}

    def collect(self):
        self.role('controller')
        received, ignored = 0, 0
        pending = read(self.state / 'decisions.json', {})
        for page in range(1, 21):
            issues = self.api.request('GET', self.route(f'issues?state=open&per_page=100&page={page}'))
            for issue in issues:
                body = issue.get('body') or ''
                if 'pull_request' in issue or not body.startswith(MARKER + '\n```json\n') or not body.endswith('\n```'):
                    ignored += 1
                    continue
                try:
                    item = json.loads(body[len(MARKER + '\n```json\n'):-len('\n```')])
                    if item['schema'] != SCHEMA or str(uuid.UUID(item['id'])) != item['id']:
                        raise ValueError()
                    self.feedback({k: v for k, v in item.items() if k not in {'schema', 'id', 'node_id', 'created_at', 'method_version'}})
                except (ValueError, KeyError, TypeError):
                    ignored += 1
                    continue
                if item['id'] in pending:
                    continue
                local = self.state / 'inbox' / (item['id'] + '.json')
                record = {'issue': issue['number'], 'author': issue.get('user', {}).get('login'), 'feedback': item}
                if local.exists() and read(local) != record:
                    raise RuntimeError('已有反馈内容被改动，须核对后再处理。')
                if not local.exists():
                    dump(local, record)
                    received += 1
            if len(issues) < 100:
                break
        else:
            raise RuntimeError('反馈量超过本轮读取上限，须缩小范围；已收到内容保留。')
        ready = [str(p) for p in sorted((self.state / 'inbox').glob('*.json')) if p.stem not in pending]
        return {'new_feedback': received, 'pending_files': ready, 'ignored_other_issues': ignored}

    def background(self, skip_update=False):
        """Independent best-effort stages; delivery never depends on this result."""
        result = {'delivery_can_continue': True, 'stages': {}, 'errors': {}}
        if not self.config:
            result['errors']['setup'] = '同步尚未初始化，先使用本机方法继续交付。'
        else:
            stages = ['submit']
            if self.config['role'] == 'controller':
                stages.append('collect')
            elif not skip_update:
                stages.append('pull')
            else:
                result['update_deferred'] = '本轮只回传，留待任务间隙更新方法。'
            for stage in stages:
                try:
                    result['stages'][stage] = getattr(self, stage)()
                except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
                    result['errors'][stage] = str(exc)
        prior = read(self.state / 'background-result.json', {})
        result['attention_changed'] = bool(result['errors']) and result['errors'] != prior.get('errors', {})
        result['checked_at'] = now()
        try:
            dump(self.state / 'background-result.json', result)
        except OSError:
            result['errors']['local_record'] = '同步结果暂无法保存，客户交付继续。'
        return result

    @staticmethod
    def package(data):
        if len(data) > 30 * 1024 * 1024:
            raise ValueError('方法包超过大小限制。')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if z.testzip() is not None or len(z.namelist()) != len(set(z.namelist())):
                raise ValueError('方法包损坏或有重复路径。')
            if sum(i.file_size for i in z.infolist()) > 50 * 1024 * 1024:
                raise ValueError('方法包解压大小超限。')
            roots = {PurePosixPath(n).parts[0] for n in z.namelist()}
            if len(roots) != 1:
                raise ValueError('方法包须有唯一根目录。')
            prefix = next(iter(roots)) + '/'
            manifest = json.loads(z.read(prefix + '文件校验清单.json'))
            expected = {prefix + f['path']: f for f in manifest['files']}
            if {n for n in z.namelist() if not n.endswith('/')} != set(expected) | {prefix + '文件校验清单.json'}:
                raise ValueError('方法包内容与清单不一致。')
            material = {}
            for n in z.namelist():
                pp = PurePosixPath(n)
                if pp.is_absolute() or '..' in pp.parts or '\\' in n or ':' in n:
                    raise ValueError('方法包路径不安全。')
                if n.endswith('/'):
                    continue
                content = z.read(n)
                if n in expected and digest(content).upper() != expected[n]['sha256'].upper():
                    raise ValueError('方法包文件哈希不一致。')
                rel = n.removeprefix(prefix + 'AI客服机器人交付中心/')
                permitted = rel in {'AGENTS.md', '配置交付SOP链路.md', '客户Bot交付表.md'} or any(
                    rel.startswith('.agents/skills/' + s + '/') for s in SKILLS) or rel.startswith(('工具/聊单清洗/', '工具/经验同步/'))
                if n.startswith(prefix + 'AI客服机器人交付中心/'):
                    if not permitted or any(part in {'.git', '__pycache__', '版本归档'} for part in pp.parts):
                        raise ValueError('方法包不能包含客户或本机状态文件。')
                    material[rel] = content
                elif n not in {prefix + '先看这里.md', prefix + '文件校验清单.json'}:
                    raise ValueError('未知包文件。')
            for s in SKILLS:
                if '.agents/skills/' + s + '/SKILL.md' not in material:
                    raise ValueError('方法包缺少 Skill。')
            return material

    def publish(self, bundle):
        self.role('controller')
        data = Path(bundle).read_bytes()
        self.package(data)
        hashed = digest(data)
        latest = {'schema': 'customer-service-release.v1', 'version': hashed[:16], 'sha256': hashed,
                  'path': 'releases/' + hashed + '/startup.zip', 'bytes': len(data)}
        self.put(latest['path'], data, immutable=True)
        self.put('latest.json', (json.dumps(latest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
        dump(self.state / 'published.json', latest)
        return latest

    def pull(self):
        self.role('worker')
        latest = json.loads(self.content('latest.json', raw=True))
        if latest.get('schema') != 'customer-service-release.v1' or not re.fullmatch(r'[0-9a-f]{64}', latest.get('sha256', '')):
            raise ValueError('远端版本声明无效。')
        if latest.get('path') != 'releases/' + latest['sha256'] + '/startup.zip' or latest.get('version') != latest['sha256'][:16]:
            raise ValueError('远端版本路径不匹配。')
        installed = read(self.state / 'installed.json', {})
        files = installed.get('files', {})
        intact = files and all((self.project / rel).is_file() and digest((self.project / rel).read_bytes()) == hashed for rel, hashed in files.items())
        if installed.get('sha256') == latest['sha256'] and intact:
            return {'updated': False, 'version': installed['version']}
        data = self.content(latest['path'], raw=True)
        if digest(data) != latest['sha256'] or len(data) != latest['bytes']:
            raise ValueError('下载包与远端声明不一致。')
        material = self.package(data)
        # Preflight every target before changing any file; retain the exact local baseline.
        backup = self.state / 'versions' / (datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '-' + latest['version'])
        baseline = {}
        for rel in material:
            target = self.project / rel
            if any(parent.is_symlink() for parent in [target, *target.parents] if parent != self.project.parent):
                raise ValueError('同步目标含符号链接，须核对实际目录。')
            if not target.resolve().is_relative_to(self.project):
                raise ValueError('同步目标越出项目。')
            if target.exists() and not target.is_file():
                raise ValueError('同步目标不是普通文件。')
            baseline[rel] = target.read_bytes() if target.exists() else None
        for rel, prior in baseline.items():
            if prior is not None:
                dest = backup / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(prior)
        changed = []
        try:
            for rel, content in material.items():
                target = self.project / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                fd, temporary = tempfile.mkstemp(prefix='.method-', dir=target.parent)
                try:
                    with os.fdopen(fd, 'wb') as f:
                        f.write(content)
                    os.replace(temporary, target)
                    changed.append(rel)
                finally:
                    if os.path.exists(temporary):
                        os.unlink(temporary)
            for rel, content in material.items():
                if (self.project / rel).read_bytes() != content:
                    raise ValueError('更新后文件不一致。')
            dump(self.state / 'installed.json', dict(latest, files={rel: digest(content) for rel, content in material.items()}))
        except BaseException:
            for rel in reversed(changed):
                target = self.project / rel
                prior = baseline[rel]
                if prior is None:
                    target.unlink(missing_ok=True)
                else:
                    target.write_bytes(prior)
            raise
        return {'updated': True, 'version': latest['version'], 'files': len(material), 'backup': str(backup)}

    def resolve(self, feedback_id, outcome, note, confirmed=False):
        self.role('controller')
        feedback_id = str(uuid.UUID(feedback_id))
        record = read(self.state / 'inbox' / (feedback_id + '.json'))
        if not record:
            raise ValueError('反馈尚未收取。')
        if outcome not in {'已采用', '不采用', '待业务确认', '待补证据'} or not note.strip() or PII.search(note):
            raise ValueError('处理结果或说明无效。')
        if outcome == '已采用':
            if record['feedback']['business_change'] and not confirmed:
                raise ValueError('业务变化须有本轮用户确认。')
            if not read(self.state / 'published.json'):
                raise ValueError('先发布已校验的方法包，再确认采用。')
        decisions = read(self.state / 'decisions.json', {})
        value = {'outcome': outcome, 'note': note, 'at': now(), 'version': read(self.state / 'published.json', {}).get('version')}
        if decisions.get(feedback_id, {}).get('outcome') == outcome and decisions[feedback_id].get('note') == note:
            return {'already_recorded': True}
        self.api.request('POST', self.route('issues/' + str(record['issue']) + '/comments'), {
            'body': '处理结果：' + outcome + '\n方法版本：' + str(value['version'] or '未发布') + '\n' + note})
        if outcome in {'已采用', '不采用'}:
            self.api.request('PATCH', self.route('issues/' + str(record['issue'])), {'state': 'closed'})
        decisions[feedback_id] = value
        dump(self.state / 'decisions.json', decisions)
        return value


def main():
    parser = argparse.ArgumentParser(description='客服交付经验回传与方法版本同步')
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[2])
    sub = parser.add_subparsers(dest='command', required=True)
    initialize = sub.add_parser('init')
    initialize.add_argument('--repository', required=True)
    initialize.add_argument('--role', choices=['worker', 'controller'], required=True)
    sub.add_parser('status')
    enqueue = sub.add_parser('enqueue')
    enqueue.add_argument('--file', type=Path, required=True)
    for name in ['submit', 'collect', 'pull']:
        sub.add_parser(name)
    background = sub.add_parser('background')
    background.add_argument('--skip-update', action='store_true')
    publish = sub.add_parser('publish')
    publish.add_argument('--bundle', type=Path, required=True)
    resolve = sub.add_parser('resolve')
    resolve.add_argument('--id', required=True)
    resolve.add_argument('--outcome', required=True)
    resolve.add_argument('--note', required=True)
    resolve.add_argument('--confirmed-by-user', action='store_true')
    args = parser.parse_args()
    if args.command == 'background':
        try:
            sync = Sync(args.project)
            with sync.locked(wait_seconds=0):
                result = sync.background(args.skip_update)
        except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
            result = {'delivery_can_continue': True, 'deferred': True, 'errors': {'sync': str(exc)}}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    sync = Sync(args.project)
    with sync.locked():
        if args.command == 'init':
            result = sync.init(args.repository, args.role)
        elif args.command == 'status':
            result = {'configured': bool(sync.config), 'role': (sync.config or {}).get('role'),
                      'repository': (sync.config or {}).get('repository'), 'installed': read(sync.state / 'installed.json'),
                      'published': read(sync.state / 'published.json')}
        elif args.command == 'enqueue':
            result = {'queued': sync.enqueue(read(args.file))['id']}
        elif args.command == 'publish':
            result = sync.publish(args.bundle)
        elif args.command == 'resolve':
            result = sync.resolve(args.id, args.outcome, args.note, args.confirmed_by_user)
        else:
            result = getattr(sync, args.command)()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
