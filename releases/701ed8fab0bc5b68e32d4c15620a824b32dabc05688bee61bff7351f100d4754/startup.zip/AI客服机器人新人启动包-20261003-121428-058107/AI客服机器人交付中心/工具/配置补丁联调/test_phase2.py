import io
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import phase2


MANIFEST = {"schemaVersion": "customer-service-workspace.v1", "botId": "practice",
            "agentId": "agent-practice", "agentProfileId": "standard", "capabilityCatalogVersion": "2026.10.02",
            "baseReleaseId": "R5",
            "sourceFingerprints": {part: "sha256:" + "a" * 64 for part in ("agent", "knowledge", "flow", "tags")}}
PLAN = """schemaVersion: customer-service-change-plan.v1
requirement: Update the practice FAQ without changing customer-facing facts
baseReleaseId: R5
changes:
  agent: []
  knowledge: [Update FAQ]
  stateMachine: []
  tags: []
coordination: []
verification: [Check the FAQ against the baseline]
capabilityRequests: []
"""


class Phase2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.baseline = root / "baseline"
        self.work = root / "work"
        files = {
            "dclaw-manifest.json": json.dumps(MANIFEST), "AGENTS.md": "instructions",
            "change-plan.yaml": "baseReleaseId: R5", "knowledge/knowledge-manifest.json": "{}",
            "knowledge/documents/FAQ.md": "old", "customer-service/flow-machine.json": "{}",
            "customer-service/tag-schema.json": "{}", "platform/capability-catalog.json": "{}",
        }
        for target in (self.baseline, self.work):
            for name, body in files.items():
                path = target / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(body, encoding="utf-8")
        with zipfile.ZipFile(self.baseline.parent / "workspace.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for name in files:
                archive.write(self.baseline / name, name)
        (self.work / "change-plan.yaml").write_text(PLAN, encoding="utf-8")
        (self.work / "knowledge/documents/FAQ.md").write_text("new", encoding="utf-8")
        self.state = root / "operation.json"

    def args(self, command, **kw):
        values = dict(command=command, state=self.state, base_url=phase2.TEST_BASE,
                      bot_id="practice", baseline=self.baseline, work=self.work,
                      confirm_diff=None, operation_id=None, release_id=None, request_file=None,
                      no_change_diagnostic=False)
        values.update(kw)
        return type("Args", (), values)()

    def test_prepare_preserves_manifest_and_packs_only_work_files(self):
        result = phase2.run(self.args("prepare"))
        self.assertEqual(result["baseReleaseId"], "R5")
        self.assertEqual(result["changed"], [{"path": "knowledge/documents/FAQ.md",
                                               "component": "knowledge", "action": "modified"}])
        archive = Path(result["archive"])
        self.assertEqual(phase2.digest(archive.read_bytes()), result["archiveDigest"])
        with zipfile.ZipFile(archive) as z:
            self.assertEqual(json.loads(z.read("dclaw-manifest.json")), MANIFEST)
        with self.assertRaisesRegex(phase2.PatchError, "state already exists"):
            phase2.run(self.args("prepare"))

    def test_no_change_diagnostic_cannot_publish(self):
        (self.work / "knowledge/documents/FAQ.md").write_text("old", encoding="utf-8")
        (self.work / "change-plan.yaml").write_text(
            PLAN.replace("[Update FAQ]", "[]"), encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "no component files changed"):
            phase2.run(self.args("prepare"))
        result = phase2.run(self.args("prepare", no_change_diagnostic=True))
        self.assertEqual(result["changed"], [])
        self.assertTrue(phase2.load(self.state)["diagnosticOnly"])
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}):
            with self.assertRaisesRegex(phase2.PatchError, "cannot be published"):
                phase2.run(self.args("publish", confirm_diff="anything"))

    def test_unplanned_change_and_production_are_rejected(self):
        (self.work / "AGENTS.md").write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "outside editable"):
            phase2.run(self.args("prepare"))
        with self.assertRaisesRegex(phase2.PatchError, "restricted"):
            phase2.run(self.args("prepare", base_url="https://worktool.deepmega.cn"))

    def test_plan_must_match_changed_component(self):
        (self.work / "change-plan.yaml").write_text(PLAN.replace("[Update FAQ]", "[]"), encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "declaration differs"):
            phase2.run(self.args("prepare"))

    def test_plan_requires_documented_fields_and_verification(self):
        for plan, error in (
            (PLAN.replace("requirement: Update the practice FAQ without changing customer-facing facts\n", ""), "fields differ"),
            (PLAN.replace("verification: [Check the FAQ against the baseline]", "verification: []"), "verification"),
            (PLAN + "unreviewedExtra: true\n", "fields differ"),
        ):
            with self.subTest(error=error, plan=plan):
                (self.work / "change-plan.yaml").write_text(plan, encoding="utf-8")
                with self.assertRaisesRegex(phase2.PatchError, error):
                    phase2.run(self.args("prepare"))

    def test_changed_baseline_is_rejected(self):
        (self.baseline / "AGENTS.md").write_text("tampered", encoding="utf-8")
        with self.assertRaisesRegex(phase2.PatchError, "baseline differs"):
            phase2.run(self.args("prepare"))

    def test_catalog_change_is_caught_before_write(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        responses = {
            "/whoami": {"tokenId": "token-1"},
            "/bots": {"bots": [{"botId": "practice", "boundAgentId": "agent-practice",
                                "agentProfileId": "standard", "readiness": {"ready": True}}]},
            "/capabilities": {"version": "2026.10.03", "profiles": {"standard": {}}},
        }
        with patch.object(phase2, "request", side_effect=lambda base, token, method, path: responses[path]):
            with self.assertRaisesRegex(phase2.PatchError, "catalog changed"):
                phase2.ensure_live_target(state, "local-test-only")

    def test_diff_checks_all_four_components_and_publish_gate(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        diff = {"schemaVersion": "config-patch-diff.v1", "components": {
                 part: {"changed": part == "knowledge", "oldDigest": "sha256:" + "a" * 64,
                                      "newDigest": "sha256:" + ("b" if part == "knowledge" else "a") * 64,
                                      "files": ["knowledge/documents/FAQ.md"] if part == "knowledge" else []}
                               for part in phase2.COMPONENTS}}
        fingerprint = phase2.compare_diff(state, diff)
        self.assertTrue(fingerprint.startswith("sha256:"))
        diff["components"]["knowledge"]["files"].append("knowledge/knowledge-manifest.json")
        self.assertTrue(phase2.compare_diff(state, diff).startswith("sha256:"))
        diff["components"]["unplanned"] = {"changed": True}
        with self.assertRaisesRegex(phase2.PatchError, "component set differs"):
            phase2.compare_diff(state, diff)
        del diff["components"]["unplanned"]
        diff["components"]["agent"]["changed"] = True
        with self.assertRaisesRegex(phase2.PatchError, "diff differs|digest transition differs"):
            phase2.compare_diff(state, diff)
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}):
            with self.assertRaisesRegex(phase2.PatchError, "review diff"):
                phase2.run(self.args("publish", confirm_diff="sha256:wrong"))

    def test_diff_retains_reviewed_components_and_rejects_changed_response(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["precheckId"] = "pre-1"
        phase2.save(self.state, state)
        diff = {"schemaVersion": "config-patch-diff.v1", "components": {
            part: {"changed": part == "knowledge", "oldDigest": "sha256:" + "a" * 64,
                   "newDigest": "sha256:" + ("b" if part == "knowledge" else "a") * 64,
                   "files": ["knowledge/documents/FAQ.md"] if part == "knowledge" else []}
            for part in phase2.COMPONENTS}}
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "request", return_value=diff):
            phase2.run(self.args("diff"))
            self.assertEqual(phase2.load(self.state)["diffResult"], diff)
            diff["components"]["knowledge"]["files"].append("knowledge/knowledge-manifest.json")
            with self.assertRaisesRegex(phase2.PatchError, "server diff changed"):
                phase2.run(self.args("diff"))
        self.assertEqual(phase2.load(self.state)["diffResult"]["components"]["knowledge"]["files"],
                         ["knowledge/documents/FAQ.md"])

    def test_upload_replays_saved_key_and_rejects_tampered_archive(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["onlineContextDigest"] = "sha256:" + "c" * 64
        phase2.save(self.state, state)
        calls = []
        def fake_request(base, token, method, path, **kwargs):
            if method == "POST":
                calls.append(kwargs["key"])
                return {"uploadId": "upload-1", "botId": "practice", "agentId": "agent-practice",
                        "baseReleaseId": "R5", "archiveDigest": phase2.load(self.state)["archiveDigest"]}
            return {}
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), patch.object(phase2, "request", side_effect=fake_request):
            phase2.run(self.args("upload"))
            phase2.run(self.args("upload"))
            self.assertEqual(calls[0], calls[1])
            Path(phase2.load(self.state)["archive"]).write_bytes(b"tampered")
            with self.assertRaisesRegex(phase2.PatchError, "archive changed"):
                phase2.run(self.args("upload"))

    def test_precheck_blocker_keeps_only_diagnostic_fields(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["uploadId"] = "upload-1"
        phase2.save(self.state, state)
        result = {"precheckId": "pre-1", "status": "ABORTED", "canPublish": False,
                  "blockers": [{"code": "CONFIGURATION_INVALID", "path": "workspace",
                                "message": "Upstream validation failed", "missingItems": ["agent/config"],
                                "privateBody": "do not retain"}]}
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), patch.object(phase2, "request", return_value=result):
            with self.assertRaisesRegex(phase2.PatchError, "precheckId=pre-1.*workspace.*Upstream validation failed"):
                phase2.run(self.args("precheck"))
        saved = phase2.load(self.state)
        self.assertEqual(saved["precheckId"], "pre-1")
        self.assertEqual(saved["precheckResult"]["blockers"][0]["missingItems"], ["agent/config"])
        self.assertNotIn("privateBody", json.dumps(saved))

    def test_rollback_requires_active_publish(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["publishOperationId"] = "op-1"
        phase2.save(self.state, state)
        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "request", return_value={"status": "RECOVERY_REQUIRED"}):
            with self.assertRaisesRegex(phase2.PatchError, "not ACTIVE"):
                phase2.run(self.args("rollback", release_id="R5"))

    def test_rollback_stops_when_newer_release_exists(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["publishOperationId"] = "op-1"
        phase2.save(self.state, state)
        calls = []

        def fake_request(base, token, method, path, **kw):
            calls.append((method, path))
            if path.endswith("/operations/op-1"):
                return {"status": "ACTIVE", "metadata": {"releaseId": "R6"}}
            if path.endswith("/releases"):
                return [{"releaseId": "R6", "version": 6, "status": "ACTIVE"},
                        {"releaseId": "R7", "version": 7, "status": "ACTIVE"}]
            raise AssertionError(path)

        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "request", side_effect=fake_request):
            with self.assertRaisesRegex(phase2.PatchError, "newer Release"):
                phase2.run(self.args("rollback", release_id="R5"))
        self.assertTrue(all(method == "GET" for method, _ in calls))

    def test_unknown_publish_result_replays_same_key_without_new_precheck(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state.update(precheckId="pre-1", diffDigest="sha256:reviewed")
        phase2.save(self.state, state)
        calls = []

        def fake_request(base, token, method, path, **kw):
            calls.append((method, path, kw.get("key")))
            if method == "GET":
                return {"status": "PREPARED", "canPublish": True, "blockers": [],
                        "expiresAt": (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()}
            if len([call for call in calls if call[0] == "POST"]) == 1:
                raise phase2.PatchError("result unknown")
            return {"operationId": "op-1", "status": "ACTIVE"}

        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), \
                patch.object(phase2, "compare_diff", return_value="sha256:reviewed"), \
                patch.object(phase2, "request", side_effect=fake_request):
            with self.assertRaisesRegex(phase2.PatchError, "result unknown"):
                phase2.run(self.args("publish", confirm_diff="sha256:reviewed"))
            self.assertIn("publishAttemptedAt", phase2.load(self.state))
            self.assertEqual(phase2.run(self.args("publish", confirm_diff="sha256:reviewed"))["operationId"], "op-1")
        posts = [call for call in calls if call[0] == "POST"]
        self.assertEqual(len(posts), 2)
        self.assertEqual(posts[0][2], posts[1][2])
        self.assertEqual(len([call for call in calls if call[0] == "GET"]), 2)

    def test_unknown_rollback_result_replays_same_target_and_key(self):
        phase2.run(self.args("prepare"))
        state = phase2.load(self.state)
        state["publishOperationId"] = "publish-1"
        phase2.save(self.state, state)
        posts = []

        def fake_request(base, token, method, path, **kw):
            if path.endswith("/releases"):
                return [{"releaseId": "R5", "version": 5, "status": "ACTIVE"},
                        {"releaseId": "R6", "version": 6, "status": "ACTIVE"}]
            if method == "GET":
                return {"status": "ACTIVE", "metadata": {"releaseId": "R6"}}
            posts.append((path, kw["key"]))
            if len(posts) == 1:
                raise phase2.PatchError("result unknown")
            return {"operationId": "rollback-1", "status": "ACTIVE"}

        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), patch.object(phase2, "request", side_effect=fake_request):
            with self.assertRaisesRegex(phase2.PatchError, "result unknown"):
                phase2.run(self.args("rollback", release_id="R5"))
            self.assertEqual(phase2.load(self.state)["rollbackTargetReleaseId"], "R5")
            self.assertEqual(phase2.run(self.args("rollback", release_id="R5"))["operationId"], "rollback-1")
        self.assertEqual(posts[0], posts[1])

    def test_full_client_loop_preserves_history_and_rollback_release(self):
        phase2.run(self.args("prepare"))
        base = phase2.load(self.state)
        releases = ["R5"]
        events = []
        current = ["R5"]
        diff = {"schemaVersion": "config-patch-diff.v1", "components": {
            part: {"changed": part == "knowledge", "oldDigest": "sha256:" + "a" * 64,
                   "newDigest": "sha256:" + ("b" if part == "knowledge" else "a") * 64,
                   "files": ["knowledge/documents/FAQ.md"] if part == "knowledge" else []}
            for part in phase2.COMPONENTS}}
        precheck = {"precheckId": "pre-1", "status": "PREPARED", "canPublish": True,
                    "blockers": [], "expiresAt": (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()}

        def fake_request(base_url, token, method, path, **kw):
            events.append((method, path, kw.get("key")))
            if path.endswith("/configuration-context"):
                return {"botId": "practice", "boundAgentId": "agent-practice", "currentReleaseId": current[0]}
            if path.endswith("/workspace-bundles/uploads"):
                return {"uploadId": "up-1", "botId": "practice", "agentId": "agent-practice",
                        "baseReleaseId": "R5", "archiveDigest": base["archiveDigest"]}
            if path.endswith("/workspace-bundles/uploads/up-1"):
                return {"uploadId": "up-1", "status": "validated"}
            if path.endswith("/releases/prechecks"):
                return precheck
            if path.endswith("/releases/prechecks/pre-1"):
                return precheck
            if path.endswith("/releases/prechecks/pre-1/diff"):
                return diff
            if method == "POST" and path.endswith("/releases"):
                releases.append("R6")
                current[0] = "R6"
                return {"operationId": "op-pub", "status": "ACTIVE", "metadata": {"releaseId": "R6"}}
            if path.endswith("/operations/op-pub"):
                return {"operationId": "op-pub", "status": "ACTIVE", "metadata": {"releaseId": "R6"}}
            if method == "POST" and path.endswith("/releases/R5/rollback"):
                releases.append("R7")
                current[0] = "R7"
                return {"operationId": "op-roll", "status": "ACTIVE", "metadata": {"releaseId": "R7"}}
            if path.endswith("/operations/op-roll"):
                return {"operationId": "op-roll", "status": "ACTIVE", "metadata": {"releaseId": "R7"}}
            if path.endswith("/releases"):
                return [{"releaseId": release, "version": int(release[1:]), "status": "ACTIVE"}
                        for release in releases]
            raise AssertionError((method, path))

        with patch.dict(os.environ, {"CONFIG_PATCH_STAFF_TOKEN": "local-test-only"}), \
                patch.object(phase2, "ensure_live_target"), patch.object(phase2, "request", side_effect=fake_request):
            self.assertEqual(phase2.run(self.args("online-baseline"))["currentReleaseId"], "R5")
            self.assertEqual(phase2.run(self.args("upload"))["uploadId"], "up-1")
            self.assertTrue(phase2.run(self.args("online-unchanged"))["unchanged"])
            self.assertEqual(phase2.run(self.args("precheck"))["status"], "PREPARED")
            reviewed = phase2.run(self.args("diff"))["diffDigest"]
            self.assertEqual(phase2.run(self.args("publish", confirm_diff=reviewed))["metadata"]["releaseId"], "R6")
            self.assertEqual(phase2.run(self.args("operation"))["status"], "ACTIVE")
            self.assertEqual([item["releaseId"] for item in phase2.run(self.args("releases"))], ["R5", "R6"])
            self.assertEqual(phase2.run(self.args("rollback", release_id="R5"))["metadata"]["releaseId"], "R7")
            self.assertEqual(phase2.run(self.args("operation"))["operationId"], "op-roll")
            self.assertEqual([item["releaseId"] for item in phase2.run(self.args("releases"))], ["R5", "R6", "R7"])
        self.assertEqual(len([event for event in events if event[0] == "POST" and event[1].endswith("/releases")]), 1)
        self.assertEqual(len([event for event in events if event[0] == "POST" and event[1].endswith("/rollback")]), 1)


if __name__ == "__main__":
    unittest.main()
