# Agent 首次导入基础包

`生成.py` 从 `$dclaw-agent-config` 的 `assets/agent-base-template.zip` 中性母版生成一个基础交付包 ZIP。包内包含 DClaw Agent 首次导入 ZIP、独立的 `客户标签配置.json` 初始结构及导入说明。母版只含技术结构与通用协议，不含客户产品、价格、对客身份或接待流程。

先核对客户名称、销售或售后、目标环境，拟定唯一 Agent ID 并请用户确认。确认后运行：

```powershell
python -X utf8 工具/Agent基础包/生成.py create --customer "<客户名称>" --purpose 销售 --environment 正式 --agent-id <已确认ID>
```

默认输出到 `Agent项目/<客户名称>-<用途>Agent基础包/`。如该客户已有专用目录，可用 `--output-dir` 指定；已有同名交付包不会被覆盖。工具检查内外层 ZIP 回读、ID、工作区路径、加载文件、技能引用、占位替换及标签 JSON 结构。标签组和提醒／接管占位均禁用，业务触发条件、处理人及动作须在取得客户资料后确认。管理员解压总 ZIP 后分别导入 Agent ZIP 和标签 JSON；总 ZIP 本身不是 Agent 平台的直接导入文件。平台导入、权限、Bot 绑定和后续业务配置须分别验证；本地生成不代表平台生效。
