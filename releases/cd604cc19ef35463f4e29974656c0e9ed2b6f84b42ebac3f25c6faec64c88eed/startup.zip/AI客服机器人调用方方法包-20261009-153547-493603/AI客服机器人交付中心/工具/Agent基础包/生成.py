"""Build a first-import DClaw Agent ZIP from the neutral runtime template."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile


TEMPLATE_ROOT = "__WORKSPACE_SLUG__/"
PLACEHOLDERS = ("__AGENT_ID__", "__WORKSPACE_SLUG__", "__PURPOSE__", "__ENVIRONMENT__")
ID_PATTERN = re.compile(r"[a-z][a-z0-9_]{2,63}\Z")


def template_path() -> Path:
    project = Path(__file__).resolve().parents[2]
    local = project / ".agents/skills/dclaw-agent-config/assets/agent-base-template.zip"
    user = Path.home() / ".codex/skills/dclaw-agent-config/assets/agent-base-template.zip"
    for path in (local, user):
        if path.is_file():
            return path
    raise FileNotFoundError("缺少 Agent 技术母版 ZIP")


def members(path: Path, expected_root: str) -> dict[str, bytes]:
    result = {}
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP 完整性检查失败")
        for info in archive.infolist():
            name = info.filename
            parts = PurePosixPath(name).parts
            if info.is_dir() or not name.startswith(expected_root) or ".." in parts or "\\" in name or ":" in name:
                raise ValueError(f"异常 ZIP 路径: {name}")
            if name in result:
                raise ValueError(f"重复 ZIP 成员: {name}")
            result[name] = archive.read(info)
    return result


def validate(contents: dict[str, bytes], root: str, agent_id: str) -> None:
    agent = json.loads(contents[root + "agent.json"])
    skills = json.loads(contents[root + "skill.json"])
    if agent["id"] != agent_id or agent["workspace_dir"] != f"/app/working/workspaces/{agent_id}":
        raise ValueError("Agent ID 与工作区路径不一致")
    if agent["name"] != agent_id:
        raise ValueError("技术展示名称与 Agent ID 不一致")
    required = {root + name for name in agent["system_prompt_files"]}
    required.update(root + f"skills/{name}/SKILL.md" for name, item in skills["skills"].items() if item["enabled"])
    if required.difference(contents):
        raise ValueError("缺少实际加载文件或启用技能")
    for name, data in contents.items():
        body = data.decode("utf-8")
        if any(token in body for token in PLACEHOLDERS):
            raise ValueError(f"母版占位未清除: {name}")
        if any(part in name.lower() for part in ("sessions_data", "conversations", ".ds_store", "__macosx")):
            raise ValueError(f"包含运行期或归档元数据: {name}")


def initial_tags(agent_id: str) -> dict:
    suffix = hashlib.sha256(agent_id.encode("ascii")).hexdigest()[:12]
    inactive_condition = "尚无已确认的业务触发条件；本标签禁用，待确认触发证据、处理人和撤销条件后配置。"

    def tag(action: str, name: str) -> dict:
        return {
            "id": f"tag_{action}_{suffix}",
            "name": name,
            "condition": inactive_condition,
            "evidenceMode": "customer",
            "enabled": False,
            "voiceAlertEnabled": False,
            "handoffEnabled": False,
            "activation": {"enabled": False, "polishByAgent": False, "messages": []},
        }

    return {
        "dateTag": {"enabled": False, "cutoffTime": "00:00"},
        "groups": [{
            "id": f"group_actions_{suffix}",
            "name": "人工处理待配置",
            "enabled": False,
            "exclusive": False,
            "oneWay": False,
            "tags": [tag("alert", "语音提醒待配置"), tag("handoff", "人工接管待配置")],
        }],
    }


def create(customer: str, purpose: str, environment: str, agent_id: str, output_dir: Path | None) -> None:
    if not ID_PATTERN.fullmatch(agent_id):
        raise ValueError("Agent ID 须为小写字母开头，后接小写字母、数字或下划线，长度 3-64")
    if not customer.strip():
        raise ValueError("客户名称不能为空")
    slug = agent_id.replace("_", "-") + "-agent"
    if output_dir is None:
        folder = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "-", customer.strip())[:60]
        output_dir = Path(__file__).resolve().parents[2] / "Agent项目" / f"{folder}-{purpose}Agent基础包"
    output = output_dir / f"{agent_id}_基础交付包_v1.zip"
    if output.exists():
        raise FileExistsError("目标基础交付包已存在；请指定新版本目录，不能覆盖")

    source = members(template_path(), TEMPLATE_ROOT)
    replacements = {
        "__AGENT_ID__": agent_id,
        "__WORKSPACE_SLUG__": slug,
        "__PURPOSE__": purpose,
        "__ENVIRONMENT__": environment,
    }
    result = {}
    for name, data in source.items():
        body = data.decode("utf-8")
        for old, new in replacements.items():
            body = body.replace(old, new)
        new_name = slug + "/" + name.removeprefix(TEMPLATE_ROOT)
        result[new_name] = body.encode("utf-8")
    validate(result, slug + "/", agent_id)

    agent_buffer = io.BytesIO()
    with zipfile.ZipFile(agent_buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(result.items()):
            archive.writestr(name, data)
    agent_zip = agent_buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(agent_zip)) as archive:
        if archive.testzip() is not None or {name: archive.read(name) for name in archive.namelist()} != result:
            raise ValueError("Agent 导入 ZIP 回读与预期内容不一致")

    tags = initial_tags(agent_id)
    tags_data = (json.dumps(tags, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    agent_member = f"{agent_id}_Agent首次导入.zip"
    note = (
        "本包有两项独立平台配置。先解压，再将 Agent首次导入.zip 上传至 DClaw Agent 导入入口；"
        "客户标签配置.json 交标签配置入口导入并回读。标签均禁用，取得客户业务规则、处理人和动作确认后才启用。"
        "导入或绑定成功不等于业务配置已发布。\n"
    ).encode("utf-8")
    bundled = {agent_member: agent_zip, "客户标签配置.json": tags_data, "导入说明.txt": note}
    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in bundled.items():
            archive.writestr(name, data)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None or {name: archive.read(name) for name in archive.namelist()} != bundled:
            raise ValueError("基础交付包回读与预期内容不一致")
    digest = hashlib.sha256(output.read_bytes()).hexdigest().upper()
    print(json.dumps({"customer": customer, "purpose": purpose, "environment": environment,
                      "agent_id": agent_id, "zip": str(output), "agent_import_member": agent_member,
                      "tags_member": "客户标签配置.json", "files": len(result), "sha256": digest,
                      "tags_enabled": False}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    new = commands.add_parser("create", help="从母版生成客户专属首次导入 ZIP")
    new.add_argument("--customer", required=True)
    new.add_argument("--purpose", choices=("销售", "售后"), required=True)
    new.add_argument("--environment", choices=("测试", "正式"), required=True)
    new.add_argument("--agent-id", required=True)
    new.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    create(args.customer, args.purpose, args.environment, args.agent_id, args.output_dir)


if __name__ == "__main__":
    main()
