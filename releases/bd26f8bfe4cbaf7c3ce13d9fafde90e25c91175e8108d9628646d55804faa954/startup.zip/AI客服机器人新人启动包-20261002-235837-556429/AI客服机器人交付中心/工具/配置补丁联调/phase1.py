"""Read-only phase-one client for the AI customer service patch API."""

import argparse
from hashlib import sha256
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import time
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
import zipfile


API_PREFIX = "/staff/v1"
MAX_FILES = 2000
MAX_FILE_SIZE = 32 * 1024 * 1024
MAX_TOTAL_SIZE = 256 * 1024 * 1024
MAX_RATIO = 1000


class Phase1Error(Exception):
    pass


class PathValidationError(Phase1Error):
    pass


def api_request(base_url, token, method, path, *, export=False):
    url = base_url.rstrip("/") + API_PREFIX + path
    request = Request(url, method=method, headers={"Authorization": f"Bearer {token}"})
    for attempt in range(3):
        try:
            with urlopen(request, timeout=120 if export else 30) as response:
                return response.read(), response.headers
        except HTTPError as error:
            detail = {}
            try:
                detail = json.loads(error.read()).get("detail", {})
            except (ValueError, AttributeError):
                pass
            if error.code in (502, 503) and attempt < 2:
                time.sleep((2, 5)[attempt])
                continue
            raise Phase1Error(
                f"{method} {path}: HTTP {error.code}, detail.code={detail.get('code')}, "
                f"missingItems={detail.get('missingItems', [])}"
            ) from None
        except (URLError, TimeoutError) as error:
            raise Phase1Error(f"{method} {path}: connection failed ({type(error).__name__})") from None
    raise AssertionError("retry loop exhausted")


def get_json(base_url, token, path):
    body, _ = api_request(base_url, token, "GET", path)
    try:
        result = json.loads(body)
    except ValueError as error:
        raise Phase1Error(f"GET {path}: invalid JSON") from error
    if not isinstance(result, dict):
        raise Phase1Error(f"GET {path}: expected JSON object")
    return result


def discover(base_url, token):
    identity = get_json(base_url, token, "/whoami")
    if not identity.get("tokenId") or not identity.get("employeeName"):
        raise Phase1Error("whoami is missing tokenId or employeeName")
    catalog = get_json(base_url, token, "/capabilities")
    if catalog.get("schemaVersion") != "capability-catalog.v1" or not isinstance(catalog.get("profiles"), dict):
        raise Phase1Error("unsupported capability catalog")
    listing = get_json(base_url, token, "/bots")
    if not isinstance(listing.get("bots"), list):
        raise Phase1Error("Bot list is missing bots array")
    return identity, catalog, listing["bots"]


def check_context(bot, context, catalog):
    if context.get("botId") != bot.get("botId"):
        raise Phase1Error("context Bot ID differs from selected Bot")
    if context.get("boundAgentId") != bot.get("boundAgentId"):
        raise Phase1Error("Bot-Agent binding changed; select Bot again")
    profile = context.get("agentProfileId")
    if profile != bot.get("agentProfileId") or profile not in catalog["profiles"]:
        raise Phase1Error("Agent Profile is missing or changed")
    readiness = context.get("readiness") or {}
    if readiness.get("ready") is not True:
        raise Phase1Error(
            f"Bot not ready: code={readiness.get('code')}, missingItems={readiness.get('missingItems', [])}"
        )
    if not isinstance(context.get("flowMachine"), dict) or not isinstance(context.get("tags"), dict):
        raise Phase1Error("context is missing current flowMachine or tags")


def validate_zip_members(archive):
    names = set()
    portable_names = set()
    portable_files = set()
    total = 0
    infos = archive.infolist()
    if len(infos) > MAX_FILES:
        raise Phase1Error("ZIP exceeds file count limit")
    for info in infos:
        name = info.filename
        path = PurePosixPath(name)
        normalized = name.rstrip("/")
        parts = normalized.split("/")
        portable = unicodedata.normalize("NFC", unicodedata.normalize("NFC", normalized).casefold())
        windows_unsafe = any(
            any(char in part for char in '<>:"|?*') or
            any(ord(char) < 32 or ord(char) == 127 for char in part) or
            part.endswith((" ", ".")) or
            part.upper().split(".", 1)[0] in
            {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}
            for part in parts
        )
        if (not name or name.startswith("/") or name.endswith("//") or "\\" in name or
                any(part in ("", ".", "..") for part in name.rstrip("/").split("/")) or
                path.is_absolute() or windows_unsafe or portable in portable_names):
            raise PathValidationError(f"unsafe ZIP path: {name!r}")
        names.add(normalized)
        portable_names.add(portable)
        if len(parts) >= 2 and parts[0] == "agent" and parts[1] in {
            "sessions_data", "tool_results", "file_store", "backup"
        }:
            raise PathValidationError(f"runtime directory in ZIP: {name!r}")
        mode = (info.external_attr >> 16) & 0xFFFF
        file_type = stat.S_IFMT(mode)
        if file_type not in (0, stat.S_IFREG, stat.S_IFDIR):
            raise Phase1Error(f"non-regular ZIP member: {name!r}")
        if info.is_dir():
            continue
        portable_files.add(portable)
        if info.file_size > MAX_FILE_SIZE:
            raise Phase1Error(f"ZIP member exceeds size limit: {name!r}")
        if info.file_size and info.file_size / max(info.compress_size, 1) > MAX_RATIO:
            raise Phase1Error(f"ZIP member exceeds compression ratio limit: {name!r}")
        total += info.file_size
        if total > MAX_TOTAL_SIZE:
            raise Phase1Error("ZIP exceeds total expanded size limit")
    for name in portable_names:
        if any("/".join(name.split("/")[:count]) in portable_files
               for count in range(1, len(name.split("/")))):
            raise PathValidationError(f"ZIP file conflicts with directory: {name!r}")
    required = {
        "dclaw-manifest.json", "AGENTS.md", "change-plan.yaml",
        "knowledge/knowledge-manifest.json", "customer-service/flow-machine.json",
        "customer-service/tag-schema.json", "platform/capability-catalog.json",
    }
    missing = required - names
    if missing:
        raise Phase1Error(f"ZIP missing required files: {sorted(missing)}")


def validate_bundle(data, headers, bot, context, catalog):
    content_type = headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
    release = headers.get("X-DClaw-Release-Id", "")
    digest = headers.get("X-DClaw-Bundle-Digest", "")
    actual_digest = "sha256:" + sha256(data).hexdigest()
    if content_type != "application/zip" or not release or digest != actual_digest:
        raise Phase1Error("ZIP Content-Type, Release or SHA-256 response header invalid")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            validate_zip_members(archive)
            manifest = json.loads(archive.read("dclaw-manifest.json"))
            bundled_catalog = json.loads(archive.read("platform/capability-catalog.json"))
            if archive.testzip() is not None:
                raise Phase1Error("ZIP member CRC failed")
    except (zipfile.BadZipFile, ValueError, KeyError) as error:
        raise Phase1Error(f"invalid ZIP or manifest: {type(error).__name__}") from error
    checks = {
        "schemaVersion": "customer-service-workspace.v1",
        "botId": bot["botId"],
        "agentId": context["boundAgentId"],
        "agentProfileId": context["agentProfileId"],
        "baseReleaseId": release,
        "capabilityCatalogVersion": catalog["version"],
    }
    for field, expected in checks.items():
        if manifest.get(field) != expected:
            raise Phase1Error(f"Manifest {field} does not match current API")
    fingerprints = manifest.get("sourceFingerprints") or {}
    if any(not isinstance(fingerprints.get(part), str) or
           re.fullmatch(r"sha256:[0-9a-f]{64}", fingerprints[part]) is None
           for part in ("agent", "knowledge", "flow", "tags")):
        raise Phase1Error("Manifest source fingerprints have invalid SHA-256 format")
    if bundled_catalog.get("version") != manifest["capabilityCatalogVersion"]:
        raise Phase1Error("bundled capability catalog version mismatch")
    return release, actual_digest, manifest


def save_rejected_bundle(output, data, headers, reason):
    rejected = output.resolve() / "校验失败工作包"
    rejected.mkdir(parents=True, exist_ok=True)
    target = Path(tempfile.mkdtemp(prefix="path-", dir=rejected))
    (target / "workspace.zip").write_bytes(data)
    record = {
        "reason": str(reason),
        "headers": {key: headers.get(key) for key in
                    ("Content-Type", "X-DClaw-Release-Id", "X-DClaw-Bundle-Digest")},
        "actualDigest": "sha256:" + sha256(data).hexdigest(),
    }
    (target / "validation-error.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return target


def save_bundle(output, data, headers, release, catalog, context):
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    target = output / "平台基线" / release
    if target.exists():
        raise Phase1Error(f"baseline already exists; refusing overwrite: {target}")
    work = output / "当前工作区"
    if work.exists():
        raise Phase1Error(f"working copy already exists; refusing overwrite: {work}")
    temp = Path(tempfile.mkdtemp(prefix="phase1-", dir=output))
    try:
        extracted = temp / "extracted"
        extracted.mkdir()
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for info in archive.infolist():
                destination = extracted.joinpath(*PurePosixPath(info.filename).parts)
                if info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                else:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(info) as source, destination.open("wb") as sink:
                        shutil.copyfileobj(source, sink)
        (temp / "workspace.zip").write_bytes(data)
        response_headers = {
            key: headers.get(key) for key in
            ("Content-Type", "X-DClaw-Release-Id", "X-DClaw-Bundle-Digest")
        }
        (temp / "response-headers.json").write_text(
            json.dumps(response_headers, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (temp / "capability-catalog.json").write_text(
            json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (temp / "configuration-context.json").write_text(
            json.dumps(context, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(temp), str(target))
    finally:
        if temp.exists():
            shutil.rmtree(temp)
    shutil.copytree(target / "extracted", work)
    return target, work


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("discover", "export"))
    parser.add_argument("--bot-id", help="Bot ID explicitly selected by the employee")
    parser.add_argument("--output", type=Path, help="private local customer task directory")
    args = parser.parse_args()
    base_url = os.environ.get("CONFIG_PATCH_BASE_URL", "").rstrip("/")
    token = os.environ.get("CONFIG_PATCH_STAFF_TOKEN", "")
    if not base_url.startswith("https://") or not token:
        raise Phase1Error("set HTTPS CONFIG_PATCH_BASE_URL and CONFIG_PATCH_STAFF_TOKEN")
    if args.command == "export" and (not args.bot_id or not args.output):
        parser.error("export requires --bot-id and --output")
    identity, catalog, bots = discover(base_url, token)
    result = {
        "environment": base_url,
        "employeeName": identity["employeeName"],
        "tokenId": identity["tokenId"],
        "catalogVersion": catalog["version"],
        "bots": [
            {key: bot.get(key) for key in ("botId", "botName", "boundAgentId", "agentProfileId", "readiness")}
            for bot in bots
        ],
    }
    if args.command == "export":
        bot = next((item for item in bots if item.get("botId") == args.bot_id), None)
        if bot is None:
            raise Phase1Error("selected Bot ID is not in the current Bot list")
        if (bot.get("readiness") or {}).get("ready") is not True:
            raise Phase1Error(f"selected Bot is not ready: {(bot.get('readiness') or {}).get('missingItems', [])}")
        path = "/bots/" + quote(args.bot_id, safe="")
        context = get_json(base_url, token, path + "/configuration-context")
        check_context(bot, context, catalog)
        data, headers = api_request(base_url, token, "POST", path + "/workspace-bundles/export", export=True)
        try:
            release, digest, _ = validate_bundle(data, headers, bot, context, catalog)
        except PathValidationError as error:
            rejected = save_rejected_bundle(args.output, data, headers, error)
            raise Phase1Error(f"{error}; original ZIP saved at {rejected}; stop development and report to server") from error
        baseline, work = save_bundle(args.output, data, headers, release, catalog, context)
        result = {key: result[key] for key in ("environment", "employeeName", "tokenId", "catalogVersion")}
        result.update({"botId": args.bot_id, "release": release, "digest": digest,
                       "baseline": str(baseline), "workingCopy": str(work)})
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    try:
        main()
    except Phase1Error as error:
        print(f"联调失败: {error}", file=sys.stderr)
        raise SystemExit(1) from None
