"""Focused checks for bundle validation; no network or real credentials."""

from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile


spec = importlib.util.spec_from_file_location("phase1", Path(__file__).with_name("phase1.py"))
phase1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(phase1)


def bundle(fingerprints=None, extra=None):
    fingerprints = fingerprints or {
        key: "sha256:" + character * 64
        for key, character in (("agent", "a"), ("knowledge", "b"), ("flow", "c"), ("tags", "d"))
    }
    manifest = {
        "schemaVersion": "customer-service-workspace.v1",
        "botId": "selected-bot",
        "agentId": "bound-agent",
        "agentProfileId": "standard-2026.09",
        "baseReleaseId": "R7",
        "capabilityCatalogVersion": "2026.09.30",
        "sourceFingerprints": fingerprints,
    }
    files = {
        "dclaw-manifest.json": json.dumps(manifest),
        "AGENTS.md": "local instructions",
        "change-plan.yaml": "schemaVersion: customer-service-change-plan.v1",
        "knowledge/knowledge-manifest.json": "{}",
        "customer-service/flow-machine.json": "{}",
        "customer-service/tag-schema.json": "{}",
        "platform/capability-catalog.json": json.dumps({"version": "2026.09.30"}),
    }
    files.update(extra or {})
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, contents in files.items():
            archive.writestr(name, contents)
    data = output.getvalue()
    headers = {
        "Content-Type": "application/zip",
        "X-DClaw-Release-Id": "R7",
        "X-DClaw-Bundle-Digest": "sha256:" + sha256(data).hexdigest(),
    }
    return data, headers


BOT = {"botId": "selected-bot"}
CONTEXT = {"boundAgentId": "bound-agent", "agentProfileId": "standard-2026.09"}
CATALOG = {"version": "2026.09.30"}


class BundleValidationTests(unittest.TestCase):
    def test_valid_bundle(self):
        data, headers = bundle()
        release, digest, manifest = phase1.validate_bundle(data, headers, BOT, CONTEXT, CATALOG)
        self.assertEqual(release, "R7")
        self.assertEqual(digest, headers["X-DClaw-Bundle-Digest"])
        self.assertEqual(manifest["botId"], "selected-bot")

    def test_raw_hex_fingerprint_is_rejected(self):
        fingerprints = {
            key: "sha256:" + character * 64
            for key, character in (("agent", "a"), ("knowledge", "b"), ("flow", "c"), ("tags", "d"))
        }
        fingerprints["flow"] = "a" * 64
        data, headers = bundle(fingerprints)
        with self.assertRaisesRegex(phase1.Phase1Error, "fingerprints have invalid"):
            phase1.validate_bundle(data, headers, BOT, CONTEXT, CATALOG)

    def test_short_or_uppercase_fingerprint_is_rejected(self):
        for invalid in ("sha256:abc", "sha256:" + "A" * 64):
            with self.subTest(invalid=invalid):
                fingerprints = {
                    key: "sha256:" + character * 64
                    for key, character in (("agent", "a"), ("knowledge", "b"), ("flow", "c"), ("tags", "d"))
                }
                fingerprints["tags"] = invalid
                data, headers = bundle(fingerprints)
                with self.assertRaisesRegex(phase1.Phase1Error, "fingerprints have invalid"):
                    phase1.validate_bundle(data, headers, BOT, CONTEXT, CATALOG)

    def test_digest_mismatch_is_rejected(self):
        data, headers = bundle()
        headers["X-DClaw-Bundle-Digest"] = "sha256:" + "0" * 64
        with self.assertRaisesRegex(phase1.Phase1Error, "SHA-256"):
            phase1.validate_bundle(data, headers, BOT, CONTEXT, CATALOG)

    def test_unsafe_paths_are_rejected(self):
        for name in ("../escape", "/absolute", "C:/drive", "agent/CON.txt",
                     "agent/trailing.", "agent/source:old.txt"):
            with self.subTest(name=name):
                data, _ = bundle(extra={name: "unsafe"})
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    with self.assertRaisesRegex(phase1.Phase1Error, "unsafe ZIP path"):
                        phase1.validate_zip_members(archive)

    def test_backslash_member_is_rejected(self):
        class RawMember:
            filename = "folder\\file"
            external_attr = 0
            file_size = 0
            compress_size = 0

            def is_dir(self):
                return False

        class RawArchive:
            def infolist(self):
                return [RawMember()]

        with self.assertRaisesRegex(phase1.Phase1Error, "unsafe ZIP path"):
            phase1.validate_zip_members(RawArchive())

    def test_save_creates_immutable_baseline_and_work_copy(self):
        data, headers = bundle(extra={"agent/source.txt": "source"})
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            baseline, work = phase1.save_bundle(root, data, headers, "R7", CATALOG, CONTEXT)
            self.assertEqual((baseline / "workspace.zip").read_bytes(), data)
            self.assertTrue((baseline / "extracted" / "AGENTS.md").exists())
            self.assertTrue((work / "AGENTS.md").exists())
            self.assertEqual((work / "agent/source.txt").read_text(), "source")
            self.assertFalse((baseline / "archive-path-map.json").exists())
            with self.assertRaisesRegex(phase1.Phase1Error, "refusing overwrite"):
                phase1.save_bundle(root, data, headers, "R7", CATALOG, CONTEXT)

    def test_runtime_directories_are_rejected(self):
        data, _ = bundle(extra={"agent/sessions_data/history.txt": "runtime"})
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            with self.assertRaisesRegex(phase1.Phase1Error, "runtime directory"):
                phase1.validate_zip_members(archive)

    def test_windows_case_collision_is_rejected(self):
        data, _ = bundle(extra={"agent/Rule.md": "one", "agent/rule.md": "two"})
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            with self.assertRaisesRegex(phase1.Phase1Error, "unsafe ZIP path"):
                phase1.validate_zip_members(archive)

    def test_unicode_normalization_collision_is_rejected(self):
        data, _ = bundle(extra={"agent/caf\u00e9.md": "one", "agent/cafe\u0301.md": "two"})
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            with self.assertRaisesRegex(phase1.PathValidationError, "unsafe ZIP path"):
                phase1.validate_zip_members(archive)

    def test_ascii_control_character_is_rejected(self):
        for name in ("agent/bad\nname.md", "agent/bad\x7fname.md"):
            with self.subTest(name=name):
                data, _ = bundle(extra={name: "unsafe"})
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    with self.assertRaisesRegex(phase1.PathValidationError, "unsafe ZIP path"):
                        phase1.validate_zip_members(archive)

    def test_file_and_directory_collision_is_rejected(self):
        data, _ = bundle(extra={"agent/Rule": "file", "agent/rule/child.md": "nested"})
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            with self.assertRaisesRegex(phase1.PathValidationError, "conflicts with directory"):
                phase1.validate_zip_members(archive)

    def test_rejected_zip_is_preserved_without_mapping(self):
        data, headers = bundle(extra={"agent/CON.txt": "unsafe"})
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            saved = phase1.save_rejected_bundle(root, data, headers, "unsafe ZIP path")
            self.assertEqual((saved / "workspace.zip").read_bytes(), data)
            record = json.loads((saved / "validation-error.json").read_text(encoding="utf-8"))
            self.assertEqual(record["actualDigest"], headers["X-DClaw-Bundle-Digest"])
            self.assertFalse((root / "当前工作区").exists())


if __name__ == "__main__":
    unittest.main()
