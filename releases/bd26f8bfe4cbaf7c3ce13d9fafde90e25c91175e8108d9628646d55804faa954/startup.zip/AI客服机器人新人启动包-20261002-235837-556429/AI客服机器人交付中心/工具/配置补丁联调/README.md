# 第一阶段配置补丁联调工具

后续联调和本地开发以 [调用方 API 文档](../../平台接口/caller-ai-config-patch-phase1-integration-guide.zh-CN.md) 与 [调用方 AI 开发决策指南](../../平台接口/caller-ai-development-decision-guide.zh-CN.md) 的当前保存版本为准。

`phase1.py` 只调用已开放的身份、能力目录、Bot 列表、配置上下文和工作包导出接口。不会上传、预检、发布或回滚。使用 Python 3.11 标准库，无额外依赖。

先在本机进程环境中设置 `CONFIG_PATCH_BASE_URL`（HTTPS）和 `CONFIG_PATCH_STAFF_TOKEN`，不要将 Token 写入命令、文档、项目文件或 Git。运行：

```powershell
py .\工具\配置补丁联调\phase1.py discover
```

员工从输出列表明确选择 Bot，核对身份与环境后，指定该 Bot ID 和本地客户任务目录：

```powershell
py .\工具\配置补丁联调\phase1.py export --bot-id <已确认BotID> --output <本地客户任务目录>
```

导出前重跑身份、能力和 Bot 列表，检查上下文绑定与 readiness；导出后校验响应头、SHA-256、Manifest、ZIP 路径与内容。只有全部通过，才创建 `平台基线/<Release>/` 与 `当前工作区/`。已有基线或工作副本不会被覆盖。客户资料及真实工作包应放在私有目录；本项目中的 `客户/**/第一阶段接口联调/` 已被 Git 忽略。

ZIP 中若有 Windows 不可用的路径、Unicode 规范化或大小写重复路径、运行期目录，校验直接失败。路径校验失败会将原始 ZIP、摘要和必要响应头保存到 `校验失败工作包/`；停止本次开发并反馈服务端。通过校验的工作包按原路径解压，不重命名、转义或映射文件与目录。R5 后续工作应从 R5 原始基线建立工作副本，不沿用 R4 的映射副本。

测试：`py -m unittest discover -s .\工具\配置补丁联调 -p 'test_*.py'`。

macOS 或 Linux 使用本机 Python 3.11 的 `python3` 运行同一脚本，参数和环境变量名相同；先确认工作包原路径校验通过。练习输出放在本机 `练习/星禾口语课程咨询/平台工作包/`，真实客户输出放在其独立客户目录，不共享基线或工作副本。
