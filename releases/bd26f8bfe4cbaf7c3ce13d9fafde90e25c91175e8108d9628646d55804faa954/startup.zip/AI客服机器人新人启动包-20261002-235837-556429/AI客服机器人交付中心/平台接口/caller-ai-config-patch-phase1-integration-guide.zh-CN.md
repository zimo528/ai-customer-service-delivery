# AI 客服配置补丁 API 文档（调用方 AI）

> 文档状态：已部署接口的正式契约
>
> 适用阶段：第一阶段，只读接入与可信工作包导出
>
> 适用对象：`ai-customer-service-delivery`、调用方 Codex 和员工本地开发工具
>
> 配套文档：[调用方 AI 开发决策指南](./caller-ai-development-decision-guide.zh-CN.md)

本文只描述调用方当前能够实际调用的员工 API。需求应修改 Agent、经验库、状态机还是标签，以及如何设计协同修改，见配套的开发决策指南。

## 1. 接入模型

调用方只访问所选 AI 客服环境的员工 API，不直接访问 DClaw 内部接口：

```text
调用方 AI / Codex
  │  员工 Codex Token
  ▼
AI 客服配置补丁 API（测试或正式）
  ├─ 读取本环境 Bot、状态机和标签
  ├─ 使用本环境固定集成身份读取 DClaw
  └─ 聚合可信工作包
       ├─ Agent
       ├─ 经验库
       ├─ 状态机
       ├─ 标签
       └─ 平台能力与职责说明
```

重要规则：

1. Bot 是调用方唯一选择入口。
2. Agent ID、经验库、OpenAPI 发布对象、状态机和标签目标由服务端根据 Bot 当前绑定解析。
3. 调用方不得传入、猜测或替换 Agent ID。
4. 测试和正式使用不同 Base URL、不同员工 Token 和相互隔离的数据。
5. 两个 AI 客服环境均连接同一套正式 DClaw；相同 `agentId` 对应同一个 DClaw Agent，这是预期行为。
6. 普通专家和超级专家使用同一套员工 API。调用方只使用能力目录，不接触超级专家的加密、密钥或内部产物。

## 2. 当前能力边界

### 2.1 已开放

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/staff/v1/whoami` | 验证 Token 和当前员工身份 |
| `GET` | `/staff/v1/capabilities` | 获取动态平台能力目录 |
| `GET` | `/staff/v1/bots` | 列出本环境全部 Bot 及其就绪状态 |
| `GET` | `/staff/v1/bots/{botId}/configuration-context` | 读取指定 Bot 的当前配置上下文 |
| `POST` | `/staff/v1/bots/{botId}/workspace-bundles/export` | 导出可信只读工作包 |

工作包导出可能创建或复用一条只读基线 Release，但不会修改 Bot、Agent、经验库、状态机或标签。

### 2.2 尚未开放

当前没有员工侧的上传、预检、发布、版本查询、回滚或平台能力申请接口。调用方不得实现假接口、绕过服务直接写数据库，也不得把本地修改描述为线上生效。

以下路径仅代表后续方向，当前不可调用：

```text
POST /staff/v1/bots/{botId}/releases/precheck
POST /staff/v1/bots/{botId}/releases
GET  /staff/v1/bots/{botId}/releases
GET  /staff/v1/bots/{botId}/releases/{releaseId}
POST /staff/v1/bots/{botId}/releases/{releaseId}/rollback
POST /staff/v1/platform-capability-requests
GET  /staff/v1/platform-capability-requests/{requestId}
```

第一次 Agent 安装也不属于员工 API。首次安装必须由 DClaw 平台管理员完成，因为 OpenAPI、积分账户、经验库关联和源码快照需要先建立。

## 3. 环境与身份

| 环境 | `CONFIG_PATCH_BASE_URL` | Token 管理入口 | 使用顺序 |
| --- | --- | --- | --- |
| 测试 | `https://worktool-test.deepmega.cn` | `https://worktool-test.deepmega.cn/admin/` | 首次开发和联调 |
| 正式 | `https://worktool.deepmega.cn` | `https://worktool.deepmega.cn/admin/` | 测试验收后只读获取正式基线 |

测试 Token 与正式 Token 完全隔离：

- 测试 Token 调用正式 Base URL 会返回 `401`；
- 正式 Token 调用测试 Base URL 会返回 `401`；
- 切换环境时必须同时更换 Base URL 和 Token；
- 切换后必须重新执行 `whoami`、读取能力目录和 Bot 列表；
- 不得把测试环境的 Bot ID、Release ID、摘要或工作包当作正式环境事实。

推荐本地配置：

```bash
export CONFIG_PATCH_BASE_URL="https://worktool-test.deepmega.cn"
export CONFIG_PATCH_STAFF_TOKEN="<通过安全渠道取得的测试Token>"
```

程序必须从配置读取 Base URL，不应在业务代码中写死测试或正式域名。

## 4. 鉴权与安全

所有员工 API 请求都必须携带：

```http
Authorization: Bearer <员工Codex Token>
```

通用要求：

- 只使用 HTTPS；
- 完整 Token 只在创建或轮换时出现一次；
- 不在 Git、聊天、截图、工单、日志、异常或测试快照中保存 Token；
- 不把 Token 放在 URL 查询参数中；
- 日志必须脱敏 `Authorization`；
- 禁止使用 `set -x` 输出调用命令；
- 禁止关闭 TLS 校验；
- 调用方不得获得或使用 `/internal/*` 所需的内部密钥。

不要用根路径 `/health` 判断当前接入的是哪个补丁环境。调用方应使用带 Token 的 `GET /staff/v1/whoami` 作为唯一身份自检。

## 5. 通用协议

### 5.1 请求约定

- 接口前缀：`/staff/v1`；
- JSON 编码：UTF-8；
- `botId` 写入路径前必须进行 URL 编码；
- 当前工作包导出请求不需要请求体；
- 未特别说明时，成功 JSON 响应为 HTTP `200`。

### 5.2 错误结构

一般错误：

```json
{
  "detail": {
    "code": "MACHINE_READABLE_CODE"
  }
}
```

初始化缺项：

```json
{
  "detail": {
    "code": "ADMIN_BOOTSTRAP_REQUIRED",
    "missingItems": [
      "openapi_publication",
      "billing_account",
      "knowledge_base"
    ]
  }
}
```

调用方必须优先依据 `detail.code` 分支处理，不解析自由文本。

### 5.3 超时与重试

| 请求类型 | 连接超时 | 总超时 |
| --- | ---: | ---: |
| JSON 查询 | 10 秒 | 30 秒 |
| 工作包导出 | 10 秒 | 120 秒 |

重试规则：

- `401`、`404`、`409` 不自动重试；
- `502`、`503` 最多退避重试两次，建议间隔 2 秒、5 秒；
- 导出结果不明时，先重新读取配置上下文，再决定是否重新导出；
- `TARGET_BINDING_CHANGED` 必须重新让员工确认目标，不能静默重试；
- 来源未变化时，重复导出返回相同 Release 和相同 ZIP 内容；
- 来源在导出过程中变化时，服务返回 `409`，不会生成混合版本工作包。

## 6. API 参考

### 6.1 验证当前身份

```http
GET /staff/v1/whoami
```

请求示例：

```bash
curl --fail-with-body \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/whoami"
```

成功响应：

```json
{
  "tokenId": "tok_xxx",
  "employeeName": "张三",
  "tokenName": "张三-MacBook-Codex-测试"
}
```

使用规则：

- 将 `tokenId` 用于安全的联调记录和问题定位；
- 不记录完整 Token；
- `employeeName` 或环境不符合预期时立即停止后续调用。

### 6.2 获取动态能力目录

```http
GET /staff/v1/capabilities
```

请求示例：

```bash
curl --fail-with-body \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/capabilities" \
  -o capability-catalog.json
```

主要响应结构：

```json
{
  "schemaVersion": "capability-catalog.v1",
  "version": "platform-2026.10.01",
  "modules": [],
  "profiles": {
    "standard-2026.09": {
      "profileId": "standard-2026.09",
      "name": "普通专家",
      "capabilities": []
    },
    "super-expert-2026.09": {
      "profileId": "super-expert-2026.09",
      "name": "超级专家",
      "capabilities": []
    }
  },
  "semantics": {},
  "capabilityRequest": {}
}
```

这里的数组为文档省略。调用方必须使用接口返回的完整内容：

- 能力目录是当前平台能力的权威来源；
- Demo、旧 Skill、历史工作包和模型常识不能替代动态目录；
- 根据目标 Bot 的 `agentProfileId` 选择对应 Profile；
- 调用方不关心 Profile 的内部加密方式。

### 6.3 列出全部 Bot

```http
GET /staff/v1/bots
```

请求示例：

```bash
curl --fail-with-body \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots" \
  -o bots.json
```

成功响应示例：

```json
{
  "bots": [
    {
      "botId": "bot_xxx",
      "botName": "测试客服",
      "enabled": true,
      "boundAgentId": "a_service",
      "agentProfileId": "standard-2026.09",
      "openapiPublicationId": "pub_xxx",
      "openapiPublicId": "public_xxx",
      "knowledgeBaseId": "kb_xxx",
      "readiness": {
        "status": "ready",
        "ready": true,
        "missingItems": [],
        "code": null
      },
      "currentReleaseId": null
    }
  ]
}
```

行为约定：

- 有效员工 Token 可以查看本环境全部 Bot，不做员工级 Bot 过滤；
- `currentReleaseId` 是可空提示字段，调用方不得依赖它判断本次导出的 Release；
- 导出 Release 的权威值来自成功响应头和工作包 Manifest；
- `readiness.status` 为 `ready`、`not_ready` 或 `unavailable`；
- Bot 列表可以展示，但只有 `readiness.ready=true` 的 Bot 才能正常导出；
- 调用方应展示名称、ID、绑定 Agent、Profile 和 readiness，由员工明确选择；
- 禁止根据相似名称、旧任务或本地目录自动猜选 Bot。

### 6.4 读取配置上下文

```http
GET /staff/v1/bots/{botId}/configuration-context
```

请求示例：

```bash
BOT_ID="<员工明确选择的Bot ID>"
BOT_ID_ENCODED="$(python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$BOT_ID")"

curl --fail-with-body \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots/$BOT_ID_ENCODED/configuration-context" \
  -o configuration-context.json
```

成功响应示例：

```json
{
  "botId": "bot_xxx",
  "botName": "测试客服",
  "enabled": true,
  "boundAgentId": "a_service",
  "agentProfileId": "standard-2026.09",
  "openapiPublicationId": "pub_xxx",
  "openapiPublicId": "public_xxx",
  "knowledgeBaseId": "kb_xxx",
  "readiness": {
    "status": "ready",
    "ready": true,
    "missingItems": [],
    "code": null
  },
  "currentReleaseId": null,
  "agentType": "standard",
  "sourceVersion": "source_xxx",
  "flowMachine": {},
  "tags": {}
}
```

调用方必须校验：

1. `botId` 等于员工选择的 Bot；
2. `boundAgentId` 等于 Bot 列表中的绑定 Agent；
3. `agentProfileId` 存在于本次获取的能力目录；
4. `readiness.ready` 为 `true`；
5. 状态机和标签来自当前响应，而不是本地历史文件。

`agentType` 可能为 `standard`、`sealed`、`unknown` 或在上游不可用时为 `null`。调用方只按 Profile 能力工作，不处理 `sealed` 的内部实现。

### 6.5 导出可信工作包

```http
POST /staff/v1/bots/{botId}/workspace-bundles/export
```

当前请求没有 JSON 请求体。

```bash
mkdir -p platform-download

curl --fail-with-body \
  -X POST \
  -H "Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN" \
  -D platform-download/response-headers.txt \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots/$BOT_ID_ENCODED/workspace-bundles/export" \
  -o platform-download/workspace.zip
```

成功响应：

- HTTP `200`；
- `Content-Type: application/zip`；
- `X-DClaw-Release-Id: Rn`；
- `X-DClaw-Bundle-Digest: sha256:...`；
- 响应体为 ZIP。

第一次导出通常创建 `R1`，但调用方不得硬编码。相同来源快照会复用已有 Release；外部来源变化后可能建立新的基线 Release。

如果首次安装或关联项未完成，响应为 HTTP `409`：

```json
{
  "detail": {
    "code": "ADMIN_BOOTSTRAP_REQUIRED",
    "missingItems": ["agent_source_snapshot"]
  }
}
```

收到该错误必须停止，将完整 `missingItems` 交给管理员。禁止创建空文件、伪造 Manifest、替换 Agent ID 或直接写数据库绕过。

## 7. 工作包契约

### 7.1 目录结构

ZIP 根目录直接包含以下条目，不额外套固定顶级目录：

```text
dclaw-manifest.json
AGENTS.md
change-plan.yaml
agent/
knowledge/
  knowledge-manifest.json
customer-service/
  flow-machine.json
  tag-schema.json
platform/
  capability-catalog.json
  responsibility-matrix.md
  runtime-mechanism.md
  coordinated-change-patterns.md
  examples/
    cross-component-change.md
```

`agent/` 和 `knowledge/` 的实际文件由目标 Agent 当前源码快照决定，不能假设固定文件名或目录。`agent/` 只包含可编辑源码；`sessions_data/`、`tool_results/`、`file_store/`、`backup/`、缓存、日志、锁文件等运行期状态不会进入工作包。调用方不得自行补回这些目录或把历史运行数据作为源码上传。

### 7.2 Manifest

`dclaw-manifest.json` 示例：

```json
{
  "schemaVersion": "customer-service-workspace.v1",
  "bundleId": "bundle_xxx",
  "botId": "bot_xxx",
  "botName": "测试客服",
  "agentId": "a_service",
  "agentProfileId": "standard-2026.09",
  "activeCapabilities": [],
  "sourceVersion": "source_xxx",
  "baseReleaseId": "R1",
  "capabilityCatalogVersion": "platform-2026.10.01",
  "sourceFingerprints": {
    "agent": "sha256:...",
    "knowledge": "sha256:...",
    "flow": "sha256:...",
    "tags": "sha256:..."
  },
  "exportedAt": "2026-10-01T00:00:00+00:00"
}
```

必须验证：

- `schemaVersion == customer-service-workspace.v1`；
- `botId` 等于员工选择的 Bot；
- `agentId` 等于配置上下文中的 `boundAgentId`；
- `agentProfileId` 存在于能力目录；
- `baseReleaseId` 等于响应头 `X-DClaw-Release-Id`；
- ZIP SHA-256 等于响应头 `X-DClaw-Bundle-Digest`；
- `sourceFingerprints` 包含 `agent`、`knowledge`、`flow`、`tags`，且均以 `sha256:` 开头；
- 工作包内的 `platform/capability-catalog.json` 与 Manifest 的能力目录版本一致。

摘要校验示例：

```bash
python3 - <<'PY'
from hashlib import sha256
from pathlib import Path

data = Path("platform-download/workspace.zip").read_bytes()
print("sha256:" + sha256(data).hexdigest())
PY
```

### 7.3 安全解压

即使 ZIP 来自可信服务，调用方仍必须：

- 先解压到新建的临时目录；
- 只接受服务端生成的跨平台相对 POSIX 路径；
- 拒绝绝对路径、`..`、反斜杠路径、Unicode 规范化重复路径和大小写不敏感重复路径；
- 拒绝 Windows 不可移植路径：分段中包含 `< > : " | ? *`、ASCII 控制字符、末尾空格或句点，或使用 `CON`、`PRN`、`AUX`、`NUL`、`COM1`–`COM9`、`LPT1`–`LPT9` 等保留名；
- 拒绝符号链接、硬链接、设备文件及其他非普通文件；
- 设置文件数、单文件大小、总展开大小和压缩比上限；
- 不覆盖已有客户目录或原始基线；
- 校验完成后再复制出可修改工作副本。

服务端工作包应能在 Windows、macOS 和 Linux 上按原路径直接解压。若路径校验失败，调用方必须保留原始 ZIP、停止本次开发并反馈服务端，不能通过重命名、转义、哈希目录或路径映射继续修改；否则后续无法证明上传内容仍对应原始基线。

### 7.4 权威顺序

当资料冲突时，调用方按以下顺序判断：

1. 本次 API 返回的身份、上下文和响应头；
2. 本次工作包的 Manifest、`AGENTS.md` 和 `platform/`；
3. 本次工作包中的实际 Agent、经验库、状态机和标签文件；
4. 客户对本次业务需求的确认；
5. 调用方自身的 Demo、旧 Skill 和历史经验。

低优先级资料不得覆盖高优先级平台事实。

### 7.5 本地基线保存

原始 ZIP、响应头和原始解压目录应只读保存。实际修改从副本开始：

```text
客户任务/
├── 平台基线/
│   └── Rn/
│       ├── response-headers.txt
│       ├── workspace.zip
│       └── extracted/
├── 当前工作区/
└── 本地验证记录/
```

平台基线、客户资料、真实工作包和 Token 不得进入通用 Skill、共享模板或公共仓库。

## 8. 标准调用流程

一次任务必须按顺序执行：

1. 读取 `CONFIG_PATCH_BASE_URL` 和 `CONFIG_PATCH_STAFF_TOKEN`；
2. 调用 `whoami`，向员工显示身份和当前 Base URL；
3. 调用 `capabilities`，记录目录版本；
4. 调用 `bots`，展示全部候选；
5. 由员工明确选择 Bot；
6. 调用 `configuration-context`，核对绑定与 readiness；
7. readiness 不通过时停止，生成管理员待办；
8. readiness 通过后导出工作包；
9. 校验响应头、ZIP、Manifest、绑定和能力目录；
10. 保存只读基线并创建本地工作副本；
11. 阅读工作包中的 `AGENTS.md`、`platform/` 和配套开发决策指南；
12. 填写 `change-plan.yaml`，再开始本地修改；
13. 本地验证完成后标记为“待后续上传能力”，不能标记为线上生效。

一期正确结束状态：

```text
平台基线：已下载并校验
本地工作副本：已创建
本地修改：已完成／未完成
本地验证：通过／未通过
平台上传：未开放
线上配置：未改变
真实线上会话：仍使用原版本
```

## 9. 错误码与处理

| HTTP | 机器码 | 含义 | 调用方处理 |
| --- | --- | --- | --- |
| 401 | `STAFF_TOKEN_REQUIRED` | 缺少 Bearer Token | 检查本地 Secret 配置 |
| 401 | `INVALID_STAFF_TOKEN` | Token 格式、值或环境错误 | 核对 Base URL；必要时请管理员轮换 |
| 401 | `STAFF_TOKEN_EXPIRED` | Token 已过期 | 请对应环境管理员重新授权 |
| 401 | `STAFF_TOKEN_REVOKED` | Token 已撤销 | 停止使用旧 Token |
| 404 | `CONFIG_PATCH_BOT_NOT_FOUND` | Bot 不存在或已删除 | 重新获取列表并让员工选择 |
| 409 | `ADMIN_BOOTSTRAP_REQUIRED` | 首次安装或关联项不完整 | 停止并上报全部 `missingItems` |
| 409 | `TARGET_BINDING_CHANGED` | 导出期间 Bot-Agent 绑定变化 | 重新读取并让员工确认 |
| 409 | `OMNICHANNEL_CONFIGURATION_CHANGED` | 状态机或标签在导出期间变化 | 等变更结束后重新读取和导出 |
| 409 | `DCLAW_SOURCE_CHANGED` | Agent、经验库或 DClaw 上下文发生变化 | 重新读取上下文和导出 |
| 409 | `BASELINE_CHANGED_RETRY` | 另一请求先建立了新基线 | 重新读取上下文后再导出 |
| 502 | `OMNICHANNEL_UPSTREAM_CONTRACT_INVALID` | AI 客服上游响应不符合契约 | 停止使用结果并联系平台技术人员 |
| 502 | `DCLAW_UPSTREAM_CONTRACT_INVALID` | DClaw 上游响应不符合契约 | 联系平台技术人员 |
| 502 | `DCLAW_SNAPSHOT_CONTRACT_INVALID` | DClaw 快照或摘要不合法 | 停止使用下载结果 |
| 503 | `OMNICHANNEL_UPSTREAM_UNAVAILABLE` | AI 客服上游暂时不可用 | 退避重试，持续失败时上报 |
| 503 | `DCLAW_UPSTREAM_UNAVAILABLE` | DClaw 上游暂时不可用 | 退避重试，持续失败时上报 |

`readiness.code` 也可能出现类似 `DCLAW_AGENT_NOT_FOUND` 的上游错误。此时不能替换 Agent ID 绕过，应由管理员检查 Bot 的实际绑定和首次安装。

常见 `missingItems`：

| 缺项 | 处理方 |
| --- | --- |
| `bot_enabled` | AI 客服管理员启用 Bot |
| `agent_bound` | AI 客服管理员完成 Bot-Agent 绑定 |
| `agent_enabled` | AI 客服管理员启用 Agent |
| `agent_identity_mismatch` | 平台技术人员修复两侧身份不一致 |
| `agent_source_snapshot` | DClaw 管理员完成首次安装或源码快照 |
| `openapi_publication` | DClaw 管理员建立 OpenAPI 发布对象 |
| `billing_account` | DClaw 管理员配置积分账户归属 |
| `knowledge_base` | DClaw 管理员关联经验库 |
| `flow_readable` | AI 客服技术人员修复状态机读取 |
| `tags_readable` | AI 客服技术人员修复标签读取 |
| `source_fingerprints` | 平台技术人员修复来源摘要 |

## 10. 最小客户端要求

调用方客户端至少提供：

```text
whoami()
get_capabilities()
list_bots()
get_configuration_context(bot_id)
export_workspace_bundle(bot_id, output_path)
```

实现必须满足：

- Base URL 和 Token 来自配置；
- 路径中的 Bot ID 正确编码；
- 不接受调用参数覆盖服务端 Agent ID；
- JSON 必填字段和类型经过校验；
- 下载先写临时文件，校验后原子改名；
- 校验 Content-Type、Release 头、Digest 头和 Manifest；
- 安全解压，不直接覆盖工作区；
- 错误对象只保存状态码、机器码和脱敏摘要；
- 单元测试使用假服务，不包含真实 Token；
- 真实联调必须显式启用，普通测试不能自动访问正式环境。

## 11. 联调验收清单

- [ ] 测试 Base URL 使用测试 Token；
- [ ] `whoami` 返回预期员工和 Token ID；
- [ ] 能力目录已保存版本号；
- [ ] Bot 列表完整展示并由员工明确选择；
- [ ] 配置上下文中的 Bot-Agent 绑定一致；
- [ ] 普通专家或超级专家 Profile 能在能力目录找到；
- [ ] 调用方没有处理任何加密密钥；
- [ ] readiness 缺项可以形成管理员待办；
- [ ] ready Bot 能导出 ZIP；
- [ ] Release、Digest、Manifest 和四个来源指纹校验通过；
- [ ] ZIP 安全检查通过；
- [ ] Token 未进入日志、Git、工作包或启动包；
- [ ] 调用方没有实现不存在的写接口；
- [ ] 本地修改没有被描述为线上生效；
- [ ] 切换正式环境时重新执行完整只读流程。

## 12. 快速联调命令

```bash
set +x

: "${CONFIG_PATCH_BASE_URL:?missing CONFIG_PATCH_BASE_URL}"
: "${CONFIG_PATCH_STAFF_TOKEN:?missing CONFIG_PATCH_STAFF_TOKEN}"

auth_header="Authorization: Bearer $CONFIG_PATCH_STAFF_TOKEN"

curl --fail-with-body -H "$auth_header" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/whoami"

curl --fail-with-body -H "$auth_header" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/capabilities" \
  -o capability-catalog.json

curl --fail-with-body -H "$auth_header" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots" \
  -o bots.json

# 员工检查 bots.json 后明确填写，禁止自动猜测。
BOT_ID="<confirmed-bot-id>"
BOT_ID_ENCODED="$(python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$BOT_ID")"

curl --fail-with-body -H "$auth_header" \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots/$BOT_ID_ENCODED/configuration-context" \
  -o configuration-context.json

curl --fail-with-body -X POST -H "$auth_header" \
  -D response-headers.txt \
  "$CONFIG_PATCH_BASE_URL/staff/v1/bots/$BOT_ID_ENCODED/workspace-bundles/export" \
  -o workspace.zip

unzip -l workspace.zip
unzip -p workspace.zip dclaw-manifest.json
```

不要在共享终端录像、日志或工单中执行任何会显示 Token 值的命令。
