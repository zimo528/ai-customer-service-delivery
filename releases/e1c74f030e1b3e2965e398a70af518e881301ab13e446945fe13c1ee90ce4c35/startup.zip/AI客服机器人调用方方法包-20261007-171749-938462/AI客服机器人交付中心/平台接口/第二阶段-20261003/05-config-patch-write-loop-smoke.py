#!/usr/bin/env python3
"""Safe caller-side smoke for the config patch write loop."""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import uuid
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen


PRODUCTION_HOST = "worktool.deepmega.cn"


def request(base: str, token: str, method: str, path: str, *, body=None, headers=None):
    payload = None if body is None else json.dumps(body).encode()
    merged = {"Authorization": f"Bearer {token}", **(headers or {})}
    if payload is not None:
        merged["Content-Type"] = "application/json"
    try:
        with urlopen(
            Request(base.rstrip("/") + path, data=payload, headers=merged, method=method),
            timeout=180,
        ) as response:
            return response.status, json.load(response)
    except HTTPError as exc:
        try:
            detail = json.load(exc)
        except Exception:
            detail = {"detail": {"code": "NON_JSON_ERROR"}}
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from None


def upload(base: str, token: str, bot_id: str, archive: Path, key: str):
    boundary = "----config-patch-" + uuid.uuid4().hex
    content = archive.read_bytes()
    mime = mimetypes.guess_type(archive.name)[0] or "application/zip"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{archive.name}"\r\n'
        f"Content-Type: {mime}\r\n\r\n"
    ).encode() + content + f"\r\n--{boundary}--\r\n".encode()
    path = f"/staff/v1/bots/{quote(bot_id, safe='')}/workspace-bundles/uploads"
    try:
        with urlopen(
            Request(
                base.rstrip("/") + path,
                data=body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Idempotency-Key": key,
                    "Content-Type": f"multipart/form-data; boundary={boundary}",
                },
            ),
            timeout=180,
        ) as response:
            return json.load(response)
    except HTTPError as exc:
        raise RuntimeError(f"upload HTTP {exc.code}: {json.load(exc)}") from None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--bot-id", required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--rollback-release")
    parser.add_argument("--allow-production-write", action="store_true")
    parser.add_argument("--key-prefix", default="smoke-" + uuid.uuid4().hex[:12])
    args = parser.parse_args()
    token = os.environ.get("CONFIG_PATCH_STAFF_TOKEN", "")
    if not token:
        parser.error("CONFIG_PATCH_STAFF_TOKEN is required")
    if PRODUCTION_HOST in args.base_url and not args.allow_production_write:
        parser.error("refusing production write without --allow-production-write")
    bot = quote(args.bot_id, safe="")
    _, identity = request(args.base_url, token, "GET", "/staff/v1/whoami")
    print(json.dumps({"step": "whoami", "tokenId": identity["tokenId"]}))
    created = upload(
        args.base_url,
        token,
        args.bot_id,
        args.workspace,
        args.key_prefix + "-upload",
    )
    upload_id = created["uploadId"]
    _, precheck = request(
        args.base_url,
        token,
        "POST",
        f"/staff/v1/bots/{bot}/releases/prechecks",
        body={"uploadId": upload_id},
        headers={"Idempotency-Key": args.key_prefix + "-precheck"},
    )
    _, diff = request(
        args.base_url,
        token,
        "GET",
        f"/staff/v1/bots/{bot}/releases/prechecks/{precheck['precheckId']}/diff",
    )
    print(json.dumps({"uploadId": upload_id, "precheck": precheck, "diff": diff}, ensure_ascii=False))
    if not args.publish:
        print("precheck complete; add --publish only after human diff confirmation")
        return 0
    if not precheck.get("canPublish"):
        raise RuntimeError("precheck does not permit publication")
    _, operation = request(
        args.base_url,
        token,
        "POST",
        f"/staff/v1/bots/{bot}/releases",
        body={"precheckId": precheck["precheckId"]},
        headers={"Idempotency-Key": args.key_prefix + "-publish"},
    )
    print(json.dumps({"publishOperation": operation}, ensure_ascii=False))
    if args.rollback_release:
        _, rollback = request(
            args.base_url,
            token,
            "POST",
            f"/staff/v1/bots/{bot}/releases/{quote(args.rollback_release, safe='')}/rollback",
            headers={"Idempotency-Key": args.key_prefix + "-rollback"},
        )
        print(json.dumps({"rollbackOperation": rollback}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
