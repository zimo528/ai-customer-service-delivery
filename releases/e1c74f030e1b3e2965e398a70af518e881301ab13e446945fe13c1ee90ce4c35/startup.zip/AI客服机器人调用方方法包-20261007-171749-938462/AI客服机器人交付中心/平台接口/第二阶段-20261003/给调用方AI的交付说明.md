# AI 客服配置补丁第二阶段交付说明

交付日期：2026-10-03

## 1. 本次开放范围

第二阶段接口已经一次性开放完成。请在已经通过验证的第一阶段流程之后，继续验证：

1. 工作包上传；
2. 服务端预检；
3. 差异与冲突检查；
4. Release 发布；
5. 发布操作状态查询；
6. 配置与工作包生效回读；
7. 真实对话验证；
8. 必要时回退；
9. 平台能力缺口申请。

## 2. 保持不变的第一阶段契约

本次升级只增加第二阶段能力，不推翻或替换已经联通的第一阶段：

- Base URL 不变；
- Staff Token 请求头和鉴权方式不变；
- `whoami`、能力目录、Bot 列表、配置上下文和工作包导出接口不变；
- 现有响应字段不变；
- 既有工作包契约、四项来源指纹、ZIP 摘要和 Windows 原路径解压规则继续有效；
- 已完成的调用方实现无需重写。

当前测试基线为 R6。针对 2026-10-03 已修复的空标签预检兼容问题，请重新导出最新工作包并从干净副本继续联调；详细说明见 `06-R6预检兼容修复通知.md`。

## 3. 本次联调参数

- 测试 Base URL：`https://worktool-test.deepmega.cn`
- Staff Token：继续使用之前由测试后台创建并已完成第一阶段验证的测试 Token
- 测试 Bot ID：`blackbox-wuhe-aigc-phase1`
- 绑定 Agent ID：`wuhe_aigc_service_phase1_test`
- 基础工作包：重新导出的最新 R6 工作包

请勿把正式环境 Token 用于测试 Base URL，也不要把测试 Token 用于正式 Base URL。

## 4. 环境边界

| 环境 | Base URL | 当前写入状态 |
| --- | --- | --- |
| 测试 | `https://worktool-test.deepmega.cn` | 已开放完整写入闭环联调 |
| 正式 | `https://worktool.deepmega.cn` | 保持只读，写请求返回 `503 / CONFIG_PATCH_WRITES_DISABLED` |

测试与正式 AI 客服分别维护自己的 Bot、Token、状态机、标签和 Release 数据，但连接同一套正式 DClaw。不得由调用方直接访问 DClaw 内部接口。

## 5. 建议执行顺序

请严格按照包内《调用方AI第二阶段完整联调执行单》执行：

1. 使用原测试 Token 复核 `whoami`、能力目录、Bot 列表和配置上下文；
2. 确认目标 Bot 仍绑定 `wuhe_aigc_service_phase1_test`；
3. 以重新导出的最新 R6 工作副本制作修改后的 ZIP，保留工作包目录结构和 Manifest 契约；
4. 上传工作包，保存 `uploadId`；
5. 发起预检，保存 `precheckId`；
6. 查询预检结果和差异，确认不存在阻断项或基线冲突；
7. 使用新的 `Idempotency-Key` 发布，保存 `releaseId` 与 `operationId`；
8. 查询操作状态直至终态；
9. 重新读取配置上下文并导出工作包，核对四个模块均已生效；
10. 执行真实对话验证；
11. 按执行单验证回退和回退后的再次回读；
12. 如发现 DClaw 当前能力不足，提交平台能力申请，不要用状态机、标签或经验库绕过平台能力边界。

## 6. 必须遵守的安全规则

- 只对指定测试 Bot 执行写入；
- Agent 首次安装仍必须由 DClaw 平台管理员完成；
- 上传包中的 Agent ID 必须与 Bot 当前绑定的 Agent ID 完全一致；
- 不允许通过请求参数指定 DClaw 地址、内部客户端 ID 或内部 Secret；
- 每次写操作使用唯一且可重放的 `Idempotency-Key`；
- 预检失败或基线冲突时不得继续发布；
- 不要修改 ZIP 中与需求无关的文件；
- 调用方无需处理普通专家与超级专家的加密细节，只按能力目录使用当前 Agent Profile 暴露的能力；
- 自动化脚本默认拒绝正式环境写入，不要关闭该保护用于本轮联调。

## 7. 发生问题时需要返回的信息

若联调失败，请一次性提供：

- 环境和 Base URL；
- 请求时间（Asia/Shanghai）；
- HTTP 方法和路径；
- HTTP 状态码；
- `detail.code`、`missingItems` 和响应正文；
- Bot ID、Agent ID；
- `uploadId`、`precheckId`、`releaseId`、`operationId`；
- `Idempotency-Key`；
- 基础 `baseReleaseId`；
- 工作包 SHA-256；
- 是否发生任何线上配置变化。

不得在问题报告中发送 Staff Token、内部 Secret 或其他明文凭证。

## 8. 包内文件阅读顺序

1. `06-R6预检兼容修复通知.md`
2. `01-调用方API文档.md`
3. `02-调用方AI开发决策指南.md`
4. `03-调用方AI第二阶段完整联调执行单.md`
5. `04-部署验证记录.md`
6. `05-config-patch-write-loop-smoke.py`

API 契约以 `01-调用方API文档.md` 为准；职责判断以 `02-调用方AI开发决策指南.md` 为准；实际联调步骤以 `03-调用方AI第二阶段完整联调执行单.md` 为准。
