"""Local, OCR-first extraction of long Chinese chat screenshots.

This script does not infer business rules or call an online API. It creates a
reviewable text layer while preserving the images and OCR coordinates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from pathlib import Path


def dependency_directory() -> Path:
    profile = os.environ.get("USERPROFILE")
    if not profile:
        raise RuntimeError("找不到 USERPROFILE，无法定位本地 OCR 依赖。")
    return Path(profile) / ".codex" / "tools" / "chat-ocr" / "deps"


deps = dependency_directory()
if not (deps / "rapidocr").is_dir():
    raise SystemExit(
        f"尚未安装 RapidOCR。请先按 README 安装到：{deps}"
    )
sys.path.insert(0, str(deps))

from PIL import Image  # noqa: E402
from rapidocr import RapidOCR  # noqa: E402


SUPPORTED = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
FULL_DATE = re.compile(r"(?:20\d{2}年\d{1,2}月\d{1,2}日|20\d{2}[-/]\d{1,2}[-/]\d{1,2})\s?\d{1,2}[:：]\d{2}")
SHORT_DATE = re.compile(r"\d{1,2}[-/]\d{1,2}\s*\d{1,2}[:：]\d{2}")
PHONE = re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")
LONG_NUMBER = re.compile(r"(?<!\d)\d{12,}(?!\d)")


def safe_text(value: str) -> str:
    value = PHONE.sub("[手机号已脱敏]", value)
    return LONG_NUMBER.sub("[长数字已脱敏]", value)


def normalized_timestamp(value: str) -> str:
    value = value.replace("：", ":")
    return re.sub(r"^(\d{1,2}[-/]\d{1,2})\s*(\d{1,2}:\d{2})$", r"\1 \2", value)


def input_images(source: Path) -> list[Path]:
    if source.is_file():
        return [source] if source.suffix.lower() in SUPPORTED else []
    if not source.is_dir():
        return []
    return sorted(
        (path for path in source.iterdir() if path.is_file() and path.suffix.lower() in SUPPORTED),
        key=lambda path: (re.sub(r"\d+", "", path.name).lower(),
                          [int(n) for n in re.findall(r"\d+", path.name)]),
    )


def run_ocr(engine: RapidOCR, image: Image.Image, image_name: str) -> list[dict]:
    lines: list[dict] = []
    step, overlap = 1200, 120
    for top in range(0, image.height, step):
        crop_top = max(0, top - overlap)
        crop_bottom = min(image.height, top + step + overlap)
        result = engine(image.crop((0, crop_top, image.width, crop_bottom)))
        if result.boxes is None or result.txts is None or result.scores is None:
            continue
        for box, content, confidence in zip(result.boxes, result.txts, result.scores):
            ys = [float(point[1]) + crop_top for point in box]
            center_y = sum(ys) / len(ys)
            if not (top <= center_y < top + step):
                continue
            xs = [float(point[0]) for point in box]
            lines.append(
                {
                    "image": image_name,
                    "x": round(min(xs)),
                    "y": round(min(ys)),
                    "text": safe_text(str(content).strip()),
                    "confidence": round(float(confidence), 3),
                }
            )
    return sorted(lines, key=lambda item: (item["y"], item["x"]))


def parse_messages(lines: list[dict], width: int, image_name: str) -> list[dict]:
    right_start = width * 0.67
    headers = [
        line for line in lines
        if line["x"] >= right_start
        and (FULL_DATE.fullmatch(line["text"]) or SHORT_DATE.fullmatch(line["text"]))
    ]
    messages: list[dict] = []
    for position, header in enumerate(headers):
        end_y = headers[position + 1]["y"] if position + 1 < len(headers) else 10**9
        speakers = [
            line for line in lines
            if 0 < line["x"] < right_start and abs(line["y"] - header["y"]) <= 6
        ]
        speaker = min(speakers, key=lambda line: abs(line["y"] - header["y"]))["text"] if speakers else "[发送人待核]"
        body_lines = [
            line for line in lines
            if header["y"] + 6 < line["y"] < end_y - 6 and 40 <= line["x"] < right_start
        ]
        body = "\n".join(line["text"] for line in body_lines) or "[仅图片或文字未识别]"
        confidence = round(sum(line["confidence"] for line in body_lines) / len(body_lines), 3) if body_lines else None
        flags = []
        if speaker == "[发送人待核]":
            flags.append("发送人待核")
        if not body_lines:
            flags.append("媒体或文字待核")
        if confidence is not None and confidence < 0.85:
            flags.append("OCR低置信度")
        if "[语音]" in body:
            flags.append("语音未转写")
        if "笔记" in body or "[文件]" in body:
            flags.append("仅预览非全文")
        messages.append(
            {
                "image": image_name,
                "y": header["y"],
                "timestamp": normalized_timestamp(header["text"]),
                "speaker_ocr": speaker,
                "text_ocr": body,
                "avg_confidence": confidence,
                "flags": flags,
            }
        )
    return messages


def overlap_candidates(messages: list[dict]) -> list[tuple[str, str]]:
    candidates = []
    for left, right in zip(messages, messages[1:]):
        if left["image"] == right["image"]:
            continue
        left_key = (left["timestamp"], left["text_ocr"].replace("\n", ""))
        right_key = (right["timestamp"], right["text_ocr"].replace("\n", ""))
        if left_key == right_key and len(left_key[1]) >= 4:
            candidates.append((left["id"], right["id"]))
    return candidates


def main() -> None:
    parser = argparse.ArgumentParser(description="本地批量识别聊天截图，输出可追溯文字底稿。")
    parser.add_argument("--input", required=True, type=Path, help="图片文件或只含本批截图的目录")
    parser.add_argument("--output", required=True, type=Path, help="新的空目录；不会覆盖已有文件")
    args = parser.parse_args()
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    files = input_images(source)
    if not files:
        parser.error("未找到支持的图片（PNG/JPG/WEBP/BMP）。")
    if output.exists() and any(output.iterdir()):
        parser.error("输出目录不是空目录，为防止覆盖已清洗资料，请换一个目录。")
    output.mkdir(parents=True, exist_ok=True)
    originals = output / "原图"
    originals.mkdir()

    engine = RapidOCR()
    all_lines: list[dict] = []
    all_messages: list[dict] = []
    manifest = []
    for index, path in enumerate(files, 1):
        image_name = f"图{index:03d}{path.suffix.lower()}"
        archived = originals / image_name
        shutil.copy2(path, archived)
        image = Image.open(archived).convert("RGB")
        lines = run_ocr(engine, image, image_name)
        messages = parse_messages(lines, image.width, image_name)
        for item_index, item in enumerate(messages, len(all_messages) + 1):
            item["id"] = f"I{index:03d}M{item_index:05d}"
        all_lines.extend(lines)
        all_messages.extend(messages)
        manifest.append(
            {
                "source_name": path.name,
                "archived_name": image_name,
                "sha256": hashlib.sha256(archived.read_bytes()).hexdigest(),
                "width": image.width,
                "height": image.height,
                "ocr_lines": len(lines),
                "parsed_messages": len(messages),
            }
        )
        print(f"{path.name}: {len(lines)} 行文字，{len(messages)} 条候选消息", flush=True)

    with (output / "ocr-lines.jsonl").open("w", encoding="utf-8") as handle:
        for item in all_lines:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    with (output / "messages.jsonl").open("w", encoding="utf-8") as handle:
        for item in all_messages:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    review = [
        "# 聊单 OCR 待核底稿",
        "",
        "本文件由本地 RapidOCR 批处理生成，不调用云端 OCR。它不是逐字校对完成的聊天导出，也不产生业务规则。",
        "音频、图片和卡片预览可能没有全文；时间、发送人、金额、手机号及重叠截图均须按原图复核。手机号和连续长数字在文本输出中已脱敏，原图保持原样。",
        "",
        f"图片 {len(files)} 张；OCR 文字行 {len(all_lines)}；候选消息 {len(all_messages)}。",
        "",
    ]
    for first, second in overlap_candidates(all_messages):
        review.append(f"- 疑似跨图重复：`{first}` 与 `{second}`。先核对原图，再决定是否去重。")
    if not overlap_candidates(all_messages):
        review.append("- 未发现完全一致的相邻跨图消息；这不代表没有重叠截图。")
    review.append("")
    for index, item in enumerate(manifest, 1):
        review.extend([f"## 图 {index}：{item['source_name']}", ""])
        image_messages = [message for message in all_messages if message["image"] == item["archived_name"]]
        if not image_messages:
            review.extend(["未识别到右侧时间戳；请直接查看 `ocr-lines.jsonl` 和原图。", ""])
        for message in image_messages:
            flag = f"｜{'、'.join(message['flags'])}" if message["flags"] else ""
            first_line, *rest = message["text_ocr"].splitlines()
            review.append(
                f"- **{message['id']}｜{message['timestamp']}｜{message['speaker_ocr']}｜y{message['y']}{flag}**：{first_line}"
            )
            review.extend(f"  {line}" for line in rest)
            review.append("")
    (output / "待核底稿.md").write_text("\n".join(review), encoding="utf-8")
    print(f"输出：{output}")


if __name__ == "__main__":
    main()
