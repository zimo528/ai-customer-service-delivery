param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$OutputPath,
    [string]$PythonPath
)
$ErrorActionPreference = 'Stop'
if (-not $PythonPath) {
    $bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $bundledPython -PathType Leaf) { $PythonPath = $bundledPython }
    else {
        $systemPython = Get-Command python -ErrorAction SilentlyContinue
        if ($systemPython) { $PythonPath = $systemPython.Source }
        else { throw '请在 Codex 中定位工作区 Python，或安装 Python 后使用 -PythonPath 指定路径。' }
    }
}
& $PythonPath (Join-Path $PSScriptRoot '批量清洗.py') --input $InputPath --output $OutputPath
exit $LASTEXITCODE
