# 聊单截图清洗工具

批量识别聊天截图，生成带原图位置和置信度的文字底稿；接待流程和业务事实须再核对原图。文档和文字资料可先直接分析，需要批量截图识别时再准备 OCR 依赖。

## 第一次使用

让当前客户对话读取本目录的 requirements.txt，定位新电脑实际 Python，将依赖安装到当前用户的 `.codex/tools/chat-ocr/deps`。依赖安装需联网；启动包包含工具及依赖清单。运行入口优先使用 Codex 工作区 Python，也接受 `-PythonPath` 指定已安装 Python。

安装命令示例，使用实际 Python 路径执行：

```powershell
& '<Python路径>' -m pip install --target "$env:USERPROFILE\.codex\tools\chat-ocr\deps" -r '<项目目录>\工具\聊单清洗\requirements.txt'
```

## 运行

```powershell
& '<项目目录>\工具\聊单清洗\运行.ps1' -InputPath '<同一批截图目录>' -OutputPath '<新建或空的输出目录>'
```

输出包括待核底稿.md、messages.jsonl、ocr-lines.jsonl、manifest.json 和原图副本。核对发言人、时间、金额、语音、媒体预览和低置信度内容后，再据此梳理 SOP。OCR 引擎为 RapidOCR，采用本机推理：[官方项目](https://github.com/RapidAI/RapidOCR)，Apache-2.0 许可证。
