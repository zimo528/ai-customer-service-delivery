"""Plan and create an isolated customer folder for a Codex client task."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import unicodedata


INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f\x7f]')
RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
            *(f"LPT{i}" for i in range(1, 10))}


def canonical(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold()


def safe_name(title: str) -> str:
    raw = unicodedata.normalize("NFC", title.strip())
    if not raw:
        raise ValueError("Task title is required")
    name = INVALID.sub("-", raw.replace("｜", "-"))
    name = re.sub(r"\s+", "-", name)
    name = re.sub(r"-+", "-", name).strip(" .-")
    if not name:
        raise ValueError("Task title contains no usable characters")
    if name.upper().split(".", 1)[0] in RESERVED:
        name = "客户-" + name
    if len(name) > 72:
        name = name[:63].rstrip(" .-") + "-" + sha256(raw.encode("utf-8")).hexdigest()[:8]
    return name


def plan(project: Path, title: str) -> str:
    root = project / "客户"
    if root.is_symlink() or (root.exists() and not root.is_dir()):
        raise ValueError("Customer root is not a normal directory")
    existing = {canonical(child.name) for child in root.iterdir()} if root.exists() else set()
    base = safe_name(title)
    candidate = base
    index = 2
    while canonical(candidate) in existing:
        suffix = f"-{index}"
        candidate = base[:72 - len(suffix)].rstrip(" .-") + suffix
        index += 1
    return "客户/" + candidate


def create(project: Path, title: str, expected: str) -> str:
    actual = plan(project, title)
    if actual != expected:
        raise ValueError(f"Customer folder changed; plan again: {actual}")
    root = project / "客户"
    root.mkdir(exist_ok=True)
    target = root / actual.removeprefix("客户/")
    target.mkdir(exist_ok=False)
    (target / "原始资料").mkdir()
    return actual


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("plan", "create"))
    parser.add_argument("--title", required=True)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--expected-relative")
    args = parser.parse_args()
    project = args.project.resolve()
    if not (project / "AGENTS.md").is_file():
        parser.error("Project AGENTS.md is missing")
    if args.command == "create":
        if not args.expected_relative:
            parser.error("create requires --expected-relative from plan")
        relative = create(project, args.title, args.expected_relative)
    else:
        relative = plan(project, args.title)
    print(json.dumps({"title": args.title, "customerFolder": relative}, ensure_ascii=False))


if __name__ == "__main__":
    main()
