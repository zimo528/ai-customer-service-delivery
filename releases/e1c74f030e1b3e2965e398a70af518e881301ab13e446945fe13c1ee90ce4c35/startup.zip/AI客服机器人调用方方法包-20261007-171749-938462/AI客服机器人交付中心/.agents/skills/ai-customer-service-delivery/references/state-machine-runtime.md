# AI 客服状态机运行逻辑与 JSON 配置规范

本文基于 `worktool-bot-service` 当前工作区源码整理，核查日期为 2026-09-14，Git 基线为 `74cae3d4f1ba9d7110640a7968704a5763bda4f3`。工作区已有未提交改动，因此这里描述的是核查时的源码，而不是承诺该提交或线上部署完全一致。

适用范围：WorkTool 私聊客服流程的配置、Agent 请求、回复校验、会话状态、发卡/入群动作与节点自动跟进。外部 DClaw Agent 的内部提示词、知识库检索和记忆实现不在本仓库中；本文只对本仓库实际构造的请求和实际执行的结果作出结论。群聊自动化、标签跟进、定时群发是独立子系统，不能把其字段搬入本状态机 JSON 后期待生效。

## 1. 先掌握这套系统实际采用的模型

这是一套“LLM 判断业务语义，服务端维护状态与执行副作用”的流程系统。它不是通用的条件表达式状态机，也不是将 JSON 中每一句自然语言编译成硬规则的规则引擎。

服务端保存整套节点配置，但通常只向 Agent 提供当前节点的压缩信息。Agent 根据客户发言、有限上下文、节点目标和完成条件生成回复，以及 `flowDecision`。服务端发送回复和卡片后，合并可采集字段；当 `nodeCompleted === true` 且当前节点配置了有效、不同于自己的 `nextNodeId` 时，服务端迁移到该固定后继节点。

几个设计时必须知道的事实：

- `transitions` 仅保留为数组，没有执行条件、优先级或分支选择逻辑。
- Agent 返回的 `nextNodeId` 不能决定最终迁移目标；服务端取当前节点配置中的 `nextNodeId`。
- `goal`、`completionCriteria`、`generalRule`、`conversationTips` 是给模型理解的文字。年龄范围、肯定词含义、拒绝条件、费用问答等没有相应的硬编码业务判断。
- `collectFields` 是字段名称清单，不是带类型、必填、正则、枚举的字段定义。写成对象不会获得这些能力。
- 完成判断只有在实际响应链路走到落库阶段才生效。没有自动遍历后续节点，也没有“进入节点立即执行 goal”的事件。
- 最后一个节点不会自动变成数据库中的“已结束会话”。没有有效后继时，仍停留在当前节点。
- 卡片节点有“本次至少发出一张配置内卡片”的完成保护，但不是年龄分流、客户意愿或所有动作成功的综合证明。
- 自动跟进由数据库任务和 worker 驱动。LLM 润色只是可选步骤，不负责计时或安排下一次任务。

## 2. 配置对象、接口包装和会话数据是三种不同对象

### 2.1 可导入的流程配置

流程 JSON 本体是下面这种结构，而不是带 `machine`、`session` 的运行时上下文：

```json
{
  "name": "咨询接待",
  "version": "1.0.0",
  "generalRule": "先回答客户当前问题，再推进当前节点；不要编造客户资料。",
  "entryNodeId": "collect_need",
  "nodes": [
    {
      "id": "collect_need",
      "name": "了解需求",
      "goal": "了解客户希望咨询的产品。客户明确说明后保存到咨询产品；不明确时只问一个澄清问题。",
      "completionCriteria": "客户明确说出要咨询的产品，且已保存咨询产品。",
      "collectFields": ["咨询产品"],
      "conversationTips": ["先回答问题。", "不要重复询问已明确的信息。"],
      "actionsOnComplete": [],
      "activation": {
        "enabled": true,
        "polishByAgent": false,
        "messages": [
          {"content": "方便时告诉我您想了解的产品，我继续为您介绍。", "intervalMinutes": 30, "maxTimes": 1}
        ]
      },
      "nextNodeId": "service",
      "transitions": []
    },
    {
      "id": "service",
      "name": "持续服务",
      "goal": "回答客户当前问题；遇到资料不足的事项明确说明需要确认。",
      "completionCriteria": "持续服务节点，不主动判定完成。",
      "collectFields": [],
      "conversationTips": [],
      "actionsOnComplete": [],
      "activation": {"enabled": false, "polishByAgent": false, "messages": []},
      "nextNodeId": "",
      "transitions": []
    }
  ]
}
```

这是不依赖外部卡片和群资源的结构示例。它不承诺任意外部 Agent 都会正确理解业务规则。

### 2.2 保存接口

读取：`GET /api/flow-machines/:botId`。没有流程时，附加 `?default=1` 可获得未启用的默认模板。

保存：`PUT /api/flow-machines/:botId`，请求体为：

```json
{
  "enabled": true,
  "config": {
    "name": "最简持续服务",
    "version": "1.0.0",
    "entryNodeId": "service",
    "generalRule": "如实回答。",
    "nodes": [{"id": "service", "name": "服务", "goal": "回答当前问题", "nextNodeId": ""}]
  }
}
```

`config` 也可以是包含 JSON 的字符串，接口会 `JSON.parse`。推荐直接传对象。接口要求 Bot 访问权限和 Agent 绑定；这里的请求示例不包含部署相关的认证信息。

`enabled` 是接口包装字段，不是配置本体字段。只有真正的布尔值 `false` 才关闭；省略、`null`、字符串 `"false"` 都不等价于关闭。配置中的 `enabled` 会作为未知顶层字段丢弃。

流程以 `agent_id` 保存到 `agent_flow_machines`。多个 Bot 绑定同一 Agent 时共享一份流程，保存会影响该 Agent 绑定的其他 Bot。会话和动作记录则关联具体 Bot 与会话。

### 2.3 运行时状态

`flow_sessions` 维护 `currentNodeId`、`collectedData`、`status`、`handoffStatus`、`activationGeneration` 和 `activationState` 等数据。它们不是流程配置字段，不要放进配置本体。

通常新私聊会话从 `entryNodeId` 创建，已有会话保留自己的当前节点。普通无流程会话使用的 `__conversation__` 可在启用流程后转为入口节点。字段资产存于该会话的一张扁平字典中，不按节点分别建表。

## 3. 流程本体的全部受支持字段

以下“默认”指服务端 `normalizeFlowConfig`；控制台编辑器还会做一次转换，见第 11 节。表内字符串转换通常使用 `String(value || "").trim()`，不应利用其宽松类型转换来生成配置。

| 字段 | 推荐类型 / 是否必需 | 服务端读取与默认值 | 实际用途 |
|---|---|---|---|
| `name` | string；建议显式提供 | 假值回退到 `默认客服流程`，再去首尾空白 | 配置名称、展示、Agent 的流程标识；不决定执行顺序 |
| `version` | string；建议显式提供 | 假值回退到 `1.0.0` | 展示和上下文标识；不校验语义版本，不自动隔离旧会话或选择旧规则 |
| `generalRule` | string；可省略 | 缺失为空字符串，去首尾空白 | 构建 Agent 业务提示；不是代码执行条件，也不自动约束原样跟进文字 |
| `entryNodeId` | string；可省略 | 假值默认第一节点 ID；去空白后必须存在 | 新流程会话入口；不是每次客户消息都重新进入 |
| `nodes` | 非空 node 数组；必需 | 非数组视为空，空数组报错 | 全流程定义，保存时规范化每一项 |

未知顶层字段不会进入规范化后的配置。不存在 `globalVariables`、`fieldDefinitions`、`onEnter`、`onExit`、`conditions`、`priority`、`timeoutNodeId` 等可执行扩展协议。

## 4. 节点的全部受支持字段

| 字段 | 推荐类型 / 必需性 | 规范化与默认 | 谁读取，如何执行 |
|---|---|---|---|
| `id` | 非空 string，必需 | 去空白；全流程唯一 | 服务端查节点、会话定位、后继引用、跟进任务关联；建议稳定的 ASCII ID |
| `name` | 非空 string，必需 | 去空白 | 展示、Agent 语义标签，不是跳转标识 |
| `goal` | string，强烈建议 | 默认空，去空白 | Agent 的当前任务；其中合法卡片占位符会被提取成内部 `agentActions` |
| `completionCriteria` | string，强烈建议 | 默认空，去空白 | Agent 判断 `nodeCompleted` 的自然语言依据；不被服务端解析成谓词 |
| `collectFields` | string[] | 非数组→`[]`；元素 `String()`，保存时不逐项 trim | Agent 提取提示、服务端字段白名单、客户资产展示；使用处会去空白、去重 |
| `conversationTips` | string[] | 非数组→`[]`；元素 `String()` | 对话提示；请求仅保留前 3 项，每项有长度限制 |
| `nextNodeId` | string | 默认 `""`；非空必须指向存在的节点 | 完成后的唯一迁移目标；空值或指向自己都不会迁移 |
| `transitions` | array；推荐 `[]` | 非数组→`[]`，数组内容原样保留 | 没有运行时消费者；无可用的条件分支规范 |
| `actionsOnComplete` | action[] | 规范化；空列表可能不写回配置 | 只有发生有效节点迁移后才执行，归属于被完成的旧节点 |
| `agentActions` | action[]；兼容字段 | 与 `goal` 提取的卡片动作合并，再只保留 `send_card` | 供旧动作执行路径和卡片完成保护使用；当前动态回复协议禁止返回 `actions`，编辑器也不保留显式此字段 |
| `activation` | object | 统一转换为 `enabled`、`polishByAgent`、`messages` | 服务端安排当前节点的自动跟进；详见第 8 节 |

未知节点字段会被丢弃。服务端只校验 ID、名称、入口和后继引用等结构；不会检测不可达节点、循环、业务目标矛盾或长文截断。

节点数组顺序不决定完成后的顺序。唯一例外是没有 `entryNodeId` 时以数组第一节点作为入口。允许配置循环，但每条边都是固定后继；没有按条件动态选择循环或分支的机制。

## 5. LLM 真正收到什么：长度、上下文和责任边界

### 5.1 普通私聊请求不是整份 JSON 的原样传输

`buildFlowContext` 在服务端拿到完整流程；`buildDclawRequest → compactFlowForAgent` 再生成给 Agent 的精简对象：

```json
{
  "machine": {"name": "咨询接待", "version": "1.0.0", "entryNodeId": "collect_need"},
  "session": {"currentNodeId": "collect_need", "handoffStatus": "ai"},
  "currentNode": {
    "id": "collect_need",
    "name": "了解需求",
    "goal": "了解客户想咨询的产品。",
    "completionCriteria": "客户说明产品。",
    "nextNodeId": "service",
    "collectFields": ["咨询产品"],
    "conversationTips": ["先回答问题。"]
  }
}
```

`machine.nodes`、`transitions`、`activation`、`actionsOnComplete` 和 `agentActions` 不在此精简对象中。合法的目标占位符会额外生成 `currentNode.actionPlaceholders`。`generalRule` 作为请求提示文本单独注入。

普通回复入口显式传 `legacyHistoryAnalysis: null`。只有历史分析文本非空时，精简函数才启用 `includeAllCollectFields`，加入全流程字段并集 `collectibleFields` 和已采集标量 `session.collectedData`。因此，**普通轮次即便数据库有资产，也不会通过这个 flow 对象再次完整传给模型**。不能把“提示模型先检查已采集字段”理解为每轮必有完整资产快照。

普通私聊还传最近最多 12 条会话记录，每条文字最多 400 字符，私聊记录负载有约 3200 字符的预算。Agent 端可能另有持久记忆，但本仓库无法证明其记忆完整性。外部会话身份按 Bot、会话和 epoch 隔离；重置后旧调用结果可能因 epoch 变化被丢弃。

### 5.2 字段截断清单

这里的字符为 JavaScript 字符串长度计数，不是 token 数。超长文字会保留前缀并加省略号。

| 内容 | 常规请求限制 | 配置设计原则 |
|---|---|---|
| `generalRule` | 600 字符 | 核心规则前置，不依赖尾部补充例外 |
| `goal` | 目标预算 3200 字符 | 超长时保留前段，并附占位符清单；占位符很长时总长度并非绝对 3200 |
| `completionCriteria` | 160 字符 | 将判定标准压缩到 160 以内；复杂细节写到 goal，仍不构成硬校验 |
| `id/name/nextNodeId` 及机器标识 | 每项 160 字符 | 使用短且稳定的 ID，避免模型看到截断 ID |
| `collectFields` | 前 10 项，每项 160 字符 | 每节点不超过 10 个短字段名；服务端白名单仍取完整流程 |
| `conversationTips` | 前 3 项，每项 160 字符 | 第 4 项及以后不能作为当前请求的有效提示依赖 |
| `actionPlaceholders` | 去重后最多 20 个 | 动作清单要短，不依赖第 21 个独立占位符清单项 |
| 历史补采中的字段值 | 字符串每项最多 500 字符 | 数值与布尔值保留；不要当作长文档存储 |
| 润色跟进的参考话术 | 每条最多 160 字符，最多 3 条 | 真实调用仅传当前一条，过长参考文字会被截短 |

整条请求 `message` 默认预算为 20000 字符，由 `DCLAW_REQUEST_MESSAGE_MAX_CHARS` 调整，最小按 1000 处理。保留决策上下文的请求可能超过该预算。其他请求超限时会进一步压缩 goal 到 1200、再到 600，并可能去掉 `completionCriteria`、`nextNodeId` 等字段。不要把默认预算当成所有路径的硬截断，更不要把数据库保存成功当成模型完整读到的证明。

### 5.3 分工表

| 事项 | LLM / 外部 Agent | 本仓库代码 |
|---|---|---|
| 识别“好的”是否同意、年龄和业务阶段 | 根据提示与上下文判断 | 不做这些业务语义判断 |
| 回答事实问题、使用知识库 | 请求要求 Agent 核对企业智库并标注来源 | 构造请求与校验部分来源格式；检索内部实现不在仓库 |
| 提取字段与更正资料 | 生成 `collectedDataPatch` | 过滤字段名及值类型，浅合并落库 |
| 节点是否完成 | 生成布尔决策 | 在发卡保护之后，根据固定后继执行迁移 |
| 选择某个年龄档卡片 | 根据 goal 选择完整占位符 | 解析模板、检查可用性/能力、调用 WorkTool；不独立验证年龄档 |
| 跟进时间与次数 | 不负责 | 持久化进度、生成任务、取消过期任务、计算间隔 |
| 跟进表达 | `polishByAgent=true` 时润色 | `false` 时直接发送配置文本；两种都由代码发送 |
| 人工接管 | 可由独立业务告警提示需确认 | 会话 handoff 状态与发送前检查控制是否可自动回复 |

## 6. 一轮正常客户消息的执行顺序

1. 接收 WorkTool 回调，做身份识别、消息去重与可达性/绑定等前置判断。新好友信号有专门入口，不能当作普通客户正文。
2. 普通私聊客户互动立即使旧节点跟进失效：递增 generation，并取消 pending/processing 任务。即使图片等消息不能转给 Agent，也会取消旧提醒。
3. 保存会话与入站记录，必要时从入口创建流程会话。人工接管会走同步/审计路径，不执行常规 AI 回复推进。
4. 连续消息先合并，再用当前会话节点构造 Agent 请求；不是每条气泡必对应一次 LLM 调用。
5. 解析 JSON 或 DSL 输出，进行响应校验、有限的修复与重试；无有效回复或发送被禁止时，不按正常路径推进。
6. 发送 `reply`（可分段），其中卡片占位符转成真实卡片；随后发送支持的附件。发送前检查会话是否仍由 AI 控制，旧 epoch 结果不应落入新会话。
7. 兼容路径可执行 Agent 请求的卡片动作，但正常动态 flow 校验禁止 `actions`，新设计不应依赖该路径。
8. `guardFlowActionCompletion` 检查配置内卡片是否在本次交付结果中成功出现；不满足则将完成决策改为 false，保留当前节点。
9. `applyFlowDecision` 先过滤并保存字段，再按旧节点的固定 `nextNodeId` 迁移。迁移后取消旧提醒，执行旧节点的 `actionsOnComplete`。
10. 保存出站历史与任务快照。成功回复后再次递增 generation，以发送结束时间为锚，给最新当前节点安排尚未发完的跟进话术。

发送、字段落库、迁移、完成动作不是一个覆盖外部接口的原子事务。前半段已发出、后半段失败的情况是可能的；发送成功也可能先于状态落库。不能把重试理解成对客户不可见的回滚。

### 6.1 Agent 决策协议

标准响应形态如下；它是 Agent 输出，不是流程配置：

```json
{
  "reply": "了解了，接下来为您介绍这款产品。",
  "attachments": [],
  "sources": [],
  "flowDecision": {
    "currentNodeId": "collect_need",
    "nextNodeId": "service",
    "nodeCompleted": true,
    "confidence": 0.95,
    "reason": "客户已明确咨询产品。",
    "collectedDataPatch": {"咨询产品": "产品 A"}
  }
}
```

如果未完成，使用 `nodeCompleted:false`，`nextNodeId` 写当前节点 ID。动态流程不要返回 `actions`，即便是 `actions:[]` 也会触发禁止动作字段的校验。启用标签、业务告警等能力时还可能要求其他响应字段；上述示例只展示流程相关部分。

| 决策字段 | 实际处理 |
|---|---|
| `currentNodeId` | 提示与审计用途；迁移时以服务端会话状态为准，不是客户端式 compare-and-swap 锁 |
| `nextNodeId` | 要求模型按配置填写，但落库时由配置覆盖；不是自由选节点的接口 |
| `nodeCompleted` | 真正的布尔 `true` 才触发迁移判断；`"true"` 不可用 |
| `confidence` | 没有置信度阈值控制，不会因为 0.1 自动阻止完成 |
| `reason` | 记录迁移理由；缺失时使用默认理由；其中“已发卡”措辞还可能触发发卡声明检查 |
| `collectedDataPatch` | 推荐的字段补丁名；兼容 `collectedFields` / `dataPatch` 的落库别名不应作为新协议 |

`AGENT_RESPONSE_FORMAT=dsl` 可改变 Agent 输出协议，默认是 JSON。DSL 仍解析为类似的内部决策对象，不改变流程配置必须为 JSON 的规范。

### 6.2 固定跳转和终点

迁移条件等价于：

```text
decision.nodeCompleted === true
AND oldNode.nextNodeId 非空
AND oldNode.nextNodeId != session.currentNodeId
AND oldNode.nextNodeId 存在于当前配置
```

满足才更新节点、写 `flow_state_events`、清空节点跟进进度并执行旧节点完成动作。终点 `nextNodeId:""` 和自环都不会执行 `actionsOnComplete`，即使模型说完成。没有一轮自动完成多个节点的循环，也没有进入新节点后立即生成第二次回复的逻辑。

需要按年龄发两种卡片时，可在同一个节点 goal 中列出两个占位符，由 Agent 选择内容，完成后仍进入同一个固定后继。需要按年龄走两个不同节点时，当前 JSON 不支持确定性分支；不能通过 `transitions` 或让模型自选 `nextNodeId` 实现。

### 6.3 字段采集、覆盖与校验的真实边界

全流程所有 `collectFields` 合并、去空白、去重后构成落库白名单。因此可以提前采集后续节点字段。合法值只有非空字符串、有限数值、布尔值；`0` 和 `false` 都算有效值。数组、对象、`null`、空白字符串被忽略。字段名先 trim，字符串值也 trim。

普通回复可覆盖已有同名字段，是浅合并；不能用空字符串或 null 删除原值。历史分析后台补采使用 `fillOnlyMissing:true`，只补没有有效值的字段，不调用普通节点迁移逻辑。不同节点使用相同字段名，表示共享同一项资产。把字段改名不会自动迁移旧资产。

必须区分“存在校验代码”和“生产入口向该代码提供了充分输入”：

- `validateFlowDecision` 若收到完整 `machine.nodes`，会检查目标 ID、补丁字段白名单；当 `nodeCompleted=true` 且补丁对象存在时，会要求当前节点全部字段在补丁或已有资产中有值。布尔 false 也算有值，并非业务条件成立。
- 该函数的节点列表查找不使用单独的 `currentNode`。真实请求的 `metadata.flow` 是第 5 节的精简对象，不含 `machine.nodes`；`buildAgentResponseValidationOptions` 直接传此对象。因此真实普通链路中这些完整图/字段检查会被跳过。
- 即便直接给该函数完整图，若没有补丁对象，也会提前返回，不能将其理解为无条件必填校验。
- 真正落库时仍用完整流程过滤字段，因此未配置资产不会入库；但“字段齐全才允许迁移”没有在 `applyFlowDecision` 重做。

结论：设计上应要求模型提供真实且完整的字段，校验器应主动检查必需资产；不能把现有运行时当作业务必填字段的可靠强制执行层。

## 7. 动作与卡片

### 7.1 结构化 action 字段字典

`normalizeFlowActions` 接受的动作只有两种；无效项通常直接丢弃，不一定报错。

| 字段 | `send_card` | `invite_to_group` | 处理规则 |
|---|---|---|---|
| `id` | string | string | 缺失生成 `action_N`；建议显式唯一且稳定，避免自动重编号影响去重 |
| `type` | 固定 `send_card` | 固定 `invite_to_group` | 其他类型丢弃 |
| `templateId` | 必需 | 不使用 | 对应当前工作区真实卡片模板 ID |
| `displayName` | 可选，默认空 | 不使用 | 规范化保留的卡片显示名；实际发送读取模板 |
| `groupName` | 不使用 | 必需非空字符串 | 交给 WorkTool 的群名，不是群 ID |
| `target` | `current_contact` | `current_contact` | 默认此值；其他目标导致动作被丢弃 |
| `showMessageHistory` | 不使用 | 固定 false | 配 true 也会改为 false；执行时也写死 false |
| `runOnce` | 默认 true | 默认 true | 仅保留字段；执行记录去重不读取它，false 不能打开重复执行 |

动作不支持自由 URL、HTTP 请求、自定义函数、变量赋值或任意 API 调用。普通文本回复不是 `send_text` action。自动生成 ID 的冲突修正规则并非值得依赖的稳定协议，生成工具应拒绝同一动作列表中的重复 ID。

完成后入群示例（放在有有效后继的节点中）：

```json
{
  "actionsOnComplete": [
    {"id": "invite_service_group", "type": "invite_to_group", "groupName": "产品服务群", "target": "current_contact", "runOnce": true}
  ],
  "nextNodeId": "service"
}
```

此处是节点片段，不是可单独导入的流程。完成动作发生在状态已迁移之后；动作失败只记录失败，不回滚迁移。若必须先证明入群成功再推进，当前配置本身不能提供这种事务保证。

### 7.2 普通回复的卡片占位符

在 goal 中嵌入：`{{card id="card_tpl_example" name="产品资料"}}`。JSON 字符串中的双引号必须转义：

```json
{
  "goal": "客户确认要资料后，回复说明并原样输出 {{card id=\"card_tpl_example\" name=\"产品资料\"}}；尚未同意时不要输出卡片。"
}
```

示例模板 ID 必须替换成当前工作区真实 ID 后才能使用。占位符要求双大括号、`card`、先 id 后 name、英文双引号。ID 匹配 `[A-Za-z0-9_-]+`；名称不能包含双引号或换行。不要把实际字符串写成含字面反斜杠的 `id=\"...\"`；JSON 解析后应得到 `id="..."` 的正常引号字符。

执行链路：goal 占位符→Agent 原样复制到 reply→出站解析器拆分文本/卡片→按 ID 找工作区模板→渲染模板→按顺序调用文本和卡片发送接口。卡片不作为普通文本发出；发现以 `{{card` 开头的畸形标记会报错。普通 URL 仍是普通文本，不会自动变成卡片。

保存流程时会递归扫描原始配置中的卡片引用并检查模板存在和工作区归属；执行时还会检查 Bot 卡片发送能力和模板变量。保存成功不代表运行时能力一定开启，也不代表客户已经收到或阅读。

`guardFlowActionCompletion` 对 goal 中卡片和兼容 `agentActions` 的卡片采取“至少一个配置内卡片成功”的保护：

- 两张候选卡片中成功一张即可，不要求两张全发。
- 保护不知道客户年龄、意愿和当前卡片是否符合业务分流；模型选错配置内卡片仍可能完成。
- goal 中只要出现卡片，模型声明节点完成通常就需要本次 reply 中含合法配置卡片，并有本次交付结果。不要在持续服务节点随手列“可选卡片”，却期望它能无卡完成。
- 不能仅靠 `collectedDataPatch` 写入“已发送”来代替真实发送。代码也不会自动把真实发送结果回填为你命名的 `卡片发送状态` 字段。
- 之前已经发卡不等于本轮自动满足交付保护。把发卡和其后的客户反馈拆为不同节点可避免本轮重复发卡才能完成的矛盾。
- 若同一张卡既在 reply 中发送，又配置到 `actionsOnComplete`，可能出现两次发送；不要重复配置两条发送路径。

响应网关对“完成/声明已发卡”检查占位符，但这不是一个覆盖任意 reply、任意模板的完整授权证明。不要推导成“所有非当前节点卡片都一定在发送前被拦截”。

### 7.3 入群占位符的能力差异

`[动作：拉入 产品服务群]` 在 `activation.messages[].content` 中会被提取为入群动作，文本中的该标记被移除，发送可见文本之后再执行动作。

但是当前普通 `reply` 的发送链路仅用 `sendOutboundContent` 解析卡片，没有调用 `mergeInlineActions`。虽然 Agent 提示词说可以原样返回入群标记，**普通回复中的入群标记在当前实现会成为普通文字，不能据此完成入群**。普通动态场景需要入群时，使用有后继节点的 `actionsOnComplete`；自动跟进场景可以使用 `actionsAfterSend`。这是当前提示与实现的差异，不是推荐的新语法。

### 7.4 幂等与发送成功的含义

结构化动作先在 `flow_action_executions` 预占，再发命令，最后写 success/failed。去重键是：

```text
bot_id + agent_id + conversation_key + source + node_id + activation_task_id + action_id
```

`source` 区分 `node_complete`、`agent_request`、`activation_sent`。同一个键已有记录就不重复预占；即使之前 failed 或 processing，也不会在此函数中自动重试。`runOnce:false` 不改变此行为。跟进任务 ID 不同，去重键不同，因此多次跟进中的同一动作仍可重复执行。

普通 reply 内联卡片走统一内容发送，不在发送前使用上述动作预占；因此该动作去重不能保证内联卡片全会话只发一次。恢复回复路径还有发送后补记动作记录，也不能把它理解成发送前去重。

这里“发送成功”表示相关调用在本实现中没有抛错、结果被记作交付/成功。它不等于客户已阅读、已申请老师或实际已经完成入群。外部发送与数据库更新之间仍有故障窗口；任务超时回收也不能提供外部严格 exactly-once。

### 7.5 卡片模板不是流程字段插值引擎

卡片模板另行保存 `name`、`description`、`title`、`subtitle`、`linkUrl`、`pictureUrl` 等。流程只引用模板 ID。模板文本可使用 `{{customer.name}}` 等变量；变量语法只支持 `(customer|group|flow|params).单个ASCII字段名`，且值必须是标量。缺失、对象值或不支持的路径会报错；URL 渲染后要求 http/https。

普通回复发送上下文只有 `customer.name` 和空 `params`；结构化卡片与跟进还传 `flow.collectedData` 对象，但渲染器不支持 `flow.collectedData.年龄` 的多级路径，也不能直接插值整个对象。因此不能假设任意 `collectFields` 都能在卡片中通过模板变量引用。原样跟进文本也不会自动替换普通 `{{年龄}}`，自然语言里的条件更不会由渲染器执行。

## 8. 自动跟进 activation 的完整规范

### 8.1 字段读取与默认值

| 路径 | 类型与推荐写法 | 服务端处理 |
|---|---|---|
| `activation.enabled` | boolean | `Boolean(value)`，缺失 false；字符串 `"false"` 实际会启用 |
| `activation.polishByAgent` | boolean | 仅严格 false 关闭，缺失 true |
| `activation.messages` | 消息对象数组 | 缺失/非数组→`[]`；空内容且无有效动作的项丢弃 |
| `activation.intervalMinutes` | 非负整数；兼容默认项 | 默认 30，供缺失单条间隔继承；规范化后不保留在 activation 顶层 |
| `activation.maxTimes` | 正整数；兼容默认项 | 默认 1，供单条继承；规范化后不保留在 activation 顶层 |
| `messages[].content` | string | 去首尾空白；提取并移除入群占位符，卡片占位符保留 |
| `messages[].intervalMinutes` | 非负整数 | `parseInt(value,10)`，有效时下限 0；无效继承顶层默认 |
| `messages[].maxTimes` | 正整数 | parseInt 后下限 1；0/无效值会回退默认，负数按 1；推荐明确正整数 |
| `messages[].actionsAfterSend` | 入群 action[] | 先过 `mergeInlineActions` 再规范化，当前只保留入群动作 |

消息也接受字符串简写，例如 `"方便时回复我。"`，其间隔和次数继承 activation 顶层默认。推荐全部使用对象，每条显式填写参数。

尽管通用动作规范支持 `send_card`，`actionsAfterSend` 前面的合并函数只接收入群动作，**这里写结构化 send_card 会被丢弃**。跟进发卡应放在 `content` 的合法卡片占位符中，建议使用 `polishByAgent:false` 保留原样。

空 content 配有效入群动作可以成为“只执行动作”的跟进项。无需真的发出文字，任务也会完成并消耗该项发送次数。

### 8.2 两种发送方式

`polishByAgent:false`：直接将当前跟进项的可见 content 交给统一发送器，支持文本和卡片；不让 LLM 改写。`generalRule` 不会再次由代码审核这段文字，因此不能在 content 写“请根据客户年龄决定是否发送卡片”并期待程序替你判断。

`polishByAgent:true`：生成 `flow_activation_due` 请求，将当前一条可见话术作为参考（最多 160 字符），由 Agent 生成 reply，再发送该 reply。此路径不把响应 `flowDecision` 应用于会话迁移或字段补丁；也没有发送响应 attachments 的普通附件分支。不能让模型靠这次润色自动完成节点。

当前 JSON 润色请求中的示例只列 reply/attachments/sources，而通用校验选项在存在 metadata.flow 时仍要求 flowDecision，存在请求示例与验证规则不完全一致的问题。润色失败可能因此进入修复/重试并最终失败。对严格话术、必须发送的卡片和首触达，优先使用原样模式。

### 8.3 什么时候开始、什么时候继续

通常在正常 AI 回复成功后，以该次发送结束时刻为 anchor，为当前节点安排下一条未完成跟进。若该回复完成节点，安排的是新节点的跟进。

新好友信号在满足绑定、流程启用与入口规则时可直接安排入口节点第一条跟进，不要求先有客户聊天正文。该入口使用专门的新好友识别/重复保护和联系人逻辑，不是所有 WorkTool 系统消息都会触发。

纯粹创建会话、保存新配置、手动切节点不等于自动创建第一条提醒。特别是控制台手动改节点会清空进度、取消旧任务，但该接口本身不调用 `scheduleCurrentActivation`。需要后续正常回复或其他明确的入口触发。

### 8.4 顺序、次数和时间计算

会话进度为：`{nodeId, messageIndex, sentCount}`。`messageIndex` 从 0 开始；`sentCount` 只累计当前话术成功完成次数。成功发完当前项 `maxTimes` 次后才进入下一项；全部耗尽后停止，不循环。

第 k 次发送某一话术：

```text
intervalMinutes > 0:
  delay = intervalMinutes × 60,000 × 2^(k-1)
intervalMinutes == 0:
  delay = 5,000 ms（每次均为 5 秒）
dueAt = 本次安排使用的 anchorAt + delay
```

后续任务通常以刚完成的发送时间作新 anchor。例：A 间隔 10 分钟、次数 3，B 间隔 60 分钟、次数 1；若首次锚点 10:00，忽略执行耗时，则 A 分别约在 10:10、10:30、11:10，B 在 12:10。不是 A 每十分钟发送，也不是 B 从 10:00 计算到 11:00。

进入下一条话术时 k 重置为 1。`maxTimes` 是成功发送次数，不是网络失败重试次数。`intervalMinutes:1440` 是相对延迟一天，不是每天固定时刻；“早上好”“昨天”等文字不会得到时钟语义校正。

### 8.5 客户回复和进度保留

客户回复使待发/进行中的提醒失效，但同节点已经完成的 `messageIndex/sentCount` 不因 generation 变化归零。新的 AI 回复成功后，以新时间作为 anchor 继续未完成部分。这避免客户每回一句就重播第一条跟进。

切换节点时 `activation_state_json` 清空，进入新节点从第一条开始。循环返回某节点也可能重新开始，因为系统只维护当前节点的进度，而不是每个节点一份永久累计账本。

全部话术已经发完后，同节点的新回复不会自动把它们复活。

### 8.6 worker、失效与失败处理

默认开启 worker，每 10 秒轮询，批量上限 20，processing 超时回收阈值 300000ms，激活 Agent 并发配置默认 2。对应环境变量前缀为 `ACTIVATION_`，不是 JSON 字段。实际发送时间会受轮询、队列、LLM、限流和发送耗时影响，5 秒是延迟目标而非精确 SLA。

任务存储节点 ID、generation、当前项、全消息快照、间隔、次数和 dueAt。worker 领取 pending→processing；检查会话仍存在、不是 human、节点与 generation 一致，再发送。发送完成事务记 sent 并推进进度，然后执行 actionsAfterSend，最后安排下一条。

客户新消息、节点迁移、人工接管、会话重置和保存流程等会使旧任务失效。发送前有检查，但不能撤回已经交给外部接口的消息。取消发生在外发期间时，可能记录“已发但此前被取消”，保留交付事实且不继续动作和下一条。

常规发送异常使任务变 failed；当前 worker 没有把所有 failed 自动放回 pending 的循环。processing 超时回收与失败重试是两回事。后续新一轮成功回复可能重新安排未消耗的进度，但不能将这一点当作失败即时自动重试保证。完成后的入群动作失败也不会撤销已消耗的跟进次数。

## 9. 不属于节点 JSON 的运行控制

人工接管通过 `handoffStatus` 等会话控制执行：取消旧提醒、抑制 AI 发送；转回 AI 也不是在配置中加入某个 `human` 字段。`attentionAlert` 属于独立业务告警响应，不等同于节点自动转人工。

标签由独立 tag schema 和 `tagDecision` 管理，可有独立标签跟进。`collectFields` 不会自动变成企业微信标签。群聊使用专门的群回复规则和群自动化任务，普通私聊 `buildFlowContext` 不应用于群聊。

机器人绑定是否启用、卡片权限、消息合并等待、失败兜底、Agent 请求预算、worker 开关等属于配置外控制。流程 JSON 正确但这些条件不满足时仍可能没有回复或没有动作。

## 10. 如何准确设计、生成和校验 JSON

### 10.1 推荐设计步骤

1. 先写客户阶段和完成证据，再将每个阶段映射为节点。把“发资料”和“客户反馈资料已收到/已申请”拆开，避免同一个卡片节点跨轮卡住。
2. 给每个节点确定唯一后继。需要条件分支时先确认是否可改成同节点的内容选择；若必须跳不同节点，应明确需要改代码。
3. 设计全流程字段词表。字段名稳定，值使用字符串/数值/布尔；用 goal 说明提取口径，不构造对象字段 schema。
4. 将完成条件写短，必要的禁止条件和动作选择在 goal 前段说清；tips 只保留三个核心提示。
5. 为动作选择明确触发位置：客户当轮发卡用 goal 占位符；固定迁移后入群用 actionsOnComplete；静默跟进入群用 actionsAfterSend。
6. 按相对发送时间计算完整提醒时间线，检查轮询延迟和指数间隔；写不依赖“今天/昨天/上午”的文本。
7. 对照可用工作区卡片、Bot 能力、群名和 Agent 绑定检查资源；保留稳定 ID。
8. 保存前验证，保存后重新读取规范化配置，比较重要字段；最后用隔离测试会话确认可观察结果。

### 10.2 静态检查清单：建议生成工具比服务端更严格

| 检查层 | 应检查什么 | 不通过时的含义 |
|---|---|---|
| JSON 语法 | 纯对象、无注释/尾逗号/重复键；正确转义 | 不能可靠解析，或重复键覆盖 |
| 顶层结构 | 只允许第 3 节字段；nodes 非空 | 未知字段会被忽略；空节点不能保存 |
| 节点结构 | ID/name 非空字符串，ID 唯一；每项都是对象 | 保存报错或发生不期望的类型转换 |
| 引用 | entryNodeId、所有非空 nextNodeId 存在 | 保存报错 |
| 图结构 | 从入口可达性、自环、循环、终点 | 服务端不拒绝，但可能业务永不推进 |
| 字段词表 | string[]，去空白后唯一；不超过 10 个/节点 | 对象会字符串化、后部字段不进入普通提示 |
| 提示长度 | generalRule≤600、completionCriteria≤160、tips≤3×160 | 超长部分可能根本没给模型 |
| 动作 | 类型、目标、必需参数、唯一 ID、放置位置 | 无效动作静默丢失、重复或无法执行 |
| 卡片 | 解析后标记正确；模板存在且同工作区；权限可用 | 保存或发送失败 |
| 完成一致性 | 卡片节点要求本轮发卡；终点不能依赖完成动作 | 配置虽合法却无法实现目标 |
| 跟进 | 真布尔值、非负整数间隔、正整数次数、有效内容/动作 | 隐式转换、空项丢弃或频率误判 |
| 类型与未知键 | 不允许用字符串模拟布尔，不允许自创字段 | 保存成功不代表语义生效 |
| 业务语义 | goal、完成条件、tips 和 generalRule 无冲突 | 仍需模型评估/场景验证，JSON Schema 无法证明 |

建议把 `additionalProperties:false`、严格类型、长度预算和稳定 ID 作为生成器的约束，但要标注这是“推荐生成规范”，不是当前服务端原生严格 JSON Schema。仅有 JSON Schema 也无法验证工作区资源存在、图可达性、动作成功或 LLM 业务判断。

### 10.3 最小场景验收矩阵

| 场景 | 观察点 |
|---|---|
| 新客户首条消息 | 是否落在入口节点，是否先回答当前问题 |
| 已有字段再次对话 | 是否避免重复问；检查实际 request 是否携带所需事实 |
| 客户提前给后续节点信息 | 白名单内资产能否采集，当前节点是否仍按自身条件完成 |
| 肯定、否定、费用问题、模糊回复 | 模型是否正确区分；代码不会替你判定 |
| 两个年龄档卡片 | 发送的是正确模板而非仅任一配置模板 |
| 卡片发送失败或后半段发送失败 | 状态、资产、部分出站记录是否一致，是否发生重复发卡 |
| 空后继节点声明完成 | 保持当前节点，完成动作不执行 |
| 客户在提醒到期前回复 | 旧 generation 取消，新回复后继续未完成进度 |
| 同一话术 maxTimes>1 | 按指数间隔排程，而非固定间隔 |
| 0 分钟跟进 | 约 5 秒延迟加 worker/队列耗时，非同步立即发送 |
| 人工接管/会话重置 | 待发任务取消，旧调用不污染新会话 |
| 保存改动 | 待发快照/时间是否迁移，共享 Agent 的其他 Bot 是否受影响 |

验证发送需使用测试联系人/群和真实可用模板。本文核查未调用线上 Agent、未发送消息、未保存生产流程；静态核查不能代替这些交付验收。

## 11. 修改现有流程时的真实影响

保存使用规范化后的配置替换同一 Agent 的定义；版本号不会触发单独的迁移策略。现有会话的资产和当前节点不会因为改 version 自动重置。

保存会递增绑定 Bot 会话的 activation generation，取消 processing 任务；对原本 pending 的任务按新配置、当前进度与原 anchor 尝试迁移，最多为同会话保留一个符合条件的 pending 任务。禁用流程、节点不匹配、人工接管、话术耗尽等情况会取消任务。若新 maxTimes 已被历史次数满足，会前移话术索引并使用保存时间作新 anchor。没有旧 pending 的会话，不会因保存动作一律新建提醒。

修改建议：

- 只改展示名而保留 ID，已有会话仍能找到节点。不要为了排序重建 ID。
- 删除/改名仍有会话停留的节点有风险：上下文构造可能回退显示入口，但会话中的旧 ID 并不自动统一迁移，后续固定跳转也可能找不到旧节点。
- 需要迁移客户时应显式处理会话节点；控制台节点接口是 `PUT /api/flow-sessions/:conversationKey/node`，参数包括 botId、nextNodeId、reason。它取消旧提醒，不自动执行被跳过节点完成动作。
- 修改字段名后，旧字典键不会自动映射到新键；资产展示按当前配置词表投影，旧值可能不再显示。
- 重排跟进 messages 是按索引改变含义，不是按消息 ID 做语义迁移，因为消息项没有稳定 id 字段。
- 完成动作 id 改变会改变幂等键；不要把“改 id 重发”当普通文案修改。

控制台 JSON→可视化编辑器→保存并非原样往返：编辑器可重分配冲突节点 ID、补默认值、提取入群标记；显式 `agentActions` 不被该编辑器保留，只能靠 goal 的合法卡片标记在服务端重新生成。建议总是对比保存前后返回的 config，而不是只看编辑器显示成功。

## 12. 当前项目“试音接待”配置的具体解读

核查文件为 `docs/试音接待-好的视为同意优化版.json`，读取时版本为 `2.6.0`，有四个节点：

```text
node_1 试音意愿 → node_4 申请跟进 → node_5 试音预约 → node_6 后续服务
```

`node_1` 的年龄、意愿和两种卡片分流全部由 LLM 按 goal 判断；“好/好的必须视为同意”并非程序内置词表。两张合法卡片均能被源码解析器识别，但本次没有连接数据库验证这些模板在部署环境存在。

该文件可见的限制：

- generalRule 为 416 字符，在 600 预算内；node_1 goal 为 905 字符，在常规 goal 预算内。
- node_1 completionCriteria 为 376 字符，普通请求只传前 160 字符；其中后部限制不会完整进入该字段。
- node_1 有 11 条 conversationTips，普通请求仅传前 3 条。其余八条不能作为该字段提供的运行保证，虽有部分规则在 goal 重复出现。
- 节点中五个“已采集”字段并不会因为发卡成功自动赋值，仍需模型正确返回补丁；普通 flow 上下文也没有完整的 session.collectedData。
- 卡片完成保护只验证本轮至少一张配置卡片交付，不验证“18–24 发 A、25–45 发 B”，年龄范围与费用咨询后的意愿判断仍需场景测试。
- node_1 两次提醒在无回复时约为首次回复后 10 分钟、再过 60 分钟，合计约 70 分钟。node_4 的 30/60/1440 也是逐条相对累计，而非都相对首次回复。
- node_5 的“早上好”“昨天”不会由 1440 分钟定时保证正确；如果前一条在下午发，下一条仍可能是下午。
- node_6 无后继、跟进关闭，因此可作为持续服务节点；不会因“结束”措辞自行关闭会话。

以上是现状分析，不代表已经修改这份业务 JSON。

## 13. 已验证的实现差异与复核方法

本次使用真实导出函数构建普通请求，再把该请求的 metadata 交给响应验证选项。最小样例将已有年龄资产置为 20，同时让模型回复一个不存在的 nextNodeId 和未配置补丁键。结果：

| 调用方式 | 结果 | 解释 |
|---|---|---|
| 使用真实 buildDclawRequest 生成的 metadata.flow 验证 | valid=true | 精简 flow 无完整节点图，节点/字段语义检查没有足够输入 |
| 手动给同一验证器完整 flow.machine.nodes | valid=false | 正常识别不存在的节点与未配置字段 |
| mergeInlineActions 输入入群标记和结构化 send_card | 保留入群，丢弃 send_card | 证明 actionsAfterSend 的实际过滤路径 |
| buildOutboundUnits 输入普通入群标记 | 返回 text 单元 | 证明普通统一发送器不执行入群标记 |

这不表示模型可以把非法节点写入数据库：最终 `applyFlowDecision` 仍只使用配置后继，补丁也仍受完整字段白名单过滤。它表示不能宣称响应网关已经完整强制执行所有配置约束。

用于交叉验证的现有测试共 24 项，全部通过：

```sh
node --test tests/flow-assets.test.js tests/flow-action-completion.test.js tests/activation-timing.test.js tests/dclaw-activation.test.js tests/agent-response-validation-options.test.js tests/outbound-units.test.js tests/card-action-chips.test.js
```

文档中的 6 个 JSON 代码块均已通过 JSON.parse；其中 2 个完整流程样例已使用从当前源码提取的 normalizeFlowConfig 及其实际依赖函数完成规范化检查，未加载数据库或调用保存接口。

这些测试覆盖资产过滤、卡片完成保护、指数/零分钟间隔、请求构造、校验选项及顺序发送；不是线上端到端验收。本文没有修改程序行为或把发现的边界作为已修复问题。

## 14. 源码依据索引

本文正文已经给出设计配置所需行为；以下索引用于后续版本升级时核对。行号对应本次工作区，未来可能移动。

| 依据 | 关键入口 | 对应主题 |
|---|---|---|
| `src/db.js:6979` | normalizeFlowConfig | 顶层、节点字段、引用校验、未知字段丢弃 |
| `src/db.js:7423` | collectFlowCardTemplateReferences / prepareFlowCardTemplateReferences | 模板引用与工作区 |
| `src/db.js:7530` | upsertFlowMachine / resetAgentFlowActivationState | Agent 归属、保存与旧提醒迁移 |
| `src/db.js:7758` | getOrCreateFlowSession | 新会话入口与普通会话升级 |
| `src/db.js:8360` | updateFlowSessionNode | 节点更新、事件记录、跟进进度清空 |
| `src/db.js:8458` | mergeFlowSessionData / normalizeFlowActions / normalizeActivationConfig | 字段合并、动作与跟进规范化 |
| `src/db.js:8569` | scheduleFlowActivationTask / claimDueFlowActivationTasks | 跟进快照与领取 |
| `src/db.js:8733` | reserveFlowActionExecution | 结构化动作幂等键 |
| `src/db.js:8843` | incrementFlowActivationGeneration / finalizeFlowActivationTaskDelivery | generation、进度与发送事务 |
| `src/flow-assets.js` | listConfiguredFlowCollectFields / filterConfiguredCollectedDataPatch | 全流程白名单与值过滤 |
| `src/dclaw.js:378` | buildDclawRequest 中 agentFlow 构造 | 普通请求的精简 flow |
| `src/dclaw.js:479` | 流程 instructions | 固定后继、占位符、禁止动态 actions |
| `src/dclaw.js:1160` | buildDclawActivationRequest | 润色请求与参考文字 |
| `src/dclaw.js:1307` | compactFlowForAgent | 实际传给模型的字段和资产条件 |
| `src/agent-response-validation-options.js` | buildAgentResponseValidationOptions | 网关使用 metadata.flow |
| `src/agent-response-gateway.js:1228` | validateRequiredCompletionActions | 发卡声明与占位符检查 |
| `src/agent-response-gateway.js:1435` | validateFlowDecision | 完整图校验的前置条件 |
| `src/flow-action-completion.js` | guardFlowActionCompletion | 发送后卡片保护 |
| `src/server.js:1509` | buildFlowContext / scheduleActivationAfterFlowReply | 完整配置读取、回复后安排提醒 |
| `src/server.js:1832` | executeFlowActions / applyFlowDecision | 动作、字段和固定跳转 |
| `src/server.js:3368` | sendOutboundReplyParts | 普通回复仅走统一卡片/文本发送 |
| `src/server.js:4351` | isStaleActivationTask / processFlowActivationTask | 过期检查、发送、动作、下一任务 |
| `src/server.js:6333` | 正常出站与 applyFlowDecision 调用段 | 先发送后推进的实际顺序 |
| `src/server.js:8708` | /api/flow-machines 路由 | 保存与读取 API |
| `src/server.js:9090` | /api/flow-sessions/:conversationKey/node | 手动节点迁移 |
| `src/action-chips.js` | extractCardActionChips / mergeInlineActions | 两类占位符及入群过滤 |
| `src/card-templates.js` | parseCardMarkers / renderCardTemplate | 标记语法、模板变量限制 |
| `src/outbound-content.js`、`src/outbound-units.js` | buildOutboundUnits / executeOutboundUnits | 模板解析、顺序发送、部分失败 |
| `src/activation-timing.js` | activationDelayMs | 0 分钟 5 秒与指数间隔 |
| `public/console/app.js:3067` | setFlowEditorFromConfig / buildFlowConfigFromEditor | 编辑器往返转换 |

交给 JSON 生成器时，应同时提供本文的字段字典、提示长度限制、动作位置差异和校验清单。要求生成器把“代码保证”“模型判断”“当前不支持”分开表述；不要输出能被保存却不会被执行的伪规则。
