# 配置补丁第二阶段

适用于管理员交付的 2026-10-03 正式契约。执行前读项目 `平台接口/第二阶段-20261003/` 的三份文档及 `工具/配置补丁联调/README.md`；若后续收到新版，以新契约和本次 API 返回为准。历史第一阶段文档只作历史记录。官方开发决策指南第 13 节及已导出工作包的 `AGENTS.md` 仍有一期“没有写接口”的旧表述；第二阶段 API 文档、执行单和实际接口已明确测试环境写入开放。工作包中的职责与文件边界仍按本次 Manifest 和源码核对。

## 从基线到发布

1. 在正确环境完成身份、能力、Bot 列表、员工明确选择、配置上下文、ready 检查和可信工作包导出。保留原 ZIP 与只读基线，只在独立副本修改。始终以本次 API 返回的 Release 和 Manifest 为基线；遇基线、指纹或能力目录冲突就重新导出并重做变更，不沿用旧副本。
2. 阅读工作包 `AGENTS.md`、Manifest、`platform/`、实际源码和已确认业务资料，填写 `change-plan.yaml`。四模块的声明与实际文件差异一致；Manifest 身份及来源指纹保持不变。记录本地静态检查和测试证据。
3. 使用第二阶段工具生成可移植 ZIP，上传并查询 upload。保存同一操作的稳定幂等键；同键同包重放应返回同一结果，同键异包为 409。上传、预检后核对线上 Release 未变化。
4. 预检必须 `PREPARED`、`canPublish=true`、无 blocker，记录过期时间。独立读取 diff，核对 Agent、knowledge、flowMachine、tags 四组件的 changed、旧/新摘要和文件清单。范围、业务口径或并发基线不符时停止。
5. 人工确认 diff 后才发布。结果不明先查 operation，必要时只用原键重放；不能换键盲重试。`ACTIVE` 后查新 Release、四项摘要和配置上下文，再用真实会话及渠道回执验证。将静态、API、对话、送达四层证据分别记录。
6. 回退目标应是明确选定的旧 Release；回退会创建新 Release，不覆盖历史。回退后同样核对 operation `ACTIVE`、新 Release、配置上下文、真实会话和回执。`RECOVERY_REQUIRED` 停止自动继续，交管理员恢复。

身份/绑定变化、readiness 不通过、路径或摘要失败、预检 blocker、diff 越界、正式环境写入关闭、或能力目录缺失，均按机器错误码停止在相应阶段。`BASE_RELEASE_CHANGED` 或 `SOURCE_FINGERPRINT_CHANGED` 后重新导出；`CONFIGURATION_INVALID` 或 `CHANGE_PLAN_MISMATCH` 有具体字段时按契约修复，再用新工作包重新上传预检。若只返回 `Upstream validation failed` 等笼统错误，保存脱敏的 uploadId、precheckId、ZIP 摘要、Bot、Release、时间和错误码，交管理员查询上游具体失败字段；不得猜测原因、反复盲测或绕过预检。平台缺少公共能力时提交标准化申请；目录升级后重新获取目录和工作包。不要直接访问内部接口或使用旧工作包继续发布。

新人完整写入练习要求管理员提供隔离的 ready 测试 Bot、可恢复起始 Release 和真实会话入口；第一阶段只读演练可共用 Bot，写入练习不能并行共用。业务负责人审核 SOP、diff 与最终验收证据。配置补丁发布只覆盖契约所含四组件；企微欢迎语、外部卡片、渠道绑定等不在包内的动作仍按各自渠道验证。
