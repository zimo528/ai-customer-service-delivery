"""GitHub transport for portable methods and private feedback.

Credentials stay in the OS-backed Git credential helper. Customer folders are never synchronized.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import getpass
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

SCHEMA = 'customer-service-feedback.v1'
SKILLS = ('ai-customer-service-delivery', 'dclaw-agent-config', 'grill-me', 'no-negative-echo')
PII = re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|\b(?:gh[pousr]_|github_pat_|sk-|dclaw_staff_)[A-Za-z0-9_\-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----', re.I)
MARKER = '<!-- customer-service-feedback.v1 -->'


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    fd, temporary = tempfile.mkstemp(prefix='.sync-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read(path, default=None):
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.is_file() else default


def next_display_version(label):
    if not valid_display_version(label):
        raise ValueError('远端版本识别号无效。')
    major, minor, patch = map(int, label.split('.'))
    # Legacy labels above 15 in the last position are interpreted as the old release count.
    number = major * 256 + minor * 16 + patch + 1
    major, remainder = divmod(number, 256)
    minor, patch = divmod(remainder, 16)
    return f'{major}.{minor}.{patch}'


def valid_display_version(label):
    if not isinstance(label, str) or not re.fullmatch(r'[1-9][0-9]*\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)', label):
        return False
    _, minor, patch = map(int, label.split('.'))
    return minor < 16 and (patch < 16 or (minor == 0 and label.startswith('1.0.')))


class RemoteError(RuntimeError):
    def __init__(self, status):
        self.status = status
        super().__init__(f'GitHub 请求未完成（状态 {status}）；本地待办保留。')


class GitHub:
    def __init__(self, token=None):
        if token is None:
            env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never')
            try:
                p = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\n\n', text=True,
                                   capture_output=True, timeout=30, env=env)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                raise RuntimeError('请先安装 Git 并在本机凭据管理器中配置 GitHub 凭据。') from None
            fields = dict(line.split('=', 1) for line in p.stdout.splitlines() if '=' in line)
            token = fields.get('password') if p.returncode == 0 else None
        if not token:
            raise RuntimeError('本机没有可用的 GitHub 凭据；调用方可用 auth-set 接入专用反馈 Token。')
        self.headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
                        'User-Agent': 'customer-service-skill-sync', 'X-GitHub-Api-Version': '2026-03-10'}

    def request(self, method, path, payload=None, raw=False, anonymous=False):
        if anonymous:
            match = re.fullmatch(r'repos/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)(?:/contents/(.+))?', path)
            if method != 'GET' or payload is not None or not match:
                raise ValueError('匿名访问仅用于公开方法仓库的读取。')
            name = urllib.parse.unquote(match[2]) if match[2] else 'latest.json'
            url = 'https://raw.githubusercontent.com/' + match[1] + '/main/' + urllib.parse.quote(name, safe='/')
            if name == 'latest.json':
                url += '?v=' + str(time.time_ns())
            req = urllib.request.Request(url, headers={'User-Agent': 'customer-service-skill-sync'})
            try:
                with urllib.request.urlopen(req, timeout=180) as response:
                    content = response.read()
            except urllib.error.HTTPError as exc:
                raise RemoteError(exc.code) from None
            except (urllib.error.URLError, TimeoutError):
                raise RemoteError('网络暂不可用') from None
            if match[2] is None:
                return {'private': False, 'archived': False, 'permissions': {'push': False}}
            return content if raw else {'sha': digest(content)}
        headers = dict(self.headers)
        if raw:
            headers['Accept'] = 'application/vnd.github.raw+json'
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        if body is not None:
            headers['Content-Type'] = 'application/json'
        req = urllib.request.Request('https://api.github.com/' + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=40) as response:
                content = response.read()
        except urllib.error.HTTPError as e:
            raise RemoteError(e.code) from None
        except (urllib.error.URLError, TimeoutError):
            raise RemoteError('网络暂不可用') from None
        return content if raw else json.loads(content) if content else None


def store_feedback_token(repository):
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
        raise ValueError('反馈仓库填写为 所有者/仓库名。')
    if not sys.stdin.isatty():
        raise RuntimeError('请在本机交互式终端运行 auth-set，勿将 Token 写入聊天或命令参数。')
    try:
        helper = subprocess.run(['git', 'config', '--get-all', 'credential.helper'], text=True,
                                capture_output=True, timeout=15)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        raise RuntimeError('本机缺少 Git 或凭据管理器。') from None
    helpers = helper.stdout.lower().splitlines() if helper.returncode == 0 else []
    if not any(any(name in item for name in ('manager', 'osxkeychain', 'libsecret', 'wincred')) for item in helpers):
        raise RuntimeError('请先启用 Git Credential Manager 或系统钥匙串；不将 Token 存为明文。')
    token = getpass.getpass('请输入仅授权私有反馈仓库 Issues 读写的 Token（输入不回显）：').strip()
    if not token.startswith('github_pat_') or any(ch.isspace() for ch in token):
        raise ValueError('请使用该私有仓库专用的 GitHub fine-grained Token。')
    api = GitHub(token=token)
    metadata = api.request('GET', 'repos/' + repository)
    if not metadata.get('private') or metadata.get('archived') or not metadata.get('has_issues', True):
        raise ValueError('反馈仓库必须为已启用 Issues 的可用私有仓库。')
    api.request('GET', 'repos/' + repository + '/issues?state=all&per_page=1')
    env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never')
    try:
        saved = subprocess.run(['git', 'credential', 'approve'],
                               input='protocol=https\nhost=github.com\nusername=x-access-token\npassword=' + token + '\n\n',
                               text=True, capture_output=True, timeout=30, env=env)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        raise RuntimeError('凭据保存未完成，请核对本机 Git Credential Manager。') from None
    if saved.returncode != 0:
        raise RuntimeError('凭据保存未完成，请核对本机 Git Credential Manager。')
    stored = GitHub()
    if stored.headers['Authorization'] != api.headers['Authorization']:
        raise RuntimeError('凭据管理器返回了另一枚凭据，请在本机核对后再初始化。')
    stored.request('GET', 'repos/' + repository + '/issues?state=all&per_page=1')
    return {'feedback_repository': repository, 'credential_saved': True, 'private_read_verified': True,
            'write_verified': False}


class Sync:
    def __init__(self, project, api=None):
        self.project = Path(project).resolve()
        self.state = self.project / '.经验同步'
        self.config_path = self.state / 'config.json'
        self.config = read(self.config_path)
        self._api = api

    @property
    def api(self):
        if self._api is None:
            self._api = GitHub()
        return self._api

    def route(self, suffix):
        if not self.config:
            raise RuntimeError('经验同步未初始化。')
        return 'repos/' + self.config['repository'] + '/' + suffix

    @contextmanager
    def locked(self, wait_seconds=30):
        # Several customer chats and the timer can share the same local queue.
        self.state.mkdir(parents=True, exist_ok=True)
        with (self.state / 'sync.lock').open('a+b') as lock:
            if lock.tell() == 0:
                lock.write(b'0')
                lock.flush()
            deadline = time.monotonic() + wait_seconds
            while True:
                try:
                    lock.seek(0)
                    if os.name == 'nt':
                        import msvcrt
                        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise RuntimeError('另一次同步仍在运行，本轮留待重试。') from None
                    time.sleep(0.2)
            try:
                # Initialization by another process may have completed while waiting.
                self.config = read(self.config_path)
                yield
            finally:
                lock.seek(0)
                if os.name == 'nt':
                    msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def role(self, expected):
        if not self.config or self.config['role'] != expected:
            raise RuntimeError('该操作只用于 ' + expected + ' 角色。')

    def init(self, repository, role, feedback_repository=None):
        if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
            raise ValueError('仓库填写为 GitHub账号/仓库名。')
        if feedback_repository and not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', feedback_repository):
            raise ValueError('反馈仓库填写为 GitHub账号/仓库名。')
        if self.config and (self.config['repository'] != repository or self.config['role'] != role):
            raise ValueError('已有不同同步配置，须先核对迁移范围。')
        metadata = self.api.request('GET', 'repos/' + repository, anonymous=role == 'worker')
        if metadata.get('archived'):
            raise ValueError('方法仓库已归档。')
        if role == 'controller' and not metadata.get('permissions', {}).get('push'):
            raise ValueError('主控账号需要发布权限。')
        if feedback_repository:
            feedback = self.api.request('GET', 'repos/' + feedback_repository)
            if not feedback.get('private') or feedback.get('archived'):
                raise ValueError('经验反馈只发送到可用的私有仓库。')
        if self.config and self.config.get('feedback_repository') not in (None, feedback_repository) and feedback_repository:
            raise ValueError('已有不同反馈仓库，须先核对迁移范围。')
        self.config = self.config or {'schema': 'customer-service-sync.v1', 'repository': repository,
                                     'role': role, 'node_id': self.node_id(), 'initialized_at': now()}
        if feedback_repository:
            self.config['feedback_repository'] = feedback_repository
        dump(self.config_path, self.config)
        return {'role': role, 'repository': repository,
                'feedback_repository': self.config.get('feedback_repository'), 'initialized': True}

    def node_id(self):
        if self.config:
            return self.config['node_id']
        path = self.state / 'node.json'
        node = read(path)
        if not node:
            node = {'id': str(uuid.uuid4())}
            dump(path, node)
        return node['id']

    def register_task(self, thread_id, title, customer_folder, created_at=None):
        thread_id = str(uuid.UUID(thread_id))
        folder = PurePosixPath(customer_folder.replace('\\', '/'))
        if not title.strip() or len(title) > 200 or folder.is_absolute() or '..' in folder.parts or len(folder.parts) < 2 or folder.parts[0] != '客户':
            raise ValueError('任务标题或客户目录无效。')
        if created_at is not None:
            try:
                moment = datetime.fromtimestamp(float(created_at), timezone.utc)
            except ValueError:
                moment = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                if moment.tzinfo is None:
                    raise ValueError('任务创建时间必须带时区。')
            created_at = moment.astimezone(timezone.utc).isoformat()
        path = self.state / 'task-registry.json'
        registry = read(path, {})
        registered_at = now()
        item = {'title': title.strip(), 'customerFolder': folder.as_posix(),
                'registeredAt': registered_at, 'scanFrom': created_at or registered_at}
        if thread_id in registry:
            if registry[thread_id]['title'] != item['title'] or registry[thread_id]['customerFolder'] != item['customerFolder']:
                raise ValueError('任务已登记为不同客户，须核对后处理。')
            return {'threadId': thread_id, **registry[thread_id], 'alreadyRegistered': True}
        registry[thread_id] = item
        dump(path, registry)
        return {'threadId': thread_id, **item, 'alreadyRegistered': False}

    def scan_begin(self):
        registry = read(self.state / 'task-registry.json', {})
        state = read(self.state / 'scan-state.json', {})
        cutoff = now()
        checkpoint = state.get('lastSuccessfulAt')
        task_checkpoints = state.get('taskCheckpoints', {})
        tasks = []
        for key, value in sorted(registry.items()):
            since = task_checkpoints.get(key) or value.get('scanFrom', value['registeredAt'])
            tasks.append({'threadId': key, **value, 'since': since})
        start = min((task['since'] for task in tasks), default=checkpoint or cutoff)
        run = {'runId': str(uuid.uuid4()), 'since': start, 'until': cutoff,
               'checkpointAtStart': checkpoint, 'tasks': tasks}
        dump(self.state / 'scan-run.json', run)
        return run

    def scan_finish(self, run_id, report):
        run = read(self.state / 'scan-run.json')
        if not run or run['runId'] != str(uuid.UUID(run_id)):
            raise ValueError('扫描轮次已变化，不能推进检查点。')
        expected = {task['threadId'] for task in run['tasks']}
        scanned = report.get('scannedThreadIds')
        if not isinstance(scanned, list) or len(scanned) != len(expected) or set(scanned) != expected:
            raise ValueError('并非所有登记任务都已完整检查，检查点保持不变。')
        feedback_ids = report.get('feedbackIds', [])
        if not isinstance(feedback_ids, list) or any(not (self.state / 'outbox' / (str(uuid.UUID(item)) + '.json')).is_file() for item in feedback_ids):
            raise ValueError('反馈编号缺少本机入队文件，检查点保持不变。')
        state = read(self.state / 'scan-state.json', {})
        if state.get('lastSuccessfulAt') != run['checkpointAtStart']:
            raise ValueError('检查点已被其他扫描更新，请重新开始。')
        task_checkpoints = state.get('taskCheckpoints', {})
        task_checkpoints.update({thread_id: run['until'] for thread_id in expected})
        state.update(lastSuccessfulAt=run['until'], lastRunId=run['runId'],
                     scannedTasks=len(expected), feedbackIds=feedback_ids,
                     taskCheckpoints=task_checkpoints)
        dump(self.state / 'scan-state.json', state)
        return {'lastSuccessfulAt': run['until'], 'scannedTasks': len(expected),
                'feedbackCount': len(feedback_ids)}

    def feedback_route(self, suffix):
        repository = self.config.get('feedback_repository') or self.config['repository']
        metadata = self.api.request('GET', 'repos/' + repository)
        if not metadata.get('private') or metadata.get('archived'):
            raise RuntimeError('公开方法仓库不接收经验反馈；本地队列保留，待接入私有反馈仓库。')
        return 'repos/' + repository + '/' + suffix

    def content(self, path, raw=False):
        return self.api.request('GET', self.route('contents/' + urllib.parse.quote(path, safe='/')),
                                raw=raw, anonymous=self.config['role'] == 'worker')

    def put(self, path, content, immutable=False):
        existing = None
        try:
            existing = self.content(path)
        except RemoteError as e:
            if e.status != 404:
                raise
        if existing:
            blob = b'blob ' + str(len(content)).encode('ascii') + b'\0' + content
            if existing['sha'] == hashlib.sha1(blob).hexdigest():
                return
            if immutable:
                raise ValueError('已发布版本不能覆盖。')
        body = {'message': 'Update delivery methods', 'content': base64.b64encode(content).decode('ascii')}
        if existing:
            body['sha'] = existing['sha']
        self.api.request('PUT', self.route('contents/' + urllib.parse.quote(path, safe='/')), body)

    def feedback(self, fields):
        required = {'module', 'problem', 'before', 'after', 'evidence', 'lesson', 'scope', 'test_level', 'business_change', 'result'}
        allowed = required | {'package_area'}
        if not required <= set(fields) or not set(fields) <= allowed:
            raise ValueError('反馈字段须与示例一致，证据只用脱敏后的简短片段。')
        if fields['module'] not in {'agent', 'state-machine', 'knowledge', 'delivery'}:
            raise ValueError('未知反馈板块。')
        if 'package_area' in fields and fields['package_area'] not in {
            'Skill与运行参考', '项目规则与流程', '调用方入口与任务话术', '新人入口与任务话术',
            '工具与自动化', '平台资料索引', '案例与模板', '总控协作', '待定位'}:
            raise ValueError('未知方法包改进位置。')
        if fields['test_level'] not in {'静态推演', '隔离模拟', '平台接口回读', '微信实测'} or type(fields['business_change']) is not bool:
            raise ValueError('测试层级和业务变更标记无效。')
        if fields['result'] not in {'改进', '失败', '无变化', '待验证'}:
            raise ValueError('测试结果无效。')
        for key in set(fields) - {'evidence', 'business_change'}:
            if not isinstance(fields[key], str) or not fields[key].strip() or len(fields[key]) > 4000:
                raise ValueError('反馈文字为空或过长。')
        if not isinstance(fields['evidence'], list) or not 1 <= len(fields['evidence']) <= 10:
            raise ValueError('反馈需附至少一项简短证据。')
        for evidence in fields['evidence']:
            if not isinstance(evidence, dict) or set(evidence) != {'input', 'observed', 'expected'}:
                raise ValueError('证据字段应为 input、observed、expected。')
            if any(not isinstance(v, str) or len(v) > 2000 for v in evidence.values()):
                raise ValueError('证据片段格式无效。')
        body = json.dumps(fields, ensure_ascii=False)
        if len(body.encode('utf-8')) > 30000 or PII.search(body):
            raise ValueError('反馈含联系方式／凭据或超过大小限制，请先脱敏并缩短。')

    def enqueue(self, fields, source_key=None):
        self.feedback(fields)
        if source_key is not None and (not source_key.strip() or len(source_key) > 500):
            raise ValueError('反馈来源键无效。')
        node_id = self.node_id()
        feedback_id = str(uuid.uuid5(uuid.UUID(node_id), source_key)) if source_key else str(uuid.uuid4())
        path = self.state / 'outbox' / (feedback_id + '.json')
        existing = read(path)
        if existing:
            if {key: existing[key] for key in fields} != fields:
                raise ValueError('同一来源键对应不同反馈内容，须核对后处理。')
            return existing
        installed = read(self.state / 'installed.json', {})
        item = dict(fields, schema=SCHEMA, id=feedback_id, node_id=node_id, created_at=now(),
                    method_version=installed.get('displayVersion', installed.get('version', '初始包')))
        dump(path, item)
        return item

    def submit(self):
        feedback_root = self.feedback_route('')
        sent = read(self.state / 'sent.json', {})
        attempts = read(self.state / 'submission-attempts.json', {})
        count = 0
        for path in sorted((self.state / 'outbox').glob('*.json')):
            item = read(path)
            if item['id'] in sent:
                continue
            self.feedback({k: v for k, v in item.items() if k not in {'schema', 'id', 'node_id', 'created_at', 'method_version'}})
            # A timed-out POST can have succeeded; look up the stable UUID before retrying.
            q = urllib.parse.quote('repo:' + feedback_root.removeprefix('repos/').rstrip('/') + ' is:issue ' + item['id'] + ' in:title')
            found = self.api.request('GET', 'search/issues?q=' + q)['items']
            matches = [x for x in found if x.get('title', '').endswith(item['id'])]
            if not matches and item['id'] in attempts:
                # GitHub search indexing can lag behind a successful POST. On retry
                # inspect the issue collection directly before creating anything.
                for page in range(1, 21):
                    recent = self.api.request('GET', feedback_root + f'issues?state=all&per_page=100&page={page}')
                    matches.extend(x for x in recent if 'pull_request' not in x and x.get('title', '').endswith(item['id']))
                    if len(recent) < 100:
                        break
                else:
                    raise RuntimeError('回传重试核对超过读取上限，本地反馈保留待核。')
            if len(matches) > 1:
                raise RuntimeError('远端有重复反馈编号，保留本地待核。')
            if matches:
                issue = matches[0]
                expected_body = MARKER + '\n```json\n' + json.dumps(item, ensure_ascii=False, indent=2) + '\n```'
                full = self.api.request('GET', feedback_root + 'issues/' + str(issue['number']))
                if full.get('body') != expected_body:
                    raise RuntimeError('远端反馈内容与本地不同，保留待核。')
            else:
                attempts[item['id']] = {'started_at': now()}
                dump(self.state / 'submission-attempts.json', attempts)
                issue = self.api.request('POST', feedback_root + 'issues', {
                    'title': '[经验反馈] ' + item['module'] + ' ' + item['id'],
                    'body': MARKER + '\n```json\n' + json.dumps(item, ensure_ascii=False, indent=2) + '\n```'})
            sent[item['id']] = {'issue': issue['number'], 'sent_at': now(), 'sha256': digest(path.read_bytes())}
            dump(self.state / 'sent.json', sent)
            count += 1
        return {'submitted': count, 'total_sent': len(sent)}

    def collect(self):
        self.role('controller')
        feedback_root = self.feedback_route('')
        received, ignored = 0, 0
        pending = read(self.state / 'decisions.json', {})
        for page in range(1, 21):
            issues = self.api.request('GET', feedback_root + f'issues?state=open&per_page=100&page={page}')
            for issue in issues:
                body = issue.get('body') or ''
                if 'pull_request' in issue or not body.startswith(MARKER + '\n```json\n') or not body.endswith('\n```'):
                    ignored += 1
                    continue
                try:
                    item = json.loads(body[len(MARKER + '\n```json\n'):-len('\n```')])
                    if item['schema'] != SCHEMA or str(uuid.UUID(item['id'])) != item['id']:
                        raise ValueError()
                    self.feedback({k: v for k, v in item.items() if k not in {'schema', 'id', 'node_id', 'created_at', 'method_version'}})
                except (ValueError, KeyError, TypeError):
                    ignored += 1
                    continue
                if item['id'] in pending:
                    continue
                local = self.state / 'inbox' / (item['id'] + '.json')
                record = {'issue': issue['number'], 'author': issue.get('user', {}).get('login'), 'feedback': item}
                if local.exists() and read(local) != record:
                    raise RuntimeError('已有反馈内容被改动，须核对后再处理。')
                if not local.exists():
                    dump(local, record)
                    received += 1
            if len(issues) < 100:
                break
        else:
            raise RuntimeError('反馈量超过本轮读取上限，须缩小范围；已收到内容保留。')
        ready = [str(p) for p in sorted((self.state / 'inbox').glob('*.json')) if p.stem not in pending]
        return {'new_feedback': received, 'pending_files': ready, 'ignored_other_issues': ignored}

    def background(self, skip_update=False):
        """Independent best-effort stages; delivery never depends on this result."""
        result = {'delivery_can_continue': True, 'stages': {}, 'errors': {}}
        if not self.config:
            result['errors']['setup'] = '同步尚未初始化，先使用本机方法继续交付。'
        else:
            stages = ['submit']
            if self.config['role'] == 'controller':
                stages.append('collect')
            elif not skip_update:
                stages.append('pull')
            else:
                result['update_deferred'] = '本轮只回传，留待任务间隙更新方法。'
            for stage in stages:
                try:
                    result['stages'][stage] = getattr(self, stage)()
                except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
                    result['errors'][stage] = str(exc)
        prior = read(self.state / 'background-result.json', {})
        result['attention_changed'] = bool(result['errors']) and result['errors'] != prior.get('errors', {})
        result['checked_at'] = now()
        try:
            dump(self.state / 'background-result.json', result)
        except OSError:
            result['errors']['local_record'] = '同步结果暂无法保存，客户交付继续。'
        return result

    @staticmethod
    def package(data, compatibility_bridge=False):
        if len(data) > 30 * 1024 * 1024:
            raise ValueError('方法包超过大小限制。')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if z.testzip() is not None or len(z.namelist()) != len(set(z.namelist())):
                raise ValueError('方法包损坏或有重复路径。')
            if sum(i.file_size for i in z.infolist()) > 50 * 1024 * 1024:
                raise ValueError('方法包解压大小超限。')
            roots = {PurePosixPath(n).parts[0] for n in z.namelist()}
            if len(roots) != 1:
                raise ValueError('方法包须有唯一根目录。')
            prefix = next(iter(roots)) + '/'
            manifest = json.loads(z.read(prefix + '文件校验清单.json'))
            required_skills = SKILLS
            if compatibility_bridge:
                legacy_skills = ('ai-customer-service-delivery', 'dclaw-agent-config', 'no-negative-echo')
                if (manifest.get('skills') != list(legacy_skills) or
                        manifest.get('compatibilityBridge', {}).get('from') != '1.2.6'):
                    raise ValueError('兼容过渡包的 Skill 声明或来源版本不符。')
                required_skills = legacy_skills
            else:
                declared = manifest.get('skills')
                if (not isinstance(declared, list) or
                        not all(isinstance(name, str) and re.fullmatch(r'[a-z0-9-]+', name)
                                for name in declared) or len(declared) != len(set(declared)) or
                        not set(SKILLS) <= set(declared)):
                    raise ValueError('方法包 Skill 清单无效。')
                required_skills = tuple(declared)
            expected = {prefix + f['path']: f for f in manifest['files']}
            if {n for n in z.namelist() if not n.endswith('/')} != set(expected) | {prefix + '文件校验清单.json'}:
                raise ValueError('方法包内容与清单不一致。')
            material = {}
            for n in z.namelist():
                pp = PurePosixPath(n)
                if pp.is_absolute() or '..' in pp.parts or '\\' in n or ':' in n:
                    raise ValueError('方法包路径不安全。')
                if n.endswith('/'):
                    continue
                content = z.read(n)
                if n in expected and digest(content).upper() != expected[n]['sha256'].upper():
                    raise ValueError('方法包文件哈希不一致。')
                rel = n.removeprefix(prefix + 'AI客服机器人交付中心/')
                permitted = rel in {
                    'AGENTS.md', '配置交付SOP链路.md', '本地项目目录约定.md', '.gitignore',
                    '客户Bot交付表.md', '新人交接操作链路手册.md',
                     '平台接口/README.md', '工具/客户目录.py',
                    '工具/配置补丁联调/phase1.py', '工具/配置补丁联调/test_phase1.py',
                    '工具/配置补丁联调/phase2.py', '工具/配置补丁联调/test_phase2.py',
                    '工具/配置补丁联调/local_auth.py', '工具/配置补丁联调/test_local_auth.py',
                    '工具/配置补丁联调/requirements.txt', '工具/配置补丁联调/README.md',
                } or any(
                    rel.startswith('.agents/skills/' + s + '/') for s in required_skills) or rel.startswith((
                    '工具/Agent基础包/', '工具/聊单清洗/', '工具/经验同步/',
                    '平台接口/第二阶段-20261003/'))
                if n.startswith(prefix + 'AI客服机器人交付中心/'):
                    if not permitted or any(part in {'.git', '__pycache__', '版本归档'} for part in pp.parts):
                        raise ValueError('方法包包含未许可路径：' + rel)
                    material[rel] = content
                elif n not in {prefix + '先看这里.md', prefix + '文件校验清单.json'}:
                    raise ValueError('未知包文件。')
            for s in required_skills:
                if '.agents/skills/' + s + '/SKILL.md' not in material:
                    raise ValueError('方法包缺少 Skill。')
            return material

    def publish(self, bundle, compatibility_bridge=False):
        self.role('controller')
        data = Path(bundle).read_bytes()
        self.package(data, compatibility_bridge=compatibility_bridge)
        hashed = digest(data)
        try:
            previous = json.loads(self.content('latest.json', raw=True))
        except RemoteError as exc:
            if exc.status != 404:
                raise
            previous = None
        if previous:
            if previous.get('schema') != 'customer-service-release.v1' or not re.fullmatch(r'[0-9a-f]{64}', previous.get('sha256', '')):
                raise ValueError('远端版本声明无效。')
            if previous['sha256'] == hashed:
                return previous
            prior_label = previous.get('displayVersion')
            if prior_label is None:
                display_version = '1.0.1'
            else:
                if not valid_display_version(prior_label):
                    raise ValueError('远端版本识别号无效。')
                display_version = next_display_version(prior_label)
        else:
            display_version = '1.0.1'
        latest = {'schema': 'customer-service-release.v1', 'version': hashed[:16], 'sha256': hashed,
                  'path': 'releases/' + hashed + '/startup.zip', 'bytes': len(data),
                  'displayVersion': display_version}
        self.put(latest['path'], data, immutable=True)
        bootstrap = Path(__file__).with_name('bootstrap.py').read_bytes()
        self.put('bootstrap.py', bootstrap)
        readme_template = Path(__file__).with_name('仓库README模板.md')
        if readme_template.is_file():
            readme = readme_template.read_text(encoding='utf-8')
            if any(marker not in readme for marker in ('{{DISPLAY_VERSION}}', '{{PACKAGE_PATH}}', '{{BOOTSTRAP_SHA256}}')):
                raise ValueError('仓库 README 模板缺少版本占位。')
            readme = (readme.replace('{{DISPLAY_VERSION}}', latest['displayVersion'])
                      .replace('{{PACKAGE_PATH}}', latest['path'])
                      .replace('{{BOOTSTRAP_SHA256}}', digest(bootstrap)))
            self.put('README.md', readme.encode('utf-8'))
        self.put('latest.json', (json.dumps(latest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
        dump(self.state / 'published.json', latest)
        return latest

    def pull(self):
        self.role('worker')
        latest = json.loads(self.content('latest.json', raw=True))
        if latest.get('schema') != 'customer-service-release.v1' or not re.fullmatch(r'[0-9a-f]{64}', latest.get('sha256', '')):
            raise ValueError('远端版本声明无效。')
        if latest.get('path') != 'releases/' + latest['sha256'] + '/startup.zip' or latest.get('version') != latest['sha256'][:16]:
            raise ValueError('远端版本路径不匹配。')
        if 'displayVersion' in latest and not valid_display_version(latest['displayVersion']):
            raise ValueError('远端版本识别号无效。')
        installed = read(self.state / 'installed.json', {})
        files = installed.get('files', {})
        intact = files and all((self.project / rel).is_file() and digest((self.project / rel).read_bytes()) == hashed for rel, hashed in files.items())
        if installed.get('sha256') == latest['sha256'] and intact:
            return {'updated': False, 'version': installed.get('displayVersion', installed['version']),
                    'internal_case': self.pull_internal_case()}
        data = self.content(latest['path'], raw=True)
        if digest(data) != latest['sha256'] or len(data) != latest['bytes']:
            raise ValueError('下载包与远端声明不一致。')
        material = self.package(data)
        # Preflight every target before changing any file; retain the exact local baseline.
        backup = self.state / 'versions' / (datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '-' + latest['version'])
        baseline = {}
        for rel in material:
            target = self.project / rel
            if any(parent.is_symlink() for parent in [target, *target.parents] if parent != self.project.parent):
                raise ValueError('同步目标含符号链接，须核对实际目录。')
            if not target.resolve().is_relative_to(self.project):
                raise ValueError('同步目标越出项目。')
            if target.exists() and not target.is_file():
                raise ValueError('同步目标不是普通文件。')
            baseline[rel] = target.read_bytes() if target.exists() else None
        for rel, prior in baseline.items():
            if prior is not None:
                dest = backup / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(prior)
        changed = []
        try:
            for rel, content in material.items():
                target = self.project / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                fd, temporary = tempfile.mkstemp(prefix='.method-', dir=target.parent)
                try:
                    with os.fdopen(fd, 'wb') as f:
                        f.write(content)
                    os.replace(temporary, target)
                    changed.append(rel)
                finally:
                    if os.path.exists(temporary):
                        os.unlink(temporary)
            for rel, content in material.items():
                if (self.project / rel).read_bytes() != content:
                    raise ValueError('更新后文件不一致。')
            dump(self.state / 'installed.json', dict(latest, files={rel: digest(content) for rel, content in material.items()}))
        except BaseException:
            for rel in reversed(changed):
                target = self.project / rel
                prior = baseline[rel]
                if prior is None:
                    target.unlink(missing_ok=True)
                else:
                    target.write_bytes(prior)
            raise
        return {'updated': True, 'version': latest.get('displayVersion', latest['version']), 'files': len(material),
                'backup': str(backup), 'internal_case': self.pull_internal_case()}

    def pull_internal_case(self):
        if not self.config.get('feedback_repository'):
            return {'available': False, 'reason': 'private repository is not configured'}
        tool = Path(__file__).with_name('case.py')
        if not tool.is_file():
            return {'available': False, 'reason': 'case tool is not installed yet'}
        try:
            spec = importlib.util.spec_from_file_location('customer_service_internal_case', tool)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module.pull(self)
        except (RuntimeError, ValueError, KeyError, OSError, TypeError, zipfile.BadZipFile) as exc:
            return {'available': False, 'error': str(exc)}

    def resolve(self, feedback_id, outcome, note, confirmed=False):
        self.role('controller')
        feedback_root = self.feedback_route('')
        feedback_id = str(uuid.UUID(feedback_id))
        record = read(self.state / 'inbox' / (feedback_id + '.json'))
        if not record:
            raise ValueError('反馈尚未收取。')
        if outcome not in {'已采用', '已改待实测', '不采用', '待业务确认', '待补证据', '待平台处理'} or not note.strip() or PII.search(note):
            raise ValueError('处理结果或说明无效。')
        if outcome == '已改待实测' and not read(self.state / 'published.json'):
            raise ValueError('先发布已校验的方法包，再记录已改待实测。')
        if outcome == '已采用':
            if record['feedback']['business_change'] and not confirmed:
                raise ValueError('业务变化须有本轮用户确认。')
            if not read(self.state / 'published.json'):
                raise ValueError('先发布已校验的方法包，再确认采用。')
        decisions = read(self.state / 'decisions.json', {})
        published = read(self.state / 'published.json', {})
        value = {'outcome': outcome, 'note': note, 'at': now(),
                 'version': published.get('displayVersion', published.get('version'))}
        if decisions.get(feedback_id, {}).get('outcome') == outcome and decisions[feedback_id].get('note') == note:
            return {'already_recorded': True}
        self.api.request('POST', feedback_root + 'issues/' + str(record['issue']) + '/comments', {
            'body': '处理结果：' + outcome + '\n方法版本：' + str(value['version'] or '未发布') + '\n' + note})
        if outcome in {'已采用', '不采用'}:
            self.api.request('PATCH', feedback_root + 'issues/' + str(record['issue']), {'state': 'closed'})
        else:
            self.api.request('PATCH', feedback_root + 'issues/' + str(record['issue']), {'state': 'open'})
        decisions[feedback_id] = value
        dump(self.state / 'decisions.json', decisions)
        return value


def main():
    parser = argparse.ArgumentParser(description='客服交付经验回传与方法版本同步')
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[2])
    sub = parser.add_subparsers(dest='command', required=True)
    initialize = sub.add_parser('init')
    initialize.add_argument('--repository', required=True)
    initialize.add_argument('--feedback-repository')
    initialize.add_argument('--role', choices=['worker', 'controller'], required=True)
    credential = sub.add_parser('auth-set')
    credential.add_argument('--feedback-repository', required=True)
    sub.add_parser('status')
    register = sub.add_parser('register-task')
    register.add_argument('--thread-id', required=True)
    register.add_argument('--title', required=True)
    register.add_argument('--customer-folder', required=True)
    register.add_argument('--created-at', help='任务创建时间：带时区的 ISO 时间或 Unix 秒')
    sub.add_parser('scan-begin')
    finish = sub.add_parser('scan-finish')
    finish.add_argument('--run-id', required=True)
    finish.add_argument('--report', type=Path, required=True)
    enqueue = sub.add_parser('enqueue')
    enqueue.add_argument('--file', type=Path, required=True)
    enqueue.add_argument('--source-key')
    for name in ['submit', 'collect', 'pull']:
        sub.add_parser(name)
    background = sub.add_parser('background')
    background.add_argument('--skip-update', action='store_true')
    publish = sub.add_parser('publish')
    publish.add_argument('--bundle', type=Path, required=True)
    publish.add_argument('--compatibility-bridge', action='store_true')
    resolve = sub.add_parser('resolve')
    resolve.add_argument('--id', required=True)
    resolve.add_argument('--outcome', required=True)
    resolve.add_argument('--note', required=True)
    resolve.add_argument('--confirmed-by-user', action='store_true')
    args = parser.parse_args()
    if args.command == 'background':
        try:
            sync = Sync(args.project)
            with sync.locked(wait_seconds=0):
                result = sync.background(args.skip_update)
        except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
            result = {'delivery_can_continue': True, 'deferred': True, 'errors': {'sync': str(exc)}}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    if args.command == 'auth-set':
        print(json.dumps(store_feedback_token(args.feedback_repository), ensure_ascii=False, indent=2))
        return
    sync = Sync(args.project)
    with sync.locked():
        if args.command == 'init':
            result = sync.init(args.repository, args.role, args.feedback_repository)
        elif args.command == 'status':
            installed = read(sync.state / 'installed.json')
            published = read(sync.state / 'published.json')
            active = published or installed or {}
            result = {'configured': bool(sync.config), 'role': (sync.config or {}).get('role'),
                      'repository': (sync.config or {}).get('repository'),
                      'version': active.get('displayVersion', active.get('version')),
                      'installed_version': installed.get('displayVersion', installed.get('version')) if installed else None,
                      'feedback_repository': (sync.config or {}).get('feedback_repository'),
                      'published_version': published.get('displayVersion', published.get('version')) if published else None,
                      'sha256': active.get('sha256'),
                      'registered_tasks': len(read(sync.state / 'task-registry.json', {})),
                      'last_successful_scan': read(sync.state / 'scan-state.json', {}).get('lastSuccessfulAt')}
        elif args.command == 'register-task':
            result = sync.register_task(args.thread_id, args.title, args.customer_folder, args.created_at)
        elif args.command == 'scan-begin':
            result = sync.scan_begin()
        elif args.command == 'scan-finish':
            result = sync.scan_finish(args.run_id, read(args.report, {}))
        elif args.command == 'enqueue':
            result = {'queued': sync.enqueue(read(args.file), args.source_key)['id']}
        elif args.command == 'publish':
            release = sync.publish(args.bundle, compatibility_bridge=args.compatibility_bridge)
            result = {'version': release.get('displayVersion', release['version']),
                      'sha256': release['sha256'], 'bytes': release['bytes']}
        elif args.command == 'resolve':
            result = sync.resolve(args.id, args.outcome, args.note, args.confirmed_by_user)
        else:
            result = getattr(sync, args.command)()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
