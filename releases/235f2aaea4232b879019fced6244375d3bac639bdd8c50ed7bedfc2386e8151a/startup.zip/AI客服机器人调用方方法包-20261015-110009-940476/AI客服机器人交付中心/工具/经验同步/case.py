"""Build and distribute an internal, non-deployable customer case through private Issues."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile
import zipfile


INDEX_MARKER = '<!-- customer-service-case-index.v1 -->'
ARCHIVE_MARKER = '<!-- customer-service-case-archive.v1 -->'
PART_MARKER = '<!-- customer-service-case-part.v1 '
INDEX_TITLE = '内部案例目录｜配音试音销售'
CASE_NAME = '配音试音销售'
PART_BYTES = 48000
MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
SOURCE_COUNT = 904
SENSITIVE = re.compile(
    r'(?<!\d)1[3-9]\d{9}(?!\d)|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}'
    r'|\b(?:github_pat_|gh[pousr]_|sk-|dclaw_staff_)[A-Za-z0-9_-]{12,}'
    r'|\b\d{17}[0-9Xx]\b|wxid_[A-Za-z0-9_-]{6,}', re.I)
BOT_ID = re.compile(r'\bwt[a-z0-9]{20,}\b', re.I)
CARD_ID = re.compile(r'\bcard_tpl_[a-z0-9]+\b', re.I)
CONVERSATION_ID = re.compile(r'\bwt-c-[a-z0-9]+\b', re.I)
KNOWLEDGE_ID = re.compile(r'mindspace-[a-f0-9]+', re.I)
URL = re.compile(r'https?://[^\s<>"\']+', re.I)
LOCAL_PATH = re.compile(r'[A-Za-z]:[\\/][^\s<>"\']+', re.I)
TEXT_EXTENSIONS = {'.md', '.txt', '.json', '.yaml', '.py'}
USER_FIELD = re.compile(r'((?:\*\*)?userId(?:\*\*)?\s*:\s*(?:\*\*)?\s*)([^\r\n]+)', re.I)
GROUP_FIELD = re.compile(r'((?:\*\*)?groupName(?:\*\*)?\s*:\s*(?:\*\*)?\s*)([^\r\n]+)', re.I)
PERSON_FIELD = re.compile(r'(?m)^([^\r\n]{0,16}(?:客户姓名|联系人|微信号|微信名|试音老师昵称|用户昵称)\s*[:：]\s*)([^\r\n]+)')
PERSON_TITLE = re.compile(r'(?m)^(#+\s*(?:客户档案|会话记录)\s*[:：]\s*)([^\r\n]+)')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Redactor:
    def __init__(self, person_map: dict[str, str] | None = None):
        self.ids: dict[str, dict[str, str]] = {}
        self.counters: dict[str, int] = {}
        self.person_map = person_map or {}

    def alias(self, kind: str, value: str) -> str:
        group = self.ids.setdefault(kind, {})
        if value not in group:
            group[value] = f'case_{kind}_{len(group) + 1:02d}'
        return group[value]

    def filename(self, relative: str) -> tuple[str, bool]:
        path = PurePosixPath(relative)
        extension = path.suffix or (path.name if path.name in TEXT_EXTENSIONS else '')
        if path.is_absolute() or '..' in path.parts or '\\' in relative:
            raise ValueError('Unsafe source path')
        name = relative
        private = False
        if relative.startswith('agent/会话记录/'):
            name = self._numbered('agent/会话记录/conversations', '会话', extension)
        elif relative.startswith('agent/客户档案/'):
            name = self._numbered('agent/客户档案', '档案', extension)
        elif relative.startswith('agent/docs/'):
            name = self._numbered('agent/docs', '历史资料', extension)
            private = True
        elif relative.startswith('agent/users/'):
            name = self._numbered('agent/users', '记忆', extension)
            private = True
        elif relative.startswith('agent/') and (path.name.startswith(('tmp_', '_tmp_')) or path.suffix == '.xlsx'):
            label = '辅助表格' if path.suffix == '.xlsx' else '辅助脚本'
            name = self._numbered('agent', label, path.suffix)
            private = True
        elif relative in {'agent/MEMORY.md', 'agent/output.json', 'agent/test_list.txt', 'agent/test_write.txt'}:
            private = True
        name = KNOWLEDGE_ID.sub(lambda match: self.alias('knowledge', match.group()), name)
        if SENSITIVE.search(name) or BOT_ID.search(name) or CONVERSATION_ID.search(name):
            raise ValueError('Sensitive filename requires an explicit mapping: ' + relative)
        return name, private

    def _numbered(self, folder: str, label: str, extension: str) -> str:
        key = folder + '/' + label
        self.counters[key] = self.counters.get(key, 0) + 1
        return f'{folder}/{label}-{self.counters[key]:04d}{extension}'

    def text(self, body: str) -> str:
        body = USER_FIELD.sub(lambda match: match[1] + self.alias('user', match[2].strip()), body)
        body = GROUP_FIELD.sub(lambda match: match[1] + ('（私聊）' if '私聊' in match[2] else self.alias('group', match[2].strip())), body)
        body = PERSON_FIELD.sub(lambda match: match[1] + self.alias('person', match[2].strip()), body)
        body = PERSON_TITLE.sub(lambda match: match[1] + self.alias('user', match[2].strip()), body)
        for original, replacement in self.person_map.items():
            body = body.replace(original, replacement)
        body = body.replace('wuhe_consulting_service', 'case_voice_sales_agent')
        body = KNOWLEDGE_ID.sub(lambda match: self.alias('knowledge', match.group()), body)
        body = CARD_ID.sub(lambda match: self.alias('card', match.group()), body)
        body = BOT_ID.sub(lambda match: self.alias('bot', match.group()), body)
        body = CONVERSATION_ID.sub(lambda match: self.alias('conversation', match.group()), body)
        body = LOCAL_PATH.sub('[LOCAL_PATH]', body)
        body = URL.sub('[CASE_URL]', body)
        body = SENSITIVE.sub('[REDACTED]', body)
        return body


def placeholder(extension: str) -> bytes:
    if extension == '.json':
        return b'{"case_redacted": true}\n'
    if extension == '.py':
        return b'# Historical helper removed from the anonymized case.\n'
    if extension == '.xlsx':
        return placeholder_xlsx()
    return '# 个人或历史内容已脱敏\n\n此文件仅保留原工作包中的位置与类型。\n'.encode('utf-8')


def placeholder_xlsx() -> bytes:
    files = {
        '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
        '_rels/.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        'xl/workbook.xml': '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Redacted" sheetId="1" r:id="rId1"/></sheets></workbook>',
        'xl/_rels/workbook.xml.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
        'xl/worksheets/sheet1.xml': '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>Personal workbook content redacted</t></is></c></row></sheetData></worksheet>',
    }
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as book:
        for name, body in files.items():
            book.writestr(name, body)
    return out.getvalue()


def build(source: Path, destination: Path, index_text: str, person_map: dict[str, str]) -> dict:
    if not source.is_dir():
        raise ValueError('Case source directory is missing')
    if not index_text.strip() or not person_map or any(not key or not value for key, value in person_map.items()):
        raise ValueError('Private case index and replacement map are required')
    redactor = Redactor(person_map)
    files = sorted(path for path in source.rglob('*') if path.is_file())
    if len(files) != SOURCE_COUNT:
        raise ValueError(f'Expected {SOURCE_COUNT} files, got {len(files)}; review the new baseline first')
    output: dict[str, bytes] = {}
    for path in files:
        if path.is_symlink():
            raise ValueError('Symlink in case source')
        relative = path.relative_to(source).as_posix()
        new_name, private = redactor.filename(relative)
        extension = path.suffix.lower() or (path.name if path.name in TEXT_EXTENSIONS else '')
        if extension not in TEXT_EXTENSIONS | {'.xlsx'}:
            raise ValueError('Unknown file format: ' + relative)
        if private:
            content = placeholder(extension)
        else:
            content = redactor.text(path.read_text(encoding='utf-8-sig')).encode('utf-8')
        if new_name in output:
            raise ValueError('Case path collision: ' + new_name)
        output['工作包/' + new_name] = content
    output['案例索引.md'] = index_text.encode('utf-8')
    manifest = {'schema': 'customer-service-internal-case.v1', 'case': CASE_NAME,
                'sourceFiles': len(files), 'files': {name: sha(data) for name, data in sorted(output.items())}}
    output['文件校验清单.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(output.items()):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    result = verify(destination, person_map)
    return {'archive': str(destination), **result}


def verify(archive_path: Path, blocked_terms=()) -> dict:
    raw = archive_path.read_bytes()
    if len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('Internal case exceeds size limit')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
        if archive.testzip() is not None or len(names) != len(set(names)):
            raise ValueError('Internal case ZIP is damaged or has duplicate paths')
        manifest = json.loads(archive.read('文件校验清单.json'))
        if manifest.get('schema') != 'customer-service-internal-case.v1':
            raise ValueError('Unknown internal case schema')
        expected = manifest['files']
        if set(names) != set(expected) | {'文件校验清单.json'} or manifest['sourceFiles'] != SOURCE_COUNT:
            raise ValueError('Internal case file inventory does not match')
        if len([name for name in names if name.startswith('工作包/')]) != SOURCE_COUNT:
            raise ValueError('Internal case did not retain the full file tree')
        if sum(info.file_size for info in archive.infolist()) > 30 * 1024 * 1024:
            raise ValueError('Internal case expands beyond the size limit')
        for name in names:
            path = PurePosixPath(name)
            if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name:
                raise ValueError('Unsafe internal case path')
            data = archive.read(name)
            if name in expected and sha(data) != expected[name]:
                raise ValueError('Internal case file checksum mismatch')
            if SENSITIVE.search(name) or BOT_ID.search(name) or CONVERSATION_ID.search(name):
                raise ValueError('Sensitive case filename remains')
            if path.suffix in TEXT_EXTENSIONS and name != '文件校验清单.json':
                body = data.decode('utf-8')
                if path.suffix == '.json':
                    json.loads(body)
                if SENSITIVE.search(body) or BOT_ID.search(body) or CARD_ID.search(body) or URL.search(body):
                    raise ValueError('Sensitive string remains in ' + name)
                if any(person in body for person in blocked_terms):
                    raise ValueError('Known private name remains in ' + name)
                if name.startswith(('工作包/agent/客户档案/', '工作包/agent/会话记录/')):
                    if any(not match[2].strip().startswith('case_user_') for match in USER_FIELD.finditer(body)):
                        raise ValueError('Unredacted userId remains in ' + name)
            elif path.suffix == '.xlsx':
                with zipfile.ZipFile(io.BytesIO(data)) as book:
                    if book.testzip() is not None or book.namelist() != placeholder_xlsx_names():
                        raise ValueError('Unexpected spreadsheet content in anonymized case')
        knowledge = json.loads(archive.read('工作包/knowledge/knowledge-manifest.json'))
        for document in knowledge.get('documents', []):
            if '工作包/knowledge/' + document['path'] not in names:
                raise ValueError('Anonymized knowledge manifest has a missing document')
    return {'sha256': sha(raw), 'bytes': len(raw), 'sourceFiles': SOURCE_COUNT}


def placeholder_xlsx_names() -> list[str]:
    with zipfile.ZipFile(io.BytesIO(placeholder_xlsx())) as book:
        return book.namelist()


def installed_intact(version_dir: Path, archive_path: Path) -> bool:
    with zipfile.ZipFile(archive_path) as archive:
        for name in archive.namelist():
            target = version_dir.joinpath(*PurePosixPath(name).parts)
            if target.is_symlink() or not target.is_file() or sha(target.read_bytes()) != sha(archive.read(name)):
                return False
    return True


def issue_pages(api, route):
    for page in range(1, 21):
        batch = api.request('GET', f'{route}/issues?state=all&per_page=100&page={page}')
        yield from (item for item in batch if 'pull_request' not in item)
        if len(batch) < 100:
            return
    raise ValueError('Too many private Issues to find the case index')


def case_index(sync, route: str):
    matches = [item for item in issue_pages(sync.api, route)
               if item.get('title') == INDEX_TITLE and (item.get('body') or '').startswith(INDEX_MARKER + '\n')]
    if len(matches) > 1:
        raise ValueError('Duplicate internal case index Issues')
    return matches[0] if matches else None


def comments(api, route: str, number: int):
    for page in range(1, 21):
        batch = api.request('GET', f'{route}/issues/{number}/comments?per_page=100&page={page}')
        yield from batch
        if len(batch) < 100:
            return
    raise ValueError('Too many internal case comment pages')


def upload(sync, archive_path: Path) -> dict:
    sync.role('controller')
    checked = verify(archive_path)
    data = archive_path.read_bytes()
    route = sync.feedback_route('').rstrip('/')
    title = f'内部案例归档｜{CASE_NAME}｜{checked["sha256"][:16]}'
    archive_manifest = {'schema': 'customer-service-case-archive.v1', **checked,
                        'partCount': (len(data) + PART_BYTES - 1) // PART_BYTES}
    issues = [item for item in issue_pages(sync.api, route) if item.get('title') == title]
    if len(issues) > 1:
        raise ValueError('Duplicate case archive Issues')
    if issues:
        issue = issues[0]
        if json.loads((issue.get('body') or '').removeprefix(ARCHIVE_MARKER + '\n')) != archive_manifest:
            raise ValueError('Existing case archive manifest differs')
    else:
        issue = sync.api.request('POST', route + '/issues',
                                 {'title': title, 'body': ARCHIVE_MARKER + '\n' + json.dumps(archive_manifest, ensure_ascii=False)})
    number = issue['number']
    present = {}
    for item in comments(sync.api, route, number):
        match = re.fullmatch(r'<!-- customer-service-case-part\.v1 ([0-9a-f]{64}) (\d+) -->\n([A-Za-z0-9+/=]+)', item.get('body') or '')
        if match and match[1] == checked['sha256']:
            part = base64.b64decode(match[3], validate=True)
            index = int(match[2])
            if index in present and present[index] != part:
                raise ValueError('Conflicting case parts')
            present[index] = part
    for index in range(archive_manifest['partCount']):
        part = data[index * PART_BYTES:(index + 1) * PART_BYTES]
        if index in present:
            if present[index] != part:
                raise ValueError('Remote case part differs')
            continue
        body = f'{PART_MARKER}{checked["sha256"]} {index} -->\n' + base64.b64encode(part).decode('ascii')
        sync.api.request('POST', f'{route}/issues/{number}/comments', {'body': body})
    latest = {'schema': 'customer-service-case-index.v1', 'case': CASE_NAME,
              'archiveIssue': number, **checked}
    current = case_index(sync, route)
    body = INDEX_MARKER + '\n' + json.dumps(latest, ensure_ascii=False)
    if current:
        sync.api.request('PATCH', f'{route}/issues/{current["number"]}', {'body': body, 'state': 'open'})
        index_number = current['number']
    else:
        index_number = sync.api.request('POST', route + '/issues', {'title': INDEX_TITLE, 'body': body})['number']
    return {'indexIssue': index_number, 'archiveIssue': number, **checked}


def pull(sync, output_root: Path | None = None) -> dict:
    if not sync.config or not sync.config.get('feedback_repository'):
        return {'available': False, 'reason': 'private repository is not configured'}
    route = sync.feedback_route('').rstrip('/')
    index = case_index(sync, route)
    if not index:
        return {'available': False, 'reason': 'case index has not been published'}
    value = json.loads(index['body'][len(INDEX_MARKER) + 1:])
    if value.get('schema') != 'customer-service-case-index.v1' or not re.fullmatch(r'[0-9a-f]{64}', value.get('sha256', '')):
        raise ValueError('Invalid case index')
    root = output_root or sync.project / '内部案例' / CASE_NAME
    root = Path(root)
    installed = root / '安装状态.json'
    if installed.is_file():
        status = json.loads(installed.read_text(encoding='utf-8'))
        archive = root / '案例工作包.zip'
        version_dir = root / '版本' / value['sha256'][:16]
        if (status.get('sha256') == value['sha256'] and archive.is_file()
                and sha(archive.read_bytes()) == value['sha256'] and installed_intact(version_dir, archive)):
            return {'available': True, 'updated': False, 'sha256': value['sha256'], 'path': str(version_dir)}
    issue = sync.api.request('GET', f'{route}/issues/{value["archiveIssue"]}')
    if not (issue.get('body') or '').startswith(ARCHIVE_MARKER + '\n'):
        raise ValueError('Case archive Issue marker is missing')
    manifest = json.loads(issue['body'][len(ARCHIVE_MARKER) + 1:])
    if any(manifest.get(key) != value.get(key) for key in ('sha256', 'bytes', 'sourceFiles')):
        raise ValueError('Case archive differs from index')
    parts = {}
    for item in comments(sync.api, route, value['archiveIssue']):
        match = re.fullmatch(r'<!-- customer-service-case-part\.v1 ([0-9a-f]{64}) (\d+) -->\n([A-Za-z0-9+/=]+)', item.get('body') or '')
        if match and match[1] == value['sha256']:
            index_num = int(match[2])
            part = base64.b64decode(match[3], validate=True)
            if index_num in parts and parts[index_num] != part:
                raise ValueError('Conflicting case parts')
            parts[index_num] = part
    if set(parts) != set(range(manifest['partCount'])):
        raise ValueError('Internal case is incomplete; retry later')
    data = b''.join(parts[number] for number in range(manifest['partCount']))
    if len(data) != value['bytes'] or sha(data) != value['sha256']:
        raise ValueError('Internal case checksum differs')
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.case-', dir=root) as temporary:
        temp = Path(temporary) / '案例工作包.zip'
        temp.write_bytes(data)
        verify(temp)
        version_dir = root / '版本' / value['sha256'][:16]
        if version_dir.exists() and not installed_intact(version_dir, temp):
            raise ValueError('Existing case version has local changes; review it before reinstalling')
        if not version_dir.exists():
            extracted = Path(temporary) / 'extracted'
            extracted.mkdir()
            with zipfile.ZipFile(temp) as archive:
                for name in archive.namelist():
                    target = extracted.joinpath(*PurePosixPath(name).parts)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.read(name))
            version_dir.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(extracted), str(version_dir))
        os.replace(temp, root / '案例工作包.zip')
    status = {'sha256': value['sha256'], 'indexIssue': index['number'],
              'archiveIssue': value['archiveIssue'], 'installedAt': datetime.now().astimezone().isoformat()}
    installed.write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'available': True, 'updated': True, 'sha256': value['sha256'], 'path': str(version_dir)}


def main() -> None:
    from sync import Sync
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[2])
    commands = parser.add_subparsers(dest='command', required=True)
    build_cmd = commands.add_parser('build')
    build_cmd.add_argument('--source', type=Path, required=True)
    build_cmd.add_argument('--output', type=Path, required=True)
    build_cmd.add_argument('--index-file', type=Path, required=True)
    build_cmd.add_argument('--replacements-file', type=Path, required=True)
    check_cmd = commands.add_parser('verify')
    check_cmd.add_argument('--archive', type=Path, required=True)
    send_cmd = commands.add_parser('publish')
    send_cmd.add_argument('--archive', type=Path, required=True)
    get_cmd = commands.add_parser('pull')
    get_cmd.add_argument('--output-root', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'build':
            person_map = json.loads(args.replacements_file.read_text(encoding='utf-8'))
            if not isinstance(person_map, dict) or any(not isinstance(value, str) for value in person_map.values()):
                raise ValueError('Private replacement map must be an object of text pairs')
            result = build(args.source, args.output, args.index_file.read_text(encoding='utf-8'), person_map)
        elif args.command == 'verify':
            result = verify(args.archive)
        elif args.command == 'publish':
            result = upload(Sync(args.project), args.archive)
        else:
            result = pull(Sync(args.project), args.output_root)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, RuntimeError, KeyError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == '__main__':
    main()
